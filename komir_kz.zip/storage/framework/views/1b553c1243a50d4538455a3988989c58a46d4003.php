<?php $__env->startSection('content'); ?>
    <script src="https://code.jquery.com/jquery-migrate-3.0.1.js" integrity="sha256-VvnF+Zgpd00LL73P2XULYXEn6ROvoFaa/vbfoiFlZZ4=" crossorigin="anonymous"></script>
    <script src="/admin/scripts/jquery-ui-1.10.3.full.min.js"></script>

    <div class="alert alert-success alert-dismissible fade show mb-0 client-alert" role="alert" style="display: none">
        <button type="button" class="close" data-dismiss="alert" aria-label="Close">
            <span aria-hidden="true">×</span>
        </button>
        <i class="fa fa-check mx-2"></i>
        Данные клиента успешно обновлены
    </div>

    <div class="main-content-container container-fluid px-4">
        <!-- Page Header -->
        <div class="page-header row no-gutters py-4">
            <div class="col-12 col-sm-4 text-center text-sm-left mb-0">
                <h3 class="page-title"><?php if($row['client_id'] > 0): ?> <?php echo e($row['client_name']); ?> <?php else: ?> Добавление нового клиента <?php endif; ?> </h3>
            </div>
        </div>
        <!-- End Page Header -->

        <style>
            label.error{
                color: red;
                height: auto;
                display: block;
                text-align: center;
            }

            input.error{
                height: auto;
            }
        </style>

        <!-- Default Light Table -->
        <div class="row">
            <form id="client_form" method="post" enctype="multipart/form-data" style="display: contents">
                <input type="hidden" name="_token" value="<?php echo e(csrf_token()); ?>">
                <input type="hidden" name="client_id" value="<?php echo e($row->client_id); ?>" id="client_id">
                <div class="col-lg-8 d-flex">
                    <div class="col-lg-6 pl-0">
                        <div class="card card-small mb-4 pt-1">
                            <div class="card-header border-bottom text-left">
                                <h5 class="mb-0">Данные</h5>
                            </div>
                            <div class="card-body">
                                <div id="client-contact-form" method="post" enctype="multipart/form-data">
                                    <div class="form-group">
                                        <label for="client-contact-form-name">Фамилия</label>
                                        <input type="text" name="client_surname" id="client-contact-form-name" placeholder="" class="form-control" value="<?php echo e($row['client_surname']); ?>">
                                    </div>
                                    <div class="form-group">
                                        <label for="client-contact-form-name">Имя</label>
                                        <input type="text" name="client_name" id="client-contact-form-name" placeholder="" class="form-control" value="<?php echo e($row['client_name']); ?>">
                                    </div>
                                    <div class="form-group">
                                        <label for="client-contact-form-phone">Телефон</label>
                                        <input type="tel" name="client_phone" id="client-contact-form-phone" placeholder="" class="form-control" value="<?php echo e($row['client_phone']); ?>">
                                    </div>
                                    <div class="form-group">
                                        <label for="client-contact-form-email">Email</label>
                                        <input type="email" name="client_email" id="client-contact-form-email" placeholder="" class="form-control" value="<?php echo e($row['client_email']); ?>">
                                    </div>
                                    <button type="button" name="button" id="client-contact-form-submit" onclick="updateClientInfo()" class="mb-2 btn btn-primary mr-2">Обновить</button>
                                </div>
                            </div>
                        </div>
                    </div>


                    <div class="col-lg-6 pr-0">
                        <div class="card card-small mb-4 pt-1">
                            <div class="card-header border-bottom text-left">
                                <h5 class="mb-0">Грузоперевозчик</h5>
                            </div>
                            <div class="card-body">
                                <div id="client-transporter-form">
                                    <div class="form-group">
                                        <input type="hidden" name="client_region_id" value="<?php echo e($row['client_region_id']); ?>" id="client_region_id">
                                        <label for="client-transporter-form-region">Область</label>
                                        <input type="text" name="region_name" id="client-transporter-form-region" placeholder="" class="form-control ui-autocomplete-input" autocomplete="off" value="<?php echo e($row['region_name']); ?>">
                                    </div>
                                    <div class="form-group">
                                        <input type="hidden" name="client_station_id" value="<?php echo e($row['client_station_id']); ?>" id="client_station_id">
                                        <label for="client-transporter-form-station">Станция</label>
                                        <input type="text" name="station_name" id="client-transporter-form-station" placeholder="" class="form-control" value="<?php echo e($row['station_name']); ?>">
                                    </div>
                                    <div class="form-group">
                                        <label for="client-transporter-form-receiverCode">Код получателя</label>
                                        <input type="text" name="client_receiver_code" id="client-transporter-form-receiverCode" placeholder="" class="form-control" value="<?php echo e($row['client_receiver_code']); ?>">
                                    </div>
                                    <button type="submit" name="button" id="client-transporter-form-submit" onclick="updateClientInfo()" class="mb-2 btn btn-primary mr-2">Обновить</button>
                                </div>
                            </div>
                        </div>
                    </div>

                </div>

                <div class="col-lg-8">
                    <div class="card card-small mb-4">
                        <div class="card-header border-bottom">
                            <h5 class="m-0">Компания</h5>
                        </div>
                        <ul class="list-group list-group-flush">
                            <li class="list-group-item p-3">
                                <div class="row">
                                    <div class="col">
                                        <div id="client-company-form">
                                            <div class="form-row">
                                                <input type="hidden" name="client_company_id" value="<?php echo e($row['client_company_id']); ?>">
                                                <div class="form-group col-md-6">
                                                    <label for="client-company-form-name">Наименование компании</label>
                                                    <input type="text" class="form-control" id="client-company-form-name" placeholder="" name="company_name" value="<?php echo e($company_row['company_name']); ?>">
                                                </div>
                                                <div class="form-group col-md-6">
                                                    <label for="client-company-form-bankName">Банк</label>
                                                    <select id="client-company-form-bankName" class="form-control" name="company_bank_id">
                                                        <?
                                                        use App\Models\Bank;
                                                        $bank_list = Bank::orderBy("bank_name","asc")->get();
                                                        ?>
                                                        <option value="0">Выберите банк</option>
                                                        <?php if(@count($bank_list) > 0): ?>
                                                            <?php $__currentLoopData = $bank_list; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $bank_item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                                <option value="<?php echo e($bank_item['bank_id']); ?>" <?php if($bank_item['bank_id'] == $company_row['company_bank_id']): ?> selected <?php endif; ?>><?php echo e($bank_item['bank_name']); ?></option>
                                                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                                        <?php endif; ?>
                                                    </select>
                                                </div>
                                            </div>
                                            <div class="form-row">
                                                <div class="form-group col-md-6">
                                                    <label for="client-company-form-ceoPosition">Должность руководителя</label>
                                                    <input type="text" class="form-control" id="client-company-form-ceoPosition" placeholder="" value="<?php echo e($company_row['company_ceo_position']); ?>" name="company_ceo_position"> </div>
                                                <div class="form-group col-md-6">
                                                    <label for="client-company-form-bankIIK">ИИК</label>
                                                    <input type="text" class="form-control" id="client-company-form-bankIIK" placeholder="" value="<?php echo e($company_row['company_bank_iik']); ?>" name="company_bank_iik"> </div>
                                            </div>
                                            <div class="form-row">
                                                <div class="form-group col-md-6">
                                                    <label for="client-company-form-ceoName">ФИО руководителя</label>
                                                    <input type="text" class="form-control" id="client-company-form-ceoName" placeholder="" value="<?php echo e($company_row['company_ceo_name']); ?>" name="company_ceo_name"> </div>
                                                
                                                    
                                                    
                                            </div>
                                            <div class="form-row">
                                                <div class="form-group col-md-6">
                                                    <label for="client-company-form-address">Юридический адрес</label>
                                                    <input type="text" class="form-control" id="client-company-form-assress" placeholder="" value="<?php echo e($company_row['сompany_address']); ?>" name="сompany_address"> </div>
                                                <div class="form-group col-md-6">
                                                    <label for="client-company-form-bankBIN">БИН</label>
                                                    <input type="text" class="form-control" id="client-company-form-bankBIN" placeholder="" value="<?php echo e($company_row['company_bank_bin']); ?>" name="company_bank_bin"> </div>
                                            </div>
                                            <div class="form-row">
                                                <div class="form-group col-md-6">
                                                    <button type="button" id="client-company-form-submit" onclick="updateClientInfo()" class="btn btn-primary">Обновить</button>
                                                </div>
                                                <div class="form-group d-flex align-items-center col-md-6">
                                                    <div class="custom-control custom-toggle custom-toggle-sm mb-1">
                                                        <input type="checkbox" id="client-company-form-isDiscount" name="is_discount" class="custom-control-input" <?php if($row['is_discount'] == 1): ?> checked="checked" <?php endif; ?>>
                                                        <label class="custom-control-label" for="client-company-form-isDiscount">Давать скидку (нет/да)</label>
                                                    </div>
                                                </div>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                            </li>
                        </ul>
                    </div>
                </div>
            </form>

        </div>
        <!-- End Default Light Table -->
    </div>

    <script>
        $(document).ready(function(){
            $("#client_form").validate({
                rules : {
                    'company_bank_id':{min:1},
                    'client_region_id':{min:1},
                    region_name: {required: true},
                    'client_station_id':{min:1},
                    station_name: {required: true}
                },
                messages:{
                    'company_bank_id': {min: "Выберите Банк"},
                    'client_region_id': {min: "Выберите Регион"},
                    region_name: {required: "Выберите Регион"},
                    'client_station_id': {min: "Выберите Область"},
                    station_name: {required: "Выберите Область"}
                }
            });

            $("#client-transporter-form-region").autocomplete({
                source: function( request, response ) {
                    $.ajax({
                        url: "/admin/get-region-list",
                        data: {
                            region_search_str: request.term
                        },
                        success: function( data ) {
                            response( $.map( data.region_list, function( item ) {
                                return {
                                    label: item.region_name,
                                    value: item.region_name,
                                    key: item.region_id
                                }
                            }));
                        }
                    });
                },
                minLength: 2,
                select: function( event, ui ) {
                    $("#client_region_id").val(ui.item.key);
                    $(this).val(ui.item.value);
                    return false;
                }
            });

            $("#client-transporter-form-station").autocomplete({
                source: function( request, response ) {
                    $.ajax({
                        url: "/admin/get-station-list",
                        data: {
                            station_search_str: request.term
                        },
                        success: function( data ) {
                            response( $.map( data.station_list, function( item ) {
                                return {
                                    label: item.station_name,
                                    value: item.station_name,
                                    key: item.station_id
                                }
                            }));
                        }
                    });
                },
                minLength: 2,
                select: function( event, ui ) {
                    $("#client_station_id").val(ui.item.key);
                    $(this).val(ui.item.value);
                    return false;
                }
            });

        });

        function updateClientInfo(){
            if (!$("#client_form").valid()){
                return false;
            }

            $.ajax({
                type: 'POST',
                url: "/admin/client-edit",
                data: $("#client_form").serialize(),
                success: function(data){
                    if(data.result == false){
                        alert("Ошибка при сохранении клиента");
                    }
                    else{
                        $(".client-alert").fadeIn(200);
                        window.location.href = "/admin/client-list";
                    }
                }
            });
        }
    </script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('admin.layout', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>