<?php $__env->startSection('layout'); ?>
    <?php  $user = Auth::user();
            $action_name = "";
            $controller_name = "";
            $current_path_parts = explode("/",Route::getFacadeRoot()->current()->uri());
            if(isset($current_path_parts[0])){
                $controller_name = $current_path_parts[0];
            }
            if(isset($current_path_parts[1])){
                $action_name = $current_path_parts[1];
            }
    ?>
    <style>
        .dropdown-parent{position: relative}
    </style>
    <body class="h-100">
        <meta name="csrf-token" content="<?php echo e(csrf_token()); ?>" />

        <div class="container-fluid">
            <div class="row">
                <!-- Main Sidebar -->
                <aside class="main-sidebar col-12 col-md-3 col-lg-2 px-0">
                    <div class="main-navbar">
                        <nav class="navbar align-items-stretch navbar-light bg-white flex-md-nowrap border-bottom p-0">
                            <a class="navbar-brand w-100 mr-0" href="/admin/index" style="line-height: 25px;">
                                <div class="d-table m-auto">
                                    <img id="main-logo" class="d-inline-block align-top mr-1" style="max-width: 65%;" src="/admin/images/main-logo.svg" alt="Komir.kz">
                                </div>
                            </a>
                            <a class="toggle-sidebar d-sm-inline d-md-none d-lg-none">
                                <i class="material-icons">&#xE5C4;</i>
                            </a>
                        </nav>
                    </div>
                    <form action="#" class="main-sidebar__search w-100 border-right d-sm-flex d-md-none d-lg-none">
                        <div class="input-group input-group-seamless ml-3">
                            <div class="input-group-prepend">
                                <div class="input-group-text">
                                    <i class="fas fa-search"></i>
                                </div>
                            </div>
                            <input class="navbar-search form-control" type="text" placeholder="Поиск" aria-label="Search"> </div>
                    </form>
                    <div class="nav-wrapper">
                        <ul class="nav flex-column">
                            <li class="nav-item">
                                <a class="nav-link <?php if($action_name == "index"): ?> active <?php endif; ?> " href="/admin/index">
                                    <i class="material-icons">pie_chart</i>
                                    <span>Аналитика</span>
                                </a>
                            </li>
                            <li class="nav-item">
                                <a class="nav-link " href="/admin/deal-list?type=list">
                                    <i class="material-icons">vertical_split</i>
                                    <span>Сделки</span>
                                </a>
                            </li>
                            <li class="nav-item">
                                <a class="nav-link " href="/admin/user-task-list">
                                    <i class="material-icons">note_add</i>
                                    <span>Задачи</span>
                                </a>
                            </li>
                            <li class="nav-item">
                                <a class="nav-link " href="/admin/station-list">
                                    <i class="material-icons">view_module</i>
                                    <span>Тарифы</span>
                                </a>
                            </li>
                            <li class="nav-item">
                                <a class="nav-link" href="/admin/client-list">
                                    <i class="material-icons">table_chart</i>
                                    <span>Клиенты</span>
                                </a>
                            </li>
                            <li class="nav-item">
                                <a class="nav-link " href="/admin/profile">
                                    <i class="material-icons">person</i>
                                    <span>Личный кабинет</span>
                                </a>
                            </li>
                            <li class="nav-item">
                                <a class="nav-link " href="#">
                                    <i class="material-icons">settings</i>
                                    <span>Настройки</span>
                                </a>
                            </li>


                            <li class="nav-item" >
                                <a class="nav-link dropdown-parent" data-toggle="dropdown-tab-settings" href="javascript:;">
                                    <i class="material-icons">settings</i>
                                    <span>Справочники</span>
                                    <span class="dropdown-arrow">▶</span>
                                </a>
                            </li>
                            <ul class="nav flex-column dropdown-tab" id="dropdown-tab-settings">
                                <li class="nav-item ">
                                    <a class="nav-link" href="/admin/deal-template-file-list">
                                        <span class="ml-4">Шаблоны файлов сделки</span>
                                    </a>
                                </li>
                                <li class="nav-item ">
                                    <a class="nav-link" href="/admin/company-list">
                                        <span class="ml-4">Компании</span>
                                    </a>
                                </li>
                                <li class="nav-item ">
                                    <a class="nav-link" href="/admin/user-list">
                                        <span class="ml-4">Пользователи</span>
                                    </a>
                                </li>
                                <li class="nav-item ">
                                    <a class="nav-link" href="/admin/region-list">
                                        <span class="ml-4">Области</span>
                                    </a>
                                </li>
                                <li class="nav-item ">
                                    <a class="nav-link" href="/admin/bank-list">
                                        <span class="ml-4">Банк</span>
                                    </a>
                                </li>
                                <li class="nav-item ">
                                    <a class="nav-link" href="/admin/payment-list">
                                        <span class="ml-4">Условия оплаты</span>
                                    </a>
                                </li>
                                <li class="nav-item ">
                                    <a class="nav-link" href="/admin/delivery-list">
                                        <span class="ml-4">Срок доставки</span>
                                    </a>
                                </li>
                                <li class="nav-item ">
                                    <a class="nav-link" href="/admin/brand-list">
                                        <span class="ml-4">Разрез</span>
                                    </a>
                                </li>
                                <li class="nav-item ">
                                    <a class="nav-link" href="/admin/mark-list">
                                        <span class="ml-4">Марка угля</span>
                                    </a>
                                </li>
                                <li class="nav-item ">
                                    <a class="nav-link" href="/admin/fraction-list">
                                        <span class="ml-4">Фракции</span>
                                    </a>
                                </li>
                                <li class="nav-item ">
                                    <a class="nav-link" href="/admin/percent-list">
                                        <span class="ml-4">Процент владельца</span>
                                    </a>
                                </li>
                                <li class="nav-item ">
                                    <a class="nav-link" href="/admin/status-list">
                                        <span class="ml-4">Статус</span>
                                    </a>
                                </li>
                                <li class="nav-item ">
                                    <a class="nav-link" href="/admin/timezone-list">
                                        <span class="ml-4">Часовой пояс</span>
                                    </a>
                                </li>
                            </ul>
                        </ul>
                    </div>
                </aside>
                <!-- End Main Sidebar -->
                <main class="main-content col-lg-10 col-md-9 col-sm-12 p-0 offset-lg-2 offset-md-3">
                    <div class="main-navbar sticky-top bg-white">
                        <!-- Main Navbar -->
                        <nav class="navbar align-items-stretch navbar-light flex-md-nowrap p-0">
                            <div class="col-md-9 d-flex align-items-center justify-content-between">
                                <h4 class="mb-0 ml-2">
                                    <?php if($action_name == "bank-list"): ?>
                                        Банк
                                    <?php elseif($action_name == "bank-edit"): ?>
                                        <?php if($row['bank_id'] > 0): ?> <?php echo e($row['bank_name']); ?> <?php else: ?> Добавление нового банка <?php endif; ?>

                                    <?php elseif($action_name == "brand-list"): ?>
                                        Разрез
                                    <?php elseif($action_name == "brand-edit"): ?>
                                        <?php if($row['brand_id'] > 0): ?> <?php echo e($row['brand_name']); ?> <?php else: ?> Добавление нового разреза <?php endif; ?>

                                    <?php elseif($action_name == "client-list"): ?>
                                        Клиенты
                                    <?php elseif($action_name == "client-edit"): ?>
                                        <?php if($row['client_id'] > 0): ?> <?php echo e($row['client_name']); ?> <?php else: ?> Добавление нового клиента <?php endif; ?>

                                    <?php elseif($action_name == "company-list"): ?>
                                        Компании
                                    <?php elseif($action_name == "company-edit"): ?>
                                        <?php if($row['company_id'] > 0): ?> <?php echo e($row['company_name']); ?> <?php else: ?> Добавление новой компании <?php endif; ?>

                                    <?php elseif($action_name == "deal-list"): ?>
                                        Сделки
                                    <?php elseif($action_name == "deal-edit"): ?>
                                        <?php if($row['deal_id'] > 0): ?> <?php echo e($row['station_name']); ?> - <?php echo e($row['mark_name']); ?>  <?php echo e($row['deal_volume']); ?> тонн <?php else: ?> Добавление новой сделки <?php endif; ?>

                                    <?php elseif($action_name == "deal-template-file-list"): ?>
                                        Шаблоны файлов сделки
                                    <?php elseif($action_name == "deal-template-file-edit"): ?>
                                        <?php if($row['deal_template_file_id'] > 0): ?> <?php echo e($row['deal_template_file_id']); ?> <?php else: ?> Добавление нового шаблона файла <?php endif; ?>

                                    <?php elseif($action_name == "delivery-list"): ?>
                                        Срок доставки
                                    <?php elseif($action_name == "delivery-edit"): ?>
                                        <?php if($row['delivery_id'] > 0): ?> <?php echo e($row['delivery_name']); ?> <?php else: ?> Добавление новой сроки доставки <?php endif; ?>

                                    <?php elseif($action_name == "fraction-list"): ?>
                                        Фракции
                                    <?php elseif($action_name == "fraction-edit"): ?>
                                        <?php if($row['fraction_id'] > 0): ?> <?php echo e($row['fraction_name']); ?> <?php else: ?> Добавление новой фракции <?php endif; ?>

                                    <?php elseif($action_name == "mark-list"): ?>
                                        Марки угля
                                    <?php elseif($action_name == "mark-edit"): ?>
                                        <?php if($row['mark_id'] > 0): ?> <?php echo e($row['mark_name']); ?> <?php else: ?> Добавление новой марки угля <?php endif; ?>

                                    <?php elseif($action_name == "payment-list"): ?>
                                        Условия оплаты
                                    <?php elseif($action_name == "payment-edit"): ?>
                                        <?php if($row['payment_id'] > 0): ?> <?php echo e($row['payment_name']); ?> <?php else: ?> Добавление новой условии оплаты <?php endif; ?>

                                    <?php elseif($action_name == "percent-list"): ?>
                                        Процент владельца
                                    <?php elseif($action_name == "percent-edit"): ?>
                                        <?php if($row['percent_id'] > 0): ?> <?php echo e($row['percent_name']); ?> <?php else: ?> Добавление нового процента владельца <?php endif; ?>

                                    <?php elseif($action_name == "profile"): ?>
                                        <?php echo e($row['user_surname']); ?> <?php echo e($row['user_name']); ?>


                                    <?php elseif($action_name == "region-list"): ?>
                                        Области
                                    <?php elseif($action_name == "region-edit"): ?>
                                        <?php if($row['region_id'] > 0): ?> <?php echo e($row['region_name']); ?> <?php else: ?> Добавление новой области <?php endif; ?>

                                    <?php elseif($action_name == "station-list"): ?>
                                        Тарифы
                                    <?php elseif($action_name == "station-edit"): ?>
                                        <?php if($row['station_id'] > 0): ?> <?php echo e($row['station_name']); ?> <?php else: ?> Добавление нового тарифа <?php endif; ?>

                                    <?php elseif($action_name == "status-list"): ?>
                                        Статусы
                                    <?php elseif($action_name == "status-edit"): ?>
                                        <?php if($row['status_id'] > 0): ?> <?php echo e($row['status_name']); ?> <?php else: ?> Добавление нового статуса <?php endif; ?>

                                    <?php elseif($action_name == "timezone-list"): ?>
                                        Часовой пояс
                                    <?php elseif($action_name == "timezone-edit"): ?>
                                        <?php if($row['timezone_id'] > 0): ?> <?php echo e($row['timezone_name']); ?> <?php else: ?> Добавление нового часового пояса <?php endif; ?>

                                    <?php elseif($action_name == "user-list"): ?>
                                        Пользователи
                                    <?php elseif($action_name == "user-edit"): ?>
                                        <?php if($row['user_id'] > 0): ?> <?php echo e($row['user_surname']); ?> <?php echo e($row['user_name']); ?> <?php else: ?> Добавление нового пользователя <?php endif; ?>

                                    <?php elseif($action_name == "user-task-list"): ?>
                                        Задачи
                                    <?php elseif($action_name == "index"): ?>
                                        Аналитика
                                    <?php endif; ?>
                                </h4>
                                <?php if($controller_name == "admin" && $action_name == "deal-edit"): ?>
                                    <button type="button" class="btn btn-danger" id="deal-reject-navbar" onclick="showDealRejectForm()">Отказ клиента</button>
                                <?php endif; ?>
                            </div>
                            <ul class="navbar-nav border-left flex-row ">
                                <li class="nav-item border-right dropdown notifications">
                                    <a class="nav-link nav-link-icon text-center" href="#" role="button" id="dropdownMenuLink" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">
                                        <div class="nav-link-icon__wrapper">
                                            <i class="material-icons">&#xE7F4;</i>
                                            <span class="badge badge-pill badge-danger">2</span>
                                        </div>
                                    </a>
                                    <div class="dropdown-menu dropdown-menu-small" aria-labelledby="dropdownMenuLink">
                                        <a class="dropdown-item" href="#">
                                            <div class="notification__icon-wrapper">
                                                <div class="notification__icon">
                                                    <i class="material-icons">&#xE6E1;</i>
                                                </div>
                                            </div>
                                            <div class="notification__content">
                                                <span class="notification__category">Analytics</span>
                                                <p>Your websiteвЂ™s active users count increased by
                                                    <span class="text-success text-semibold">28%</span> in the last week. Great job!</p>
                                            </div>
                                        </a>
                                        <a class="dropdown-item" href="#">
                                            <div class="notification__icon-wrapper">
                                                <div class="notification__icon">
                                                    <i class="material-icons">&#xE8D1;</i>
                                                </div>
                                            </div>
                                            <div class="notification__content">
                                                <span class="notification__category">Sales</span>
                                                <p>Last week your storeвЂ™s sales count decreased by
                                                    <span class="text-danger text-semibold">5.52%</span>. It could have been worse!</p>
                                            </div>
                                        </a>
                                        <a class="dropdown-item notification__all text-center" href="#"> View all Notifications </a>
                                    </div>
                                </li>


                                <li class="nav-item dropdown d-flex align-items-center">
                                    <a class="nav-link dropdown-toggle text-nowrap px-3" data-toggle="dropdown" href="#" role="button" aria-haspopup="true" aria-expanded="false">
                                        <span class="d-none d-md-inline-block"><?php echo e($user->user_surname); ?> <?php echo e($user->user_name); ?></span>
                                    </a>
                                    <div class="dropdown-menu dropdown-menu-small">
                                        <a class="dropdown-item" href="/admin/profile">
                                            <i class="material-icons">&#xE7FD;</i> Профиль</a>
                                        <a class="dropdown-item" href="#">
                                            <i class="material-icons">vertical_split</i> Сделки</a>
                                        <a class="dropdown-item" href="#">
                                            <i class="material-icons">note_add</i> Задачи</a>
                                        <div class="dropdown-divider"></div>
                                        <a class="dropdown-item text-danger" href="/admin/logout">
                                            <i class="material-icons text-danger">&#xE879;</i> Выйти </a>
                                    </div>
                                </li>
                            </ul>
                            <nav class="nav">
                                <a href="#" class="nav-link nav-link-icon toggle-sidebar d-md-inline d-lg-none text-center border-left" data-toggle="collapse" data-target=".header-navbar" aria-expanded="false" aria-controls="header-navbar">
                                    <i class="material-icons">&#xE5D2;</i>
                                </a>
                            </nav>
                        </nav>
                    </div>
                    <!-- / .main-navbar -->

                    <?php echo $__env->yieldContent('content'); ?>

                    <footer class="main-footer d-flex p-2 px-3 bg-white border-top">
                        <ul class="nav">
                            <li class="nav-item">
                                <a class="nav-link" href="/admin/index">Аналитика</a>
                            </li>
                            <li class="nav-item">
                                <a class="nav-link" href="/admin/deal-list?type=list">Сделки</a>
                            </li>
                            <li class="nav-item">
                                <a class="nav-link" href="/admin/user-task-list">Задачи</a>
                            </li>
                            <li class="nav-item">
                                <a class="nav-link" href="/admin/station-list">Тарифы</a>
                            </li>
                            <li class="nav-item">
                                <a class="nav-link" href="/admin/client-list">Клиенты</a>
                            </li>
                        </ul>
                        <span class="copyright ml-auto my-auto mr-2">Copyright В© 2019
                          <a href="#" rel="nofollow">Company</a>
                        </span>
                    </footer>

                    <div id="modal-shadow"></div>
                    <div class="modal-window-refuse rounded" id="modal-window-refuse">
                        <div class="card-body p-0 py-1 rounded text-center">
                            <div class="card-header px-4 pb-0 text-left">
                                <h5 class="mb-0">Отказ клиента</h5>
                                <div class="d-flex flex-wrap no-gutters mt-2">
                                    <div class="col-12 col-sm-5">
                                        <span>ОТВЕТСТВЕННЫЙ</span>
                                        <p class="mb-0" id="deal-card-6-responsible">Какимжанов <br>Ильдос</p>
                                    </div>
                                    <div class="col-12 col-sm-7 text-sm-right">
                                        <span>ДАТА ОТПРАВЛЕНИЯ</span>
                                        <p class="mb-0" id="deal-card-6-date">21.10.2019<br>10:10</p>
                                    </div>
                                </div>
                            </div>
                            <div class="card-body px-4">
                                <form id="deal-tasks-form">
                                    <div class="form-group">
                                        <textarea class="form-control" id="deal-tasks-form-comment" name="comment" rows="4">Ответ</textarea>
                                    </div>
                                    <button type="submit" name="submit" id="deal-tasks-form-submit" class="mb-4 mt-2 btn btn-primary float-right">Отправить</button>
                                </form>
                            </div>
                        </div>
                    </div>
                </main>
            </div>
        </div>
    </body>

    <script>
        $('#tasks-card-3-form-percents').on("click", function(){
            if (document.getElementById('tasks-card-3-form-percents').checked) {
                document.getElementById('percent').style.color = '#007bff';
                document.getElementById('number').style.color = '#5a6169';
                document.getElementById('percent').style.fontWeight = 'bold';
                document.getElementById('number').style.fontWeight = 'normal';
            } else {
                document.getElementById('percent').style.color = '#5a6169';
                document.getElementById('number').style.color = '#007bff';
                document.getElementById('percent').style.fontWeight = 'normal';
                document.getElementById('number').style.fontWeight = 'bold';
            }
        });
        $('#see-all-clients').on("click", function(){
            document.getElementById('modal-shadow').style.display = 'block';
            document.getElementById('modal-window-clients').style.display = 'block';
        });
        $('#modal-shadow').on("click", function(){
            document.getElementById('modal-shadow').style.display = 'none';
            document.getElementById('modal-window-clients').style.display = 'none';
        })

        jQuery(function($) {
            $( ".datepicker").datepicker({
                showOtherMonths: true,
                selectOtherMonths: false,
                dateFormat: 'dd.mm.yy',
                monthNames : ['Январь','Февраль','Март','Апрель','Май','Июнь','Июль','Август','Сентябрь','Октябрь','Ноябрь','Декабрь'],
                dayNamesMin: ['Вс','Пн','Вт','Ср','Чт','Пт','Сб']
            });
        });

        function changeCheckboxValue(ob){
            if($(ob).is(":checked")){
                $(ob).closest(".form-group").find(".hidden-checkbox-value").attr("value",1);
            }
            else{
                $(ob).closest(".form-group").find(".hidden-checkbox-value").attr("value",0);
            }
        }
        var CSRF_TOKEN = $('meta[name="csrf-token"]').attr('content');

        function showDealRejectForm(){
            document.getElementById('modal-shadow').style.display = 'block';
            document.getElementById('modal-window-refuse').style.display = 'block';
        }
        document.getElementById('modal-shadow').onclick = function(){
            document.getElementById('modal-shadow').style.display = 'none';
            document.getElementById('modal-window-refuse').style.display = 'none';
            document.getElementById('modal-window-clients').style.display = 'none';
        }
    </script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('admin.top', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>