<!DOCTYPE html>
<html class="no-js h-100">
<head>
    <meta charset="UTF-8">
</head>

<body>
    <style>
        * { font-family: DejaVu Sans }
    </style>
    <?=$deal_template_text?>
</body>
</html>
