<?php if(@count($deal_task_list) > 0): ?>
    <?php $__currentLoopData = $deal_task_list; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $deal_task_item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <div class="rounded border-danger border px-1 py-1 mb-2 task-small-card" id="task-small-card-1">
            <div class="d-flex align-items-center justify-content-between">
                <span class="task-small-card-status">
                    <span class="task-small-card-status-icon" style="color: <?php echo e($deal_task_item['task_color']); ?> !important;">
                        ⚫
                    </span>
                    <span class="task-small-card-status-text">
                        <?php echo e($deal_task_item['task_name']); ?>

                    </span>
                </span>
                <span class="task-small-card-date">
                  <span class="task-small-card-date-icon" style="color: <?php echo e($deal_task_item['task_color']); ?> !important;">
                    📆
                  </span>
                  <span class="task-small-card-date-text">
                     <?php echo e($deal_task_item['user_task_start_date_format']); ?> <?php echo e($deal_task_item['user_task_start_time']); ?>

                     <?php echo e($deal_task_item['user_task_end_date_format']); ?> <?php echo e($deal_task_item['user_task_end_time']); ?>

                  </span>
                </span>
            </div>
            <div>
                <p class="task-small-card-name my-2">
                    <?=nl2br($deal_task_item['user_task_text'])?>
                </p>
            </div>

            <div class="d-flex align-items-center justify-content-between">
                <span class="task-small-card-responsible">
                    <?php echo e($deal_task_item['user_surname']); ?> <?php echo e($deal_task_item['user_name']); ?>

                </span>
                <?php if($deal_task_item['user_task_task_id'] < 3): ?>
                    <a href="javascript:void(0)" onclick="completeDealTask(<?php echo e($deal_task_item['user_task_id']); ?>,this)" class="task-small-card-make" style="color: <?php echo e($deal_task_item['task_color']); ?> !important;">
                      <span>
                        Выполнить
                      </span>
                    </a>
                <?php endif; ?>
            </div>
        </div>
    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
<?php endif; ?>