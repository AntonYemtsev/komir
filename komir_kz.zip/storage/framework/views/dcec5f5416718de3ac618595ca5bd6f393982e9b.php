<?php $__env->startSection('content'); ?>
    <style>
        label.error, input.error, textarea.error, select.error{height: auto;}
        input.error, textarea.error, select.error{height: auto; border: 1px solid red;}
    </style>
    <div class="main-content-container container-fluid px-4">
        <!-- Page Header -->
        <!--Timeline-->
        <ul class="timeline pl-0 mt-3 mb-0" id="timeline">
            <li class="li deal-status-li1 <?php if($row['deal_status_id'] > 1): ?> complete <?php elseif($row['deal_status_id'] == 1): ?> current <?php endif; ?>">
                <div class="timestamp">
                </div>
                <div class="status" id="status1">
                    <p>Заявка</p>
                </div>
            </li>
            <li class="li deal-status-li2 <?php if($row['deal_status_id'] > 2): ?> complete <?php elseif($row['deal_status_id'] == 2): ?> current <?php endif; ?>">
                <div class="timestamp">
                </div>
                <div class="status" id="status2">
                    <p>Расчет КП</p>
                </div>
            </li>
            <li class="li deal-status-li3 <?php if($row['deal_status_id'] > 3): ?> complete <?php elseif($row['deal_status_id'] == 3): ?> current <?php endif; ?>">
                <div class="timestamp">
                </div>
                <div class="status" id="status3">
                    <p>Переговоры</p>
                </div>
            </li>
            <li class="li deal-status-li4 <?php if($row['deal_status_id'] > 4): ?> complete <?php elseif($row['deal_status_id'] == 4): ?> current <?php endif; ?>">
                <div class="timestamp">
                </div>
                <div class="status" id="status4">
                    <p>Договор</p>
                </div>
            </li>
            <li class="li deal-status-li5 <?php if($row['deal_status_id'] > 5): ?> complete <?php elseif($row['deal_status_id'] == 5): ?> current <?php endif; ?>">
                <div class="timestamp">
                </div>
                <div class="status" id="status5">
                    <p>Счет на оплату</p>
                </div>
            </li>
            <li class="li deal-status-li6 <?php if($row['deal_status_id'] > 6): ?> complete <?php elseif($row['deal_status_id'] == 6): ?> current <?php endif; ?>">
                <div class="timestamp">
                </div>
                <div class="status" id="status6">
                    <p>Заявка разрезу</p>
                </div>
            </li>
            <li class="li deal-status-li7 <?php if($row['deal_status_id'] > 7): ?> complete <?php elseif($row['deal_status_id'] == 7): ?> current <?php endif; ?>">
                <div class="timestamp">
                </div>
                <div class="status" id="status7">
                    <p>Оплата разрезу</p>
                </div>
            </li>
            <li class="li deal-status-li8 <?php if($row['deal_status_id'] > 8): ?> complete <?php elseif($row['deal_status_id'] == 8): ?> current <?php endif; ?>">
                <div class="timestamp">
                </div>
                <div class="status" id="status8">
                    <p>Отгрузка</p>
                </div>
            </li>
            <li class="li deal-status-li9 <?php if($row['deal_status_id'] > 9): ?> complete <?php elseif($row['deal_status_id'] == 9): ?> current <?php endif; ?>">
                <div class="timestamp">
                </div>
                <div class="status" id="status9">
                    <p>Доставка</p>
                </div>
            </li>
        </ul>
        <!--/Timeline-->
        <!--Main content-->
        <div class="deal-card-wrapper dragscroll">
            <div class="d-flex" style="width: auto">
                <div class="deal-card-single-wrapper" id="deal-card-1">
                    <div class="deal-card-single card card-small mb-4 pt-1">
                        <form id="deal-card-1-form" method="post">
                            <input type="hidden" name="_token" value="<?php echo e(csrf_token()); ?>">
                            <input type="hidden" value="<?php echo e($row['deal_id']); ?>" name="deal_id" class="deal-id-hidden">
                            <input type="hidden" value="1" name="deal_status_id">
                            <div class="card-header text-left">
                                <h5 class="mb-0">Заявка</h5>
                                <div class="d-flex flex-wrap no-gutters mt-2">
                                    <div class="col-12 col-sm-6">
                                        <span>ОТВЕТСТВЕННЫЙ</span>
                                        <select name="deal_user_id1" class="form-control">
                                            <option value="0">Выберите ответственного</option>
                                            <?php if(@count($user_list) > 0): ?>
                                                <?php $__currentLoopData = $user_list; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $user_item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                    <option value="<?php echo e($user_item['user_id']); ?>" <?php if($user_item['user_id'] == $row['deal_user_id1']): ?> selected <?php endif; ?>><?php echo e($user_item['user_surname']); ?> <?php echo e($user_item['user_name']); ?></option>
                                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                            <?php endif; ?>
                                        </select>
                                        <p id="deal-card-1-responsible"></p>
                                    </div>
                                    <div class="col-12 col-sm-6 text-sm-right">
                                        <span>ДАТА СОЗДАНИЯ</span>
                                        <p id="deal-card-1-date"><?php echo e($row['deal_datetime1_format']); ?></p>
                                    </div>
                                </div>
                                <div class="rounded col-12 mt-3 py-2" style="background-color: #EA5876"></div>
                            </div>
                            <div class="card-body">
                                <span onclick="addNewClient()">+ Добавить</span>
                                <span onclick="showClientSelectBlock()" style="float: right;">Выбрать из списка</span>
                                <div class="form-group flex-wrap align-items-center justify-content-between client-select-block" style="display: none;">
                                    <label for="deal-card-1-form-name">ФИО Клиента *</label>
                                    <select class="form-control" id="client_id_list" onchange="setClientInfo(this)">
                                        <option value="0">Выберите клиента</option>
                                        <?php if(@count($client_list) > 0): ?>
                                            <?php $__currentLoopData = $client_list; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $client_item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                <option value="<?php echo e($client_item['client_id']); ?>" data-client-id="<?php echo e($client_item['client_id']); ?>" data-client-email="<?php echo e($client_item['client_email']); ?>" data-client-phone="<?php echo e($client_item['client_phone']); ?>" data-client-fio="<?php echo e($client_item['client_surname']); ?> <?php echo e($client_item['client_name']); ?>"><?php echo e($client_item['client_surname']); ?> <?php echo e($client_item['client_name']); ?></option>
                                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                        <?php endif; ?>
                                    </select>
                                </div>
                                <div class="form-group d-flex flex-wrap align-items-center justify-content-between">
                                    <input type="hidden" name="deal_client_id" value="<?php echo e($row['deal_client_id']); ?>" id="deal_client_id">
                                    <label for="deal-card-1-form-name">Имя *</label>
                                    <input type="text" name="client_fio" id="deal-card-1-form-name" placeholder="" class="form-control deal-client-input" value="<?php echo e($row['client_surname']); ?> <?php echo e($row['client_name']); ?>" readonly="readonly">
                                </div>
                                <div class="form-group">
                                    <label for="deal-card-1-form-phone">Телефон *</label>
                                    <input type="text" name="client_phone" id="deal-card-1-form-phone" placeholder="" class="form-control deal-client-input" value="<?php echo e($row['client_phone']); ?>" readonly="readonly">
                                </div>
                                <div class="form-group">
                                    <label for="deal-card-1-form-email">Email</label>
                                    <input type="text" name="email" id="deal-card-1-form-email" placeholder="" class="form-control deal-client-input" value="<?php echo e($row['client_email']); ?>" readonly="readonly">
                                </div>
                                <button type="button" onclick="sendDealForm(1)" name="submit" id="deal-card-1-form-submit" class="mb-2 mt-2 btn btn-primary mr-2">Далее</button>
                            </div>
                        </form>
                    </div>
                </div>
                <div class="deal-card-single-wrapper" id="deal-card-2">
                    <div class="deal-card-single card card-small mb-4 pt-1">
                        <form id="deal-card-2-form" method="post">
                            <input type="hidden" name="_token" value="<?php echo e(csrf_token()); ?>">
                            <input type="hidden" value="<?php echo e($row['deal_id']); ?>" name="deal_id" class="deal-id-hidden">
                            <input type="hidden" value="2" name="deal_status_id">
                            <div class="card-header text-left">
                                <h5 class="mb-0">Расчет КП</h5>
                                <div class="d-flex flex-wrap no-gutters mt-2">
                                    <div class="col-12 col-sm-6">
                                        <span>ОТВЕТСТВЕННЫЙ</span>
                                        <select name="deal_user_id2" class="form-control" id="deal_user_id2">
                                            <option value="0">Выберите ответственного</option>
                                            <?php if(@count($user_list) > 0): ?>
                                                <?php $__currentLoopData = $user_list; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $user_item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                    <option value="<?php echo e($user_item['user_id']); ?>" <?php if($user_item['user_id'] == $row['deal_user_id2']): ?> selected <?php endif; ?>><?php echo e($user_item['user_surname']); ?> <?php echo e($user_item['user_name']); ?></option>
                                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                            <?php endif; ?>
                                        </select>
                                        <p id="deal-card-2-responsible"></p>
                                    </div>
                                    <div class="col-12 col-sm-6 text-sm-right">
                                        <span>ДАТА РАСЧЕТА</span>
                                        <p id="deal-card-2-date"><?php echo e($row['deal_datetime2_format']); ?></p>
                                    </div>
                                </div>
                                <div class="rounded col-12 mt-3 py-2" style="background-color: #00B8D8"></div>
                            </div>
                            <div class="card-body">

                                <div class="form-group">
                                    <label for="deal-card-2-form-brand">Разрез</label>
                                    <select id="deal-card-2-form-brand" class="form-control" name="deal_brand_id">
                                        <option value="0">Выберите разрез</option>
                                        <?php if(@count($brand_list) > 0): ?>
                                            <?php $__currentLoopData = $brand_list; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $brand_item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                <option value="<?php echo e($brand_item['brand_id']); ?>" <?php if($brand_item['brand_id'] == $row['deal_brand_id']): ?> selected <?php endif; ?>><?php echo e($brand_item['brand_name']); ?></option>
                                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                        <?php endif; ?>
                                    </select>
                                </div>
                                <div class="form-group">
                                    <label for="deal-card-2-form-mark">Марка</label>
                                    <select id="deal-card-2-form-mark" class="form-control" name="deal_mark_id">
                                        <option value="0">Выберите марку</option>
                                        <?php if(@count($mark_list) > 0): ?>
                                            <?php $__currentLoopData = $mark_list; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $mark_item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                <option value="<?php echo e($mark_item['mark_id']); ?>" <?php if($mark_item['mark_id'] == $row['deal_mark_id']): ?> selected <?php endif; ?>><?php echo e($mark_item['mark_name']); ?></option>
                                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                        <?php endif; ?>
                                    </select>
                                </div>
                                <div class="form-group">
                                    <label for="deal-card-2-form-fraction">Фракция</label>
                                    <select id="deal-card-2-form-fraction" class="form-control" name="deal_fraction_id">
                                        <option value="0">Выберите фракцию</option>
                                        <?php if(@count($fraction_list) > 0): ?>
                                            <?php $__currentLoopData = $fraction_list; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $fraction_item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                <option value="<?php echo e($fraction_item['fraction_id']); ?>" <?php if($fraction_item['fraction_id'] == $row['deal_fraction_id']): ?> selected <?php endif; ?>><?php echo e($fraction_item['fraction_name']); ?></option>
                                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                        <?php endif; ?>
                                    </select>
                                </div>
                                <div class="form-group">
                                    <label for="deal-card-2-form-volume">Объём в тоннах</label>
                                    <input type="text" name="deal_volume" id="deal-card-1-form-volume" placeholder="" class="form-control" value="<?php echo e($row['deal_volume']); ?>">
                                </div>
                                <div class="form-group">
                                    <label for="deal-card-2-form-region">Область</label>
                                    <select id="deal-card-2-form-region" class="form-control" name="deal_region_id">
                                        <option value="0">Выберите регион</option>
                                        <?php if(@count($region_list) > 0): ?>
                                            <?php $__currentLoopData = $region_list; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $region_item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                <option value="<?php echo e($region_item['region_id']); ?>" <?php if($region_item['region_id'] == $row['deal_region_id']): ?> selected <?php endif; ?>><?php echo e($region_item['region_name']); ?></option>
                                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                        <?php endif; ?>
                                    </select>
                                </div>
                                <div class="form-group">
                                    <label for="deal-card-2-form-station">Станция</label>
                                    <select id="deal-card-2-form-station" class="form-control" name="deal_station_id">
                                        <option value="0">Выберите станцию</option>
                                        <?php if(@count($station_list) > 0): ?>
                                            <?php $__currentLoopData = $station_list; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $station_item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                <option value="<?php echo e($station_item['station_id']); ?>" <?php if($station_item['station_id'] == $row['deal_station_id']): ?> selected <?php endif; ?>><?php echo e($station_item['station_name']); ?></option>
                                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                        <?php endif; ?>
                                    </select>
                                </div>
                                <button type="button" onclick="calculateDealSum()" name="submit" id="deal-card-2-form-submit" class="mb-2 mt-2 btn btn-primary mr-2">Рассчитать</button>
                                <div class="form-group">
                                    <label for="deal-card-2-price">Цена за 1 тонну + доставка + НДС</label>
                                    <input type="text" id="deal-card-2-price" placeholder="" class="form-control" value="<?php echo e($row['deal_kp_sum']); ?>" name="deal_kp_sum">
                                </div>
                                <button type="button" onclick="sendDealForm(2)" name="submit" id="deal-card-1-form-submit" class="mb-2 mt-2 btn btn-primary mr-2 process2-btn" <?php if($row['deal_kp_sum'] < 1): ?> style="display: none;" <?php endif; ?>>Далее</button>
                            </div>
                        </form>
                    </div>
                </div>
                <div class="deal-card-single-wrapper" id="deal-card-3">
                    <div class="deal-card-single card card-small mb-4 pt-1">
                        <form id="deal-card-3-form" class="mt-2" method="post">
                            <input type="hidden" name="_token" value="<?php echo e(csrf_token()); ?>">
                            <input type="hidden" value="<?php echo e($row['deal_id']); ?>" name="deal_id" class="deal-id-hidden">
                            <input type="hidden" value="3" name="deal_status_id">
                            <div class="card-header text-left">
                                <h5 class="mb-0">Переговоры</h5>
                                <div class="d-flex flex-wrap no-gutters mt-2">
                                    <div class="col-12 col-sm-5">
                                        <span>ОТВЕТСТВЕННЫЙ</span>
                                        <select name="deal_user_id3" class="form-control" id="deal_user_id3">
                                            <option value="0">Выберите ответственного</option>
                                            <?php if(@count($user_list) > 0): ?>
                                                <?php $__currentLoopData = $user_list; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $user_item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                    <option value="<?php echo e($user_item['user_id']); ?>" <?php if($user_item['user_id'] == $row['deal_user_id3']): ?> selected <?php endif; ?>><?php echo e($user_item['user_surname']); ?> <?php echo e($user_item['user_name']); ?></option>
                                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                            <?php endif; ?>
                                        </select>
                                        <p id="deal-card-3-responsible"></p>
                                    </div>
                                    <div class="col-12 col-sm-7 text-sm-right">
                                        <span>ДАТА ОТПРАВЛЕНИЯ</span>
                                        <p id="deal-card-3-date"><?php echo e($row['deal_datetime3_format']); ?></p>
                                    </div>
                                </div>
                                <div class="rounded col-12 mt-3 py-2" style="background-color: #313541"></div>
                            </div>
                            <div class="card-body">
                                <div class="deal-card-3-filebox">
                                    <label>Коммерческое предложение № 1</label>
                                    <div class="col-12 d-flex rounded border no-gutters py-2">
                                        <div class="col-9">
                                            <span id="deal-card-3-filebox-description">
                                              <strong>Разрез:</strong> <span class="brand-span-new"><?php echo e($row['brand_name']); ?></span><br>
                                                <strong>Марка:</strong> <span class="mark-span-new"><?php echo e($row['mark_name']); ?></span><br>
                                                <strong>Фракция:</strong> <span class="fraction-span-new"><?php echo e($row['fraction_name']); ?></span><br>
                                                <strong>Объем:</strong> <span class="deal-volume-span-new"><?php echo e($row['deal_volume']); ?> </span> тонн<br>
                                                <strong>Область:</strong> <span class="region-span-new"><?php echo e($row['region_name']); ?></span><br>
                                                <strong>Станция:</strong> <span class="station-span-new"><?php echo e($row['station_name']); ?></span><br>
                                                <strong>Цена:</strong> <span class="price-span-new"><?php echo e($row['deal_kp_sum']); ?></span>
                                            </span>
                                        </div>
                                        <div class="col-3">
                                            <img src="/admin/images/pdffile.svg">
                                        </div>
                                    </div>
                                    <div class="col-12 px-0 d-flex justify-content-between">
                                        <button type="button" id="deal-card-3-sendOffer" class="btn btn-outline-primary my-2" onclick="sendKpMail()">Отправить Email</button>
                                        <button type="button" id="deal-card-3-downloadOffer" class="btn btn-outline-primary my-2" onclick="downloadDealKp()">Скачать КП</button>
                                    </div>
                                </div>

                                <div class="form-group d-flex flex-wrap align-items-center justify-content-between">
                                    <label for="deal-card-3-form-answer">Ответ клиента</label>
                                    <span class="text-right" id="deal-card-3-form-date">22.10.2019 15:16</span>
                                    <textarea class="form-control" id="deal-card-3-form-answer" name="client_answer_text" rows="7"></textarea>
                                    <button type="button" onclick="addClientAnswer()" name="submit" class="mb-2 mt-2 btn btn-primary">Сохранить</button>
                                    <div class="client-answers-block"></div>
                                </div>
                                <div class="form-group d-flex flex-wrap align-items-center justify-content-between">
                                    <label for="deal-card-3-form-discount">Скидка</label>
                                    <div class="custom-control custom-toggle custom-toggle-sm mb-2">
                                        <input type="checkbox" id="deal-card-3-form-percents" name="deal_discount_type" class="custom-control-input" <?php if($row['deal_discount_type'] == 1): ?> checked="checked" <?php endif; ?>>
                                        <label class="custom-control-label" for="deal-card-3-form-percents">
                                            <font id="number">Число</font><font> / </font><font id="percent" style="color: #007bff; font-weight: bold;">Процент</font>
                                        </label>
                                    </div>
                                    <input type="text" id="deal-card-3-form-discount" name="deal_discount" placeholder="" class="form-control" value="<?php echo e($row['deal_discount']); ?>">
                                </div>
                                <div class="col-12 px-0 d-flex justify-content-between">
                                    <button type="button" onclick="sendDealForm(3)" name="submit" id="deal-card-3-form-submit" class="mb-2 mt-2 btn btn-primary">Далее</button>
                                    <button type="button" onclick="changeDealType(<?php echo e($row['deal_id']); ?>,2)" id="deal-card-3-form-reject" class="btn btn-danger my-2">Отказ клиента</button>
                                </div>
                            </div>
                        </form>
                    </div>
                </div>
                <div class="deal-card-single-wrapper" id="deal-card-4">
                    <div class="deal-card-single card card-small mb-4 pt-1">
                        <form id="deal-card-4-form" method="post">
                            <input type="hidden" name="_token" value="<?php echo e(csrf_token()); ?>">
                            <input type="hidden" value="<?php echo e($row['deal_id']); ?>" name="deal_id" class="deal-id-hidden">
                            <input type="hidden" value="4" name="deal_status_id">
                            <div class="card-header text-left">
                                <h5 class="mb-0">Договор</h5>
                                <div class="d-flex flex-wrap no-gutters mt-2">
                                    <div class="col-12 col-sm-5">
                                        <span>ОТВЕТСТВЕННЫЙ</span>
                                        <select name="deal_user_id4" class="form-control" id="deal_user_id4">
                                            <option value="0">Выберите ответственного</option>
                                            <?php if(@count($user_list) > 0): ?>
                                                <?php $__currentLoopData = $user_list; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $user_item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                    <option value="<?php echo e($user_item['user_id']); ?>" <?php if($user_item['user_id'] == $row['deal_user_id4']): ?> selected <?php endif; ?>><?php echo e($user_item['user_surname']); ?> <?php echo e($user_item['user_name']); ?></option>
                                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                            <?php endif; ?>
                                        </select>
                                        <p id="deal-card-4-responsible"></p>
                                    </div>
                                    <div class="col-12 col-sm-7 text-sm-right">
                                        <span>ДАТА ОТПРАВЛЕНИЯ</span>
                                        <p id="deal-card-4-date"><?php echo e($row['deal_datetime4_format']); ?></p>
                                    </div>
                                </div>
                                <div class="rounded col-12 mt-3 py-2" style="background-color: #674EEC"></div>
                            </div>
                            <div class="card-body">
                                <label class="deal-dogovor-sum">
                                    <?php if($row['deal_status_id'] == 4): ?>
                                        <?
                                        $discount_sum = $row['deal_discount'];
                                        if($row['deal_discount_type'] == 1){
                                            $discount_sum = $row['deal_kp_sum']*$row['deal_discount']/100;
                                        }
                                        ?>
                                        Сумма договора: <?php echo e($row['deal_kp_sum']-$discount_sum); ?>

                                    <?php endif; ?>
                                </label>
                                <div class="d-flex no-gutters">
                                    <div class="form-group col-6 pr-2">
                                        <label for="deal-card-4-form-paymentCond">Условия оплаты</label>
                                        <select name="deal_payment_id" id="deal-card-4-form-payment" class="form-control">
                                            <option value="0">Выберите условию оплаты</option>
                                            <?php if(@count($payment_list) > 0): ?>
                                                <?php $__currentLoopData = $payment_list; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $payment_item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                    <option value="<?php echo e($payment_item['payment_id']); ?>" <?php if($payment_item['payment_id'] == $row['deal_payment_id']): ?> selected <?php endif; ?>><?php echo e($payment_item['payment_name']); ?></option>
                                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                            <?php endif; ?>
                                        </select>
                                    </div>
                                    <div class="form-group col-6">
                                        <label for="deal-card-4-form-deliveryTime">Срок доставки</label>
                                        <select id="deal-card-4-form-deliveryTime" class="form-control" name="deal_delivery_id">
                                            <option value="0">Выберите срок доставки</option>
                                            <?php if(@count($delivery_list) > 0): ?>
                                                <?php $__currentLoopData = $delivery_list; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $delivery_item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                    <option value="<?php echo e($delivery_item['delivery_id']); ?>" <?php if($delivery_item['delivery_id'] == $row['deal_delivery_id']): ?> selected <?php endif; ?>><?php echo e($delivery_item['delivery_name']); ?></option>
                                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                            <?php endif; ?>
                                        </select>
                                    </div>
                                </div>

                                <span onclick="addNewCompany()">+ Добавить</span>
                                <span onclick="showCompanySelectBlock()" style="float: right;">Выбрать из списка</span>
                                <div class="form-group company-select-block" style="display: none;">
                                    <label for="deal-card-1-form-name">Компания *</label>
                                    <select class="form-control" id="company_id_list" onchange="setCompanyInfo()">
                                        <option value="0">Выберите компанию</option>
                                        <?
                                        use App\Models\Company;
                                        $company_list = Company::orderBy("company_name","asc")->get();
                                        ?>
                                        <?php if(@count($company_list) > 0): ?>
                                            <?php $__currentLoopData = $company_list; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $company_item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                <option value="<?php echo e($company_item['company_id']); ?>" data-company-id="<?php echo e($company_item['company_id']); ?>" data-company-name="<?php echo e($company_item['company_name']); ?>" data-company-address="<?php echo e($company_item['company_address']); ?>" data-company-bin="<?php echo e($company_item['company_bank_bin']); ?>"
                                                        data-company-bank-id="<?php echo e($company_item['company_bank_id']); ?>" data-company-iik="<?php echo e($company_item['company_bank_iik']); ?>" data-company-ceo-position="<?php echo e($company_item['company_ceo_position']); ?>"
                                                        data-company-ceo-name="<?php echo e($company_item['company_ceo_name']); ?>" data-company-delivery-address="<?php echo e($company_item['company_delivery_address']); ?>" data-company-okpo="<?php echo e($company_item['company_okpo']); ?>"><?php echo e($company_item['company_name']); ?></option>
                                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                        <?php endif; ?>
                                    </select>
                                </div>

                                <div class="form-group">
                                    <input type="hidden" name="company_id" value="<?php echo e($row['company_id']); ?>" id="company_id">
                                    <label for="deal-card-4-form-companyName">Наименование компании</label>
                                    <input type="text" name="company_name" id="deal-card-4-form-companyName" placeholder="" class="form-control deal-company-input ui-autocomplete-input" autocomplete="off" value="<?php echo e($row['company_name']); ?>" readonly="readonly">
                                </div>
                                <div class="form-group">
                                    <label for="deal-card-4-form-companyAddress">Юридический адрес</label>
                                    <input type="text" name="company_address" id="deal-card-4-form-companyAddress" placeholder="" class="form-control deal-company-input" value="<?php echo e($row['company_address']); ?>" readonly="readonly">
                                </div>
                                <div class="form-group">
                                    <label for="deal-card-4-form-companyAddress">Адрес доставки</label>
                                    <input type="text" name="company_delivery_address" id="deal-card-4-form-companyDeliveryAddress" placeholder="" class="form-control deal-company-input" value="<?php echo e($row['company_delivery_address']); ?>" readonly="readonly">
                                </div>
                                <div class="form-group">
                                    <label for="deal-card-4-form-companyAddress">ОКПО</label>
                                    <input type="text" name="company_okpo" id="deal-card-4-form-companyOkpo" placeholder="" class="form-control deal-company-input" value="<?php echo e($row['company_okpo']); ?>" readonly="readonly">
                                </div>
                                <div class="form-group">
                                    <label for="deal-card-4-form-bankBIN">БИН</label>
                                    <input type="text" name="company_bank_bin" id="deal-card-4-form-bankBIN" placeholder="" class="form-control deal-company-input" value="<?php echo e($row['company_bank_bin']); ?>" readonly="readonly">
                                </div>
                                <div class="form-group">
                                    <label for="deal-card-4-form-bank">Банк</label>
                                    <select id="deal-card-4-form-bank" class="form-control deal-company-input" name="company_bank_id" readonly="readonly">
                                        <option value="0">Выберите банк</option>
                                        <?php if(@count($bank_list) > 0): ?>
                                            <?php $__currentLoopData = $bank_list; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $bank_item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                <option value="<?php echo e($bank_item['bank_id']); ?>" <?php if($bank_item['bank_id'] == $row['company_bank_id']): ?> selected <?php endif; ?>><?php echo e($bank_item['bank_name']); ?></option>
                                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                        <?php endif; ?>
                                    </select>
                                </div>
                                <div class="form-group">
                                    <label for="deal-card-4-form-bankIIK">ИИК</label>
                                    <input type="text" name="company_bank_iik" id="deal-card-4-form-bankIIK" placeholder="" class="form-control deal-company-input" value="<?php echo e($row['company_bank_iik']); ?>" readonly="readonly">
                                </div>
                                <div class="form-group">
                                    <label for="deal-card-4-form-companyCEOPosition">Должность руководителя</label>
                                    <input type="text" name="company_ceo_position" id="deal-card-4-form-companyCEOPosition" placeholder="" class="form-control deal-company-input" value="<?php echo e($row['company_ceo_position']); ?>" readonly="readonly">
                                </div>
                                <div class="form-group">
                                    <label for="deal-card-4-form-companyCEOName">ФИО руководителя</label>
                                    <input type="text" name="company_ceo_name" id="deal-card-4-form-companyCEOName" placeholder="" class="form-control deal-company-input" value="<?php echo e($row['company_ceo_name']); ?>" readonly="readonly">
                                </div>
                                <div class="form-group d-flex flex-wrap align-items-center justify-content-between">
                                    <label for="deal-card-3-form-discount">Код получателя</label>
                                    <input type="text" id="deal-card-4-form-receiverCode" name="deal_receiver_code" placeholder="" class="form-control" value="<?php echo e($row['deal_receiver_code']); ?>">
                                </div>
                                <div class="col-12 px-0 d-flex justify-content-between">
                                    <button type="button" id="deal-card-4-downloadContract" class="mb-2 mt-2 btn btn-outline-primary">Скачать договор</button>
                                    <button type="button" id="deal-card-4-sendContract" class="btn btn-outline-primary my-2">Отправить</button>
                                </div>
                                <button type="button" onclick="sendDealForm(4)" name="submit" id="deal-card-4-form-submit" class="mb-2 mt-2 btn btn-primary mr-2">Далее</button>
                            </div>
                        </form>
                    </div>
                </div>
                <div class="deal-card-single-wrapper" id="deal-card-5">
                    <div class="deal-card-single card card-small mb-4 pt-1">
                        <div class="card-header text-left">
                            <h5 class="mb-0">Счет на оплату</h5>
                            <div class="d-flex flex-wrap no-gutters mt-2">
                                <div class="col-12 col-sm-5">
                                    <span>ОТВЕТСТВЕННЫЙ</span>
                                    <select class="form-control" onchange="setDealUser(5,this)">
                                        <option value="0">Выберите ответственного</option>
                                        <?php if(@count($user_list) > 0): ?>
                                            <?php $__currentLoopData = $user_list; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $user_item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                <option value="<?php echo e($user_item['user_id']); ?>" <?php if($user_item['user_id'] == $row['deal_user_id5']): ?> selected <?php endif; ?>><?php echo e($user_item['user_surname']); ?> <?php echo e($user_item['user_name']); ?></option>
                                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                        <?php endif; ?>
                                    </select>
                                    <p id="deal-card-5-responsible"></p>
                                </div>
                                <div class="col-12 col-sm-7 text-sm-right">
                                    <span>ДАТА ОТПРАВЛЕНИЯ</span>
                                    <p id="deal-card-5-date"><?php echo e($row['deal_datetime5_format']); ?></p>
                                </div>
                            </div>
                            <div class="rounded col-12 mt-3 py-2" style="background-color: #17C671"></div>
                        </div>
                        <div class="card-body">
                            <form id="deal-bill-form" method="post">
                                <input type="hidden" name="_token" value="<?php echo e(csrf_token()); ?>">
                                <input type="hidden" value="<?php echo e($row['deal_id']); ?>" name="deal_id" class="deal-id-hidden">
                                <div class="d-flex no-gutters">
                                    <div class="form-group col-6 pr-2">
                                        <label for="deal-card-5-form-billNumber">№ счета</label>
                                        <input type="text" name="deal_bill_num" id="deal-card-5-form-billNumber" placeholder="" class="form-control" value="">
                                    </div>
                                    <div class="form-group col-6">
                                        <label for="deal-card-5-form-sum">Сумма</label>
                                        <input type="text" name="deal_bill_sum" id="deal-card-5-form-sum" placeholder="" class="form-control" value="">
                                    </div>
                                </div>
                                <button onclick="createDealBill()" type="button" name="submit" id="deal-card-5-form-submit" class="mb-2 mt-2 btn btn-outline-primary mr-2">Создать счет</button>
                            </form>

                            <form id="deal-card-5-form" method="post">
                                <input type="hidden" name="_token" value="<?php echo e(csrf_token()); ?>">
                                <input type="hidden" value="<?php echo e($row['deal_id']); ?>" name="deal_id" class="deal-id-hidden">
                                <input type="hidden" value="5" name="deal_status_id">
                                <input type="hidden" value="<?php echo e($row['deal_user_id5']); ?>" id="deal_user_id5" name="deal_user_id5">
                                <div class="d-flex flex-wrap my-2 deal-bill-file-block"></div>
                                <button type="button" onclick="sendDealForm(5)" id="deal-card-5-next" class="mb-2 mt-2 btn btn-primary mr-2">Далее</button>
                            </form>
                        </div>
                    </div>
                </div>
                <div class="deal-card-single-wrapper" id="deal-card-6">
                    <div class="deal-card-single card card-small mb-4 pt-1">
                        <form id="deal-card-6-form" method="post">
                            <input type="hidden" name="_token" value="<?php echo e(csrf_token()); ?>">
                            <input type="hidden" value="<?php echo e($row['deal_id']); ?>" name="deal_id" class="deal-id-hidden">
                            <input type="hidden" value="6" name="deal_status_id">
                            <div class="card-header text-left">
                                <h5 class="mb-0">Заявка разрезу</h5>
                                <div class="d-flex flex-wrap no-gutters mt-2">
                                    <div class="col-12 col-sm-5">
                                        <span>ОТВЕТСТВЕННЫЙ</span>
                                        <select name="deal_user_id6" class="form-control">
                                            <option value="0">Выберите ответственного</option>
                                            <?php if(@count($user_list) > 0): ?>
                                                <?php $__currentLoopData = $user_list; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $user_item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                    <option value="<?php echo e($user_item['user_id']); ?>" <?php if($user_item['user_id'] == $row['deal_user_id6']): ?> selected <?php endif; ?>><?php echo e($user_item['user_surname']); ?> <?php echo e($user_item['user_name']); ?></option>
                                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                            <?php endif; ?>
                                        </select>
                                        <p id="deal-card-6-responsible"></p>
                                    </div>
                                    <div class="col-12 col-sm-7 text-sm-right">
                                        <span>ДАТА ОТПРАВЛЕНИЯ</span>
                                        <p id="deal-card-6-date"><?php echo e($row['deal_datetime6_format']); ?></p>
                                    </div>
                                </div>
                                <div class="rounded col-12 mt-3 py-2" style="background-color: #C4183C"></div>
                            </div>
                            <div class="card-body">
                                <div id="deal-card-6-consignee-block">
                                    <p class="deal-card-6-line-name">
                                        Грузополучатель
                                    </p>
                                    <p class="deal-card-6-line-value" id="deal-card-6-consignee">
                                        <?php echo e($row['company_name']); ?>

                                    </p>
                                </div>
                                <div id="deal-card-6-BIN-block">
                                    <p class="deal-card-6-line-name">
                                        БИН
                                    </p>
                                    <p class="deal-card-6-line-value" id="deal-card-6-BIN">
                                        <?php echo e($row['company_bank_bin']); ?>

                                    </p>
                                </div>
                                <div id="deal-card-6-station-block">
                                    <p class="deal-card-6-line-name">
                                        Станция
                                    </p>
                                    <p class="deal-card-6-line-value" id="deal-card-6-station">
                                        <?php echo e($row['station_name']); ?>

                                    </p>
                                </div>
                                <div id="deal-card-6-stationCode-block">
                                    <p class="deal-card-6-line-name">
                                        Код станции
                                    </p>
                                    <p class="deal-card-6-line-value" id="deal-card-6-stationCode">
                                        <?php echo e($row['station_code']); ?>

                                    </p>
                                </div>
                                <div id="deal-card-6-address-block">
                                    <p class="deal-card-6-line-name">
                                        Адрес
                                    </p>
                                    <p class="deal-card-6-line-value" id="deal-card-6-address">
                                        <?php echo e($row['company_delivery_address']); ?>

                                    </p>
                                </div>
                                <div id="deal-card-6-address-block">
                                    <p class="deal-card-6-line-name">
                                        ОКПО
                                    </p>
                                    <p class="deal-card-6-line-value" id="deal-card-6-okpo">
                                        <?php echo e($row['company_okpo']); ?>

                                    </p>
                                </div>
                                <div id="deal-card-6-receiverCode-block">
                                    <p class="deal-card-6-line-name">
                                        Код получателя (4-х значный)
                                    </p>
                                    <p class="deal-card-6-line-value" id="deal-card-6-receiverCode">
                                        <?php echo e($row['deal_receiver_code']); ?>

                                    </p>
                                </div>
                                <div id="deal-card-6-OKPO-block">
                                    <p class="deal-card-6-line-name">
                                        ОКПО
                                    </p>
                                    <p class="deal-card-6-line-value" id="deal-card-6-OKPO">
                                        03150869
                                    </p>
                                </div>
                                <div id="deal-card-6-quantity-block">
                                    <p class="deal-card-6-line-name">
                                        Количество п/в
                                    </p>
                                    <p class="deal-card-6-line-value" id="deal-card-6-quantity">
                                        <?php echo e(ceil($row['deal_volume']/70)); ?>

                                    </p>
                                </div>
                                <div id="deal-card-6-fraction-block">
                                    <p class="deal-card-6-line-name">
                                        Фракция
                                    </p>
                                    <p class="deal-card-6-line-value" id="deal-card-6-fraction">
                                        <?php echo e($row['fraction_name']); ?>

                                    </p>
                                </div>
                                <button type="button" onclick="sendDealForm(6)" id="deal-card-6-next" class="mb-2 mt-4 btn btn-primary mr-2">Отправить разрезу</button>
                            </div>
                        </form>
                    </div>
                </div>
                <div class="deal-card-single-wrapper" id="deal-card-7">
                    <div class="deal-card-single card card-small mb-4 pt-1">
                        <div class="card-header text-left">
                            <h5 class="mb-0">Оплата разрезу</h5>
                            <div class="d-flex flex-wrap no-gutters mt-2">
                                <div class="col-12 col-sm-5">
                                    <span>ОТВЕТСТВЕННЫЙ</span>
                                    <select class="form-control" onchange="setDealUser(7,this)">
                                        <option value="0">Выберите ответственного</option>
                                        <?php if(@count($user_list) > 0): ?>
                                            <?php $__currentLoopData = $user_list; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $user_item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                <option value="<?php echo e($user_item['user_id']); ?>" <?php if($user_item['user_id'] == $row['deal_user_id7']): ?> selected <?php endif; ?>><?php echo e($user_item['user_surname']); ?> <?php echo e($user_item['user_name']); ?></option>
                                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                        <?php endif; ?>
                                    </select>
                                    <p id="deal-card-7-responsible"></p>
                                </div>
                                <div class="col-12 col-sm-7 text-sm-right">
                                    <span>ДАТА ОТПРАВЛЕНИЯ</span>
                                    <p id="deal-card-7-date"><?php echo e($row['deal_datetime7_format']); ?></p>
                                </div>
                            </div>
                            <div class="rounded col-12 mt-3 py-2" style="background-color: #F7B422"></div>
                        </div>
                        <div class="card-body">
                            <form id="deal-card-7-file-form" method="post" enctype="multipart/form-data">
                                <input type="hidden" name="_token" value="<?php echo e(csrf_token()); ?>">
                                <input type="hidden" value="<?php echo e($row['deal_id']); ?>" name="deal_id" class="deal-id-hidden">
                                <input type="hidden" value="4" name="deal_file_type">
                                <div class="d-flex no-gutters">
                                    <div class="form-group col-12">
                                        <div class="custom-file my-2">
                                            <input type="file" class="custom-file-input" id="brand_deal_file_src" name="brand_deal_file_src">
                                            <label class="custom-file-label" for="deal-card-7-file"></label>
                                        </div>
                                    </div>
                                </div>
                                <div class="deal-brand-files-block">
                                    <?php if(@count($deal_brand_files) > 0 ): ?>
                                        <?php $__currentLoopData = $deal_brand_files; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $deal_brand_item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                            <div class="d-flex flex-wrap no-gutters align-items-center justify-content-between deal-brand-file-item" id="deal-card-7-bill1">
                                                <div class="col-2">
                                                    <img src="/admin/images/file-icon.svg">
                                                </div>
                                                <div class="col-10">
                                                    <a href="/deal_files/<?php echo e($deal_brand_item['deal_file_src']); ?>" target="_blank">
                                                        <p class="deal-card-5-bill-name" id="deal-card-7-bill1-name"><?php echo e($deal_brand_item['deal_file_name']); ?></p>
                                                        <p class="deal-card-5-bill-date" id="deal-card-7-bill1-date"><?php echo e($deal_brand_item['deal_file_date_format']); ?></p>
                                                    </a>
                                                    <button onclick="deleteDealBrandFile(<?php echo e($deal_brand_item['deal_file_id']); ?>,<?php echo e($deal_brand_item['deal_file_deal_id']); ?>,this)" type="button" class="mb-2 btn btn-sm btn-outline-primary mr-1 delete-btn">Удалить</button>
                                                </div>
                                            </div>
                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                    <?php endif; ?>
                                </div>
                            </form>
                            <form id="deal-card-7-form" method="post">
                                <input type="hidden" name="_token" value="<?php echo e(csrf_token()); ?>">
                                <input type="hidden" value="<?php echo e($row['deal_id']); ?>" name="deal_id" class="deal-id-hidden">
                                <input type="hidden" value="7" name="deal_status_id">
                                <input type="hidden" value="<?php echo e($row['deal_user_id7']); ?>" id="deal_user_id7" name="deal_user_id7">
                                <div class="form-group">
                                    <label for="deal-card-7-form-sum">Сумма оплаты</label>
                                    <input type="text" name="deal_brand_sum" id="deal-card-7-form-sum" placeholder="" class="form-control" value="<?php echo e($row['deal_brand_sum']); ?>">
                                </div>
                                <button type="button" onclick="sendDealForm(7)" name="submit" id="deal-card-7-form-submit" class="mb-2 mt-2 btn btn-primary mr-2">Далее</button>
                            </form>
                        </div>
                    </div>
                </div>
                <div class="deal-card-single-wrapper" id="deal-card-8">
                    <div class="deal-card-single card card-small mb-4 pt-1">
                        <form id="deal-card-8-form" method="post">
                            <input type="hidden" name="_token" value="<?php echo e(csrf_token()); ?>">
                            <input type="hidden" value="<?php echo e($row['deal_id']); ?>" name="deal_id" class="deal-id-hidden">
                            <input type="hidden" value="8" name="deal_status_id">
                            <div class="card-header text-left">
                                <h5 class="mb-0">Отгрузка</h5>
                                <div class="d-flex flex-wrap no-gutters mt-2">
                                    <div class="col-12 col-sm-5">
                                        <span>ОТВЕТСТВЕННЫЙ</span>
                                        <select name="deal_user_id8" class="form-control" id="deal_user_id8">
                                            <option value="0">Выберите ответственного</option>
                                            <?php if(@count($user_list) > 0): ?>
                                                <?php $__currentLoopData = $user_list; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $user_item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                    <option value="<?php echo e($user_item['user_id']); ?>" <?php if($user_item['user_id'] == $row['deal_user_id8']): ?> selected <?php endif; ?>><?php echo e($user_item['user_surname']); ?> <?php echo e($user_item['user_name']); ?></option>
                                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                            <?php endif; ?>
                                        </select>
                                        <p id="deal-card-8-responsible"></p>
                                    </div>
                                    <div class="col-12 col-sm-7 text-sm-right">
                                        <span>ДАТА ОТПРАВЛЕНИЯ</span>
                                        <p id="deal-card-8-date"><?php echo e($row['deal_datetime8_format']); ?></p>
                                    </div>
                                </div>
                                <div class="rounded col-12 mt-3 py-2" style="background-color: #A8AEB4"></div>
                            </div>
                            <div class="card-body">
                                <div class="d-flex no-gutters">
                                    <div class="form-group col-6 pr-2">
                                        <div id="blog-overview-date-range" class="input-daterange input-group input-group-sm my-auto ml-auto mr-auto ml-sm-auto mr-sm-0" style="max-width: 350px;">
                                            <label for="blog-overview-date-range-1" class="col-12 pl-0">Дата отгрузки</label>
                                            <input type="text" class="input-sm form-control rounded" name="deal_shipping_date" placeholder="01/01/2019" value="<?php echo e($row['deal_shipping_date']); ?>" id="blog-overview-date-range-1" style="height: calc(2.09375rem + 2px)">
                                        </div>
                                    </div>
                                    <div class="form-group col-6">
                                        <label for="deal-card-8-form-time">Время</label>
                                        <input type="text" name="deal_shipping_time" id="deal-card-8-form-time" placeholder="" class="form-control" value="<?php echo e($row['deal_shipping_time']); ?>">
                                    </div>
                                </div>
                                <div class="form-group">
                                    <label for="deal-card-8-form-comment">Комментарий</label>
                                    <textarea class="form-control" id="deal-card-8-form-comment" name="shipping_comment_text" rows="7"></textarea>
                                    <button type="button" onclick="addShippingComment()" name="submit" class="mb-2 mt-2 btn btn-primary">Сохранить</button>

                                    <div class="shipping-comment-block"></div>
                                </div>
                                <button type="button" onclick="sendDealForm(8)" name="submit" id="deal-card-8-form-submit" class="mb-2 mt-2 btn btn-primary mr-2">Далее</button>
                            </div>
                        </form>
                    </div>
                </div>
                <div class="deal-card-single-wrapper" id="deal-card-9">
                    <div class="deal-card-single card card-small mb-4 pt-1">
                        <form id="deal-card-9-form" method="post">
                            <input type="hidden" name="_token" value="<?php echo e(csrf_token()); ?>">
                            <input type="hidden" value="<?php echo e($row['deal_id']); ?>" name="deal_id" class="deal-id-hidden">
                            <input type="hidden" value="9" name="deal_status_id">
                            <div class="card-header text-left">
                                <h5 class="mb-0">Доставка</h5>
                                <div class="d-flex flex-wrap no-gutters mt-2">
                                    <div class="col-12 col-sm-5">
                                        <span>ОТВЕТСТВЕННЫЙ</span>
                                        <select name="deal_user_id9" class="form-control" id="deal_user_id9">
                                            <option value="0">Выберите ответственного</option>
                                            <?php if(@count($user_list) > 0): ?>
                                                <?php $__currentLoopData = $user_list; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $user_item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                    <option value="<?php echo e($user_item['user_id']); ?>" <?php if($user_item['user_id'] == $row['deal_user_id9']): ?> selected <?php endif; ?>><?php echo e($user_item['user_surname']); ?> <?php echo e($user_item['user_name']); ?></option>
                                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                            <?php endif; ?>
                                        </select>
                                        <p id="deal-card-9-responsible"></p>
                                    </div>
                                    <div class="col-12 col-sm-7 text-sm-right">
                                        <span>ДАТА ОТПРАВЛЕНИЯ</span>
                                        <p id="deal-card-9-date"><?php echo e($row['deal_datetime9_format']); ?></p>
                                    </div>
                                </div>
                                <div class="rounded col-12 mt-3 py-2" style="background-color: #B3D7FF"></div>
                            </div>
                            <div class="card-body">
                                <div class="d-flex no-gutters">
                                    <div class="form-group col-6 pr-2">
                                        <div id="blog-overview-date-range-2" class="input-daterange input-group input-group-sm my-auto ml-auto mr-auto ml-sm-auto mr-sm-0" style="max-width: 350px;">
                                            <label for="blog-overview-date-range-2-1" class="col-12 pl-0">Дата отгрузки</label>
                                            <input type="text" class="input-sm form-control rounded" name="deal_delivery_date" placeholder="01/01/2019" id="blog-overview-date-range-2-1" style="height: calc(2.09375rem + 2px)" value="<?php echo e($row['deal_delivery_date']); ?>">
                                        </div>
                                    </div>
                                    <div class="form-group col-6">
                                        <label for="deal-card-9-form-time">Время</label>
                                        <input type="text" name="deal_delivery_time" id="deal-card-9-form-time" placeholder="" class="form-control" value="<?php echo e($row['deal_delivery_time']); ?>">
                                    </div>
                                </div>
                                <div class="form-group">
                                    <label for="deal-card-9-form-comment">Комментарий</label>
                                    <textarea class="form-control" id="deal-card-9-form-comment" name="delivery_comment_text" rows="7"></textarea>
                                    <button type="button" onclick="addDeliveryComment()" name="submit" class="mb-2 mt-2 btn btn-primary">Сохранить</button>

                                    <div class="delivery-comment-block"></div>
                                </div>
                                <button type="button" onclick="sendDealForm(9)" name="submit" id="deal-card-9-form-submit" class="mb-2 mt-2 btn btn-primary mr-2">Завершить</button>
                            </div>
                        </form>
                    </div>
                </div>




            </div>
        </div>
        <!-- /Main content -->
        <div class="col-12 px-0">
            <div class="col-12 px-0 d-flex flex-wrap justify-content-between py-4">
                <div class="col-12 col-sm-6">
                    <div class="card card-small">
                        <div class="d-flex flex-wrap">
                            <div class="col-12 col-sm-6">
                                <div class="card-header px-0 pb-0 text-left">
                                    <h5 class="mb-0">Задачи</h5>
                                </div>
                                <div class="card-body px-0">
                                    <form id="deal-tasks-form" method="post">
                                        <input type="hidden" name="_token" value="<?php echo e(csrf_token()); ?>">
                                        <input type="hidden" value="<?php echo e($row['deal_id']); ?>" name="deal_id" class="deal-id-hidden">
                                        <div class="form-group">
                                            <select id="deal-tasks-form-responsible" class="form-control" name="user_task_user_id">
                                                <option value="0">Выберите исполнителя</option>
                                                <?php if(@count($user_list) > 0): ?>
                                                    <?php $__currentLoopData = $user_list; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $user_item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                        <option value="<?php echo e($user_item['user_id']); ?>"><?php echo e($user_item['user_surname']); ?> <?php echo e($user_item['user_name']); ?></option>
                                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                                <?php endif; ?>
                                            </select>
                                        </div>
                                        <div class="d-flex no-gutters">
                                            <div class="form-group col-6 pr-2">
                                                <div id="blog-overview-date-range" class="input-daterange input-group input-group-sm my-auto ml-auto mr-auto ml-sm-auto mr-sm-0" style="max-width: 350px;">
                                                    <label for="blog-overview-date-range-1" class="col-12 pl-0">Дата начала</label>
                                                    <input type="text" class="input-sm form-control rounded" name="user_task_start_date" placeholder="01/01/2019" id="blog-overview-date-range-1" style="height: calc(2.09375rem + 2px)">
                                                </div>
                                            </div>
                                            <div class="form-group col-6">
                                                <label for="deal-card-8-form-time">Время начала</label>
                                                <input type="text" name="user_task_start_time" placeholder="" class="form-control">
                                            </div>
                                        </div>

                                        <div class="d-flex no-gutters">
                                            <div class="form-group col-6 pr-2">
                                                <div id="blog-overview-date-range" class="input-daterange input-group input-group-sm my-auto ml-auto mr-auto ml-sm-auto mr-sm-0" style="max-width: 350px;">
                                                    <label for="blog-overview-date-range-1" class="col-12 pl-0">Дата завершения</label>
                                                    <input type="text" class="input-sm form-control rounded" name="user_task_end_date" placeholder="01/01/2019" id="blog-overview-date-range-1" style="height: calc(2.09375rem + 2px)">
                                                </div>
                                            </div>
                                            <div class="form-group col-6">
                                                <label for="deal-card-8-form-time">Время завершения</label>
                                                <input type="text" name="user_task_end_time" placeholder="" class="form-control">
                                            </div>
                                        </div>

                                        <div class="form-group">
                                            <textarea class="form-control" id="deal-tasks-form-comment" name="user_task_text" rows="4"></textarea>
                                        </div>
                                        <button type="button" onclick="saveNewUserTask()" name="submit" id="deal-tasks-form-submit" class="mb-2 mt-2 btn btn-primary mr-2">Поставить</button>
                                    </form>
                                </div>
                            </div>
                            <div class="col-12 col-sm-6 py-4 task-small-card-block">

                            </div>

                        </div>
                    </div>
                </div>
                <div class="col-12 col-sm-3">
                    <div class="card card-small">
                        <div class="card-header pb-0">
                            <h5 class="mb-0">История</h5>
                        </div>
                        <div class="card-body deal-history-block"></div>
                    </div>
                </div>
                <div class="col-12 col-sm-3">
                    <div class="card card-small">
                        <div class="card-header pb-0">
                            <h5 class="mb-0">Документы</h5>
                        </div>
                        <div class="card-body">
                            <!-- <form class="dropzone" id="my-awesome-dropzone">
                              <div class="fallback">
                                <input name="file" type="file" multiple />
                              </div>
                            </form> -->

                            <!--begin form choose video upload-->
                            <main class="col s12">
                                <!--teste dropzone com preview-->
                                <div class="row">
                                    <div class="">
                                        <!-- Uploader Dropzone -->
                                        <form action="" id="zdrop" class="fileuploader center-align" enctype="multipart/form-data">
                                            <input type="hidden" name="_token" value="<?php echo e(csrf_token()); ?>">
                                            <input type="hidden" value="<?php echo e($row['deal_id']); ?>" name="deal_id" class="deal-id-hidden">
                                            <input type="hidden" value="5" name="deal_file_type">
                                            <div id="upload-label" style="width: 200px;">
                                                <i class="material-icons">cloud_upload</i>
                                            </div>
                                            <span class="tittle">Перетащите файл сюда или нажмите для загрузки</span>
                                        </form>

                                        <div class="deal-other-files-block">
                                            <?php if(@count($deal_other_files) > 0 ): ?>
                                                <?php $__currentLoopData = $deal_other_files; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $deal_other_item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                    <div class="d-flex flex-wrap no-gutters align-items-center justify-content-between deal-other-file-item" id="deal-card-7-bill1">
                                                        <div class="col-2">
                                                            <img src="/admin/images/file-icon.svg">
                                                        </div>
                                                        <div class="col-10">
                                                            <a href="/deal_files/<?php echo e($deal_other_item['deal_file_src']); ?>" target="_blank">
                                                                <p class="deal-card-5-bill-name" id="deal-card-7-bill1-name"><?php echo e($deal_other_item['deal_file_name']); ?></p>
                                                                <p class="deal-card-5-bill-date" id="deal-card-7-bill1-date"><?php echo e($deal_other_item['deal_file_date_format']); ?></p>
                                                            </a>
                                                            <button onclick="deleteDealOtherFile(<?php echo e($deal_other_item['deal_file_id']); ?>,<?php echo e($deal_other_item['deal_file_deal_id']); ?>,this)" type="button" class="mb-2 btn btn-sm btn-outline-primary mr-1 delete-btn">Удалить</button>
                                                        </div>
                                                    </div>
                                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                            <?php endif; ?>
                                        </div>

                                        <!-- Preview collection of uploaded documents -->
                                        <div class="preview-container">
                                            <div class="collection card" id="previews">
                                                <div class="collection-item clearhack valign-wrapper item-template" id="zdrop-template">
                                                    <div class="left pv zdrop-info" data-dz-thumbnail>
                                                        <div>
                                                            <span data-dz-name></span> <span data-dz-size></span>
                                                        </div>
                                                        <div class="progress">
                                                            <div class="determinate" style="width:0" data-dz-uploadprogress></div>
                                                        </div>
                                                        <div class="dz-error-message"><span data-dz-errormessage></span></div>
                                                    </div>

                                                    <div class="secondary-content actions">
                                                        <a href="#!" data-dz-remove class="btn-floating ph red white-text waves-effect waves-light"><i class="material-icons white-text">clear</i></a>
                                                    </div>
                                                </div>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                            </main>


                        </div>
                    </div>
                </div>
            </div>
        </div>

        <div id="modal-shadow"></div>
        <div class="modal-window-clients rounded" id="modal-window-clients">
            <div class="card-body p-0 py-1 rounded text-center">
                <table class="table mb-0 clients-table">
                    <thead class="bg-light">
                    <tr>
                        <th scope="col" class="border-0">#</th>
                        <th scope="col" class="border-0">Компания</th>
                        <th scope="col" class="border-0">Клиент</th>
                        <th scope="col" class="border-0">Телефон</th>
                        <th scope="col" class="border-0">Email</th>
                        <th scope="col" class="border-0">БИН</th>
                        <th scope="col" class="border-0">Действия</th>
                    </tr>
                    </thead>
                    <tbody>
                    <tr>
                        <td>1</td>
                        <td>ТОО IBR TRADE</td>
                        <td>Кайрат Нуртас</td>
                        <td>77771113355</td>
                        <td>qwerty@mail.ru</td>
                        <td>123123123123</td>
                        <td>
                            <div class="clients-table__actions">
                                <div class="btn-group btn-group-sm">
                                    <button type="button" class="btn btn-white">
                                  <span class="text-light">
                                    <i class="material-icons">add_circle</i>
                                  </span> Добавить </button>
                                </div>
                            </div>
                        </td>
                    </tr>

                    </tbody>
                </table>
            </div>
        </div>
    </div>

    <div style="display: none" class="clone-deal-brand-file-item">
        <div class="d-flex flex-wrap no-gutters align-items-center justify-content-between" id="deal-card-7-bill1">
            <div class="col-2">
                <img src="/admin/images/file-icon.svg">
            </div>
            <div class="col-10">
                <a href="" target="_blank">
                    <p class="deal-card-5-bill-name" id="deal-card-7-bill1-name"></p>
                    <p class="deal-card-5-bill-date" id="deal-card-7-bill1-date"></p>
                </a>
                <button onclick="deleteDealBrandFile(0,0,this)" type="button" class="mb-2 btn btn-sm btn-outline-primary mr-1 delete-btn">Удалить</button>
            </div>
        </div>
    </div>

    <div style="display: none" class="clone-deal-other-file-item">
        <div class="d-flex flex-wrap no-gutters align-items-center justify-content-between" id="deal-card-7-bill1">
            <div class="col-2">
                <img src="/admin/images/file-icon.svg">
            </div>
            <div class="col-10">
                <a href="" target="_blank">
                    <p class="deal-card-5-bill-name" id="deal-card-7-bill1-name"></p>
                    <p class="deal-card-5-bill-date" id="deal-card-7-bill1-date"></p>
                </a>
                <button onclick="deleteDealOtherFile(0,0,this)" type="button" class="mb-2 btn btn-sm btn-outline-primary mr-1 delete-btn">Удалить</button>
            </div>
        </div>
    </div>


    <?php if($row['deal_id'] > 0): ?>
        <script>
            $(document).ready(function(){
                $(".task-small-card-block").empty();
                $(".task-small-card-block").load("/admin/load-deal-task/<?php echo e($row['deal_id']); ?>");
                $(".client-answers-block").load("/admin/load-client-answers/" + $(".deal-id-hidden").val());
                $(".shipping-comment-block").load("/admin/load-shipping-comment/" + $(".deal-id-hidden").val());
                $(".delivery-comment-block").load("/admin/load-delivery-comment/" + $(".deal-id-hidden").val());
                $(".deal-history-block").load("/admin/load-deal-history/" + $(".deal-id-hidden").val());
                $(".deal-bill-file-block").load("/admin/load-deal-bill-file/" + $(".deal-id-hidden").val());
            })
        </script>
    <?php endif; ?>

    <script>
        $(document).ready(function(){
            $("#brand_deal_file_src").on("change",function(event){
                event.preventDefault();

                //grab all form data
                var formData = new FormData($("#deal-card-7-file-form")[0]);

                $.ajax({
                    url:'/admin/upload-deal-file',
                    type: 'POST',
                    headers: {
                        'X-CSRF-TOKEN': $('meta[name="csrf-token"]').attr('content')
                    },
                    data: formData,
                    async: false,
                    cache: false,
                    contentType: false,
                    processData: false,
                    success: function (data) {
                        if(data.success == true){
                            alert("Ваш файл успешно загружен");
                            a = $(".clone-deal-brand-file-item").clone();
                            a.removeClass("clone-deal-brand-file-item");
                            a.addClass("deal-brand-file-item");
                            a.css("display","block");
                            a.find("a").attr("href","/deal_files/" + data.deal_file_src);
                            a.find("#deal-card-7-bill1-name").html(data.deal_file_name);
                            a.find("#deal-card-7-bill1-date").html(data.deal_file_date);
                            a.find(".delete-btn").attr("onclick","deleteDealBrandFile(" + data.deal_file_id + ", " + data.deal_file_deal_id + ",this)");
                            $(".deal-brand-files-block").append(a);
                        }
                        else if(data.success == "not_file"){
                            alert("Прикрепите файл");
                        }
                        else{
                            alert("Ошибка при загрузке файла");
                        }
                    }
                });
            });
        });

        $(document).ready(function(){
            $("#deal-card-1-form").validate({
                rules : {
                    client_fio : {required : true},
                    client_phone : {required : true},
                    email : {required : true, email: true},
                    deal_user_id1: {min:1}
                },
                messages:{
                    client_fio: {required : ""},
                    client_phone : {required : ""},
                    email : {required : "", email: true},
                    deal_user_id1: {min: ""}
                }
            });
            $("#deal-card-2-form").validate({
                rules : {
                    deal_user_id2: {min:1},
                    deal_volume: {required:true},
                    deal_kp_sum: {required:true},
                    deal_brand_id: {min:1},
                    deal_mark_id: {min:1},
                    deal_fraction_id: {min:1},
                    deal_region_id: {min:1},
                    deal_station_id: {min:1}
                },
                messages:{
                    deal_user_id2: {min: ""},
                    deal_volume: {required: ""},
                    deal_kp_sum: {required: ""},
                    deal_brand_id: {min: ""},
                    deal_mark_id: {min: ""},
                    deal_fraction_id: {min: ""},
                    deal_region_id: {min: ""},
                    deal_station_id: {min: ""}
                }
            });
            $("#deal-card-3-form").validate({
                rules : {
                    deal_user_id3: {min:1},
//                    deal_user_answer: {required:true},
                    deal_discount: {required:true}
                },
                messages:{
                    deal_user_id3: {min: ""},
//                    deal_user_answer: {required: ""},
                    deal_discount: {required: ""}
                }
            });
            $("#deal-card-4-form").validate({
                rules : {
                    deal_user_id4: {min:1},
                    deal_payment_id: {min:1},
                    deal_delivery_id: {min:1},
                    company_bank_id: {min:1},
                    company_name: {required:true},
                    company_address: {required:true},
                    company_bank_bin: {required:true},
                    company_bank_iik: {required:true},
                    company_ceo_position: {required:true},
                    company_ceo_name: {required:true},
                    deal_receiver_code: {required:true}
                },
                messages:{
                    deal_user_id4: {min: ""},
                    deal_payment_id: {min: ""},
                    deal_delivery_id: {min: ""},
                    company_bank_id: {min: ""},
                    company_name: {required: ""},
                    company_address: {required: ""},
                    company_bank_bin: {required: ""},
                    company_bank_iik: {required: ""},
                    company_ceo_position: {required: ""},
                    company_ceo_name: {required: ""},
                    deal_receiver_code: {required: ""}
                }
            });
            $("#deal-card-5-form").validate({
                rules : {
                    deal_user_id5: {min:1}
                },
                messages:{
                    deal_user_id5: {min: ""}
                }
            });
            $("#deal-card-6-form").validate({
                rules : {
                    deal_user_id6: {min:1}
                },
                messages:{
                    deal_user_id6: {min: ""}
                }
            });
            $("#deal-card-7-form").validate({
                rules : {
                    deal_user_id7: {min:1},
                    deal_brand_sum: {required:true}
                },
                messages:{
                    deal_user_id7: {min: ""},
                    deal_brand_sum: {required: ""}
                }
            });
            $("#deal-card-8-form").validate({
                rules : {
                    deal_user_id8: {min:1},
                    deal_shipping_date: {required:true},
                    deal_shipping_time: {required:true}
//                    deal_shipping_comment: {required:true}
                },
                messages:{
                    deal_user_id8: {min: ""},
                    deal_shipping_date: {required: ""},
                    deal_shipping_time: {required: ""}
//                    deal_shipping_comment: {required: true}
                }
            });
            $("#deal-card-9-form").validate({
                rules : {
                    deal_user_id9: {min:1},
                    deal_delivery_date: {required:true},
                    deal_delivery_time: {required:true}
//                    deal_delivery_comment: {required:true}
                },
                messages:{
                    deal_user_id9: {min: ""},
                    deal_delivery_date: {required: ""},
                    deal_delivery_time: {required: ""}
//                    deal_delivery_comment: {required: true}
                }
            });
            $("#deal-bill-form").validate({
                rules : {
                    deal_bill_num: {required:true},
                    deal_bill_sum: {required:true}
                },
                messages:{
                    deal_bill_num: {required: ""},
                    deal_bill_sum: {required: ""}
                }
            });
        });

        function sendDealForm(deal_form_id){
            if (!$("#deal-card-" + deal_form_id + "-form").valid()){
                return false;
            }

            $.ajax({
                type: 'POST',
                url: "/admin/save-deal-info",
                data: $("#deal-card-" + deal_form_id + "-form").serialize(),
                success: function(data){
                    if(data.result == false){
                        alert("Ошибка при сохранение данных формы");
                    }
                    else if(data.result == "incorrect_status"){
                        alert("Текущая форма недоступна");
                    }
                    else if(data.result == "error_save_brand_file"){
                        alert("Ошибка при формировании файла разрезу");
                    }
                    else if(data.result == "error_send_brand_mail"){
                        alert("Ошибка при отправки email разрезу");
                    }
                    else{
                        if(data.deal_row['deal_type_id'] == 1){
                            alert("Сделка успешно завершена");
                            window.location.href = "/admin/deal-list?type=list";
                        }
                        else{
                            current_status = data.deal_row['deal_status_id'];
                            prev_status = current_status - 1;

                            alert("Данные успешно сохранены");
                            if(deal_form_id == 1){
                                var obj = { Title: 'Komir.kz | Личный кабинет', Url: '/admin/deal-edit/' + data.deal_row['deal_id'] };
                                history.pushState(obj, obj.Title, obj.Url);

                                $(".client-select-block").fadeOut();
                                $(".deal-client-input").attr("readonly",true);
                            }
                            else if(deal_form_id == 2){
                                $(".brand-span-new").html(data.deal_row['brand_name']);
                                $(".mark-span-new").html(data.deal_row['mark_name']);
                                $(".fraction-span-new").html(data.deal_row['fraction_name']);
                                $(".deal-volume-span-new").html(data.deal_row['deal_volume']);
                                $(".region-span-new").html(data.deal_row['region_name']);
                                $(".station-span-new").html(data.deal_row['station_name']);
                                $(".price-span-new").html(data.deal_row['deal_kp_sum']);
                            }
                            else if(deal_form_id == 3){
                                discount_sum = data.deal_row['deal_discount'];
                                if(data.deal_row['deal_discount_type'] == 1){
                                    discount_sum = data.deal_row['deal_kp_sum']*data.deal_row['deal_discount']/100;
                                }
                                kp_sum = data.deal_row['deal_kp_sum'] - discount_sum;
                                $(".deal-dogovor-sum").html("Сумма договора: " + kp_sum);
                            }
                            else if(deal_form_id == 4){
                                $(".company-select-block").fadeOut();
                                $(".deal-company-input").attr("readonly",true);
                            }

                            $("#deal-card-6-consignee").html(data.deal_row['company_name']);
                            $("#deal-card-6-BIN").html(data.deal_row['company_bank_bin']);
                            $("#deal-card-6-station").html(data.deal_row['station_name']);
                            $("#deal-card-6-stationCode").html(data.deal_row['station_code']);
                            $("#deal-card-6-address").html(data.deal_row['company_delivery_address']);
                            $("#deal-card-6-okpo").html(data.deal_row['company_okpo']);
                            $("#deal-card-6-receiverCode").html(data.deal_row['deal_receiver_code']);
                            $("#deal-card-6-fraction").html(data.deal_row['fraction_name']);
                            $("#deal-card-6-quantity").html(Math.ceil(data.deal_row['deal_volume']/70));

                            $("#deal_user_id2").val(data.deal_row['deal_user_id2']);
                            $("#deal_user_id3").val(data.deal_row['deal_user_id3']);
                            $("#deal_user_id4").val(data.deal_row['deal_user_id4']);
                            $("#deal-card-1-date").html(data.deal_row['deal_datetime1_format']);
                            $("#deal-card-2-date").html(data.deal_row['deal_datetime2_format']);
                            $("#deal-card-3-date").html(data.deal_row['deal_datetime3_format']);
                            $("#deal-card-4-date").html(data.deal_row['deal_datetime4_format']);
                            $("#deal-card-5-date").html(data.deal_row['deal_datetime5_format']);
                            $("#deal-card-6-date").html(data.deal_row['deal_datetime6_format']);
                            $("#deal-card-7-date").html(data.deal_row['deal_datetime7_format']);
                            $("#deal-card-8-date").html(data.deal_row['deal_datetime8_format']);
                            $(".deal-id-hidden").val(data.deal_row['deal_id']);
                            $(".deal-status-li" + prev_status).removeClass("current").addClass("complete");
                            $(".deal-status-li" + data.deal_row['deal_status_id']).addClass("current");
                            $(".task-small-card-block").empty();
                            $(".task-small-card-block").load("/admin/load-deal-task/" + data.deal_row['deal_id']);
                            $(".deal-history-block").empty();
                            $(".deal-history-block").load("/admin/load-deal-history/" + $(".deal-id-hidden").val());
//                            window.location.href = "/admin/deal-edit/" + data.deal_id;
                        }
                    }
                }
            });
        }

        function calculateDealSum(){
            if($("#deal-card-2-form-station").val() > 0 && $("#deal-card-2-form-region").val() > 0){

                $.ajax({
                    type: 'GET',
                    url: "/admin/calculate-deal-kp-sum",
                    data: {_token: CSRF_TOKEN, station_id: $("#deal-card-2-form-station").val(), deal_volume: $("#deal-card-1-form-volume").val(), region_id: $("#deal-card-2-form-region").val()},
                    success: function(data){
                        if(data.result == false){
                            alert("Ошибка при получении данных об станции");
                        }
                        else{
                            $("#deal-card-2-price").val(data.sum);
                            $(".process2-btn").fadeIn();
                        }
                    }
                });
            }
            else{
                alert("Выберите станцию и регион");
            }
        }

        function changeDealType(deal_id, deal_type_id){
            if (!confirm('Вы действительно хотите отметить сделку как "Отказ клиента"?')) {
                return false;
            }

            $.ajax({
                type: 'POST',
                url: "/admin/change-deal-type",
                data: {_token: CSRF_TOKEN, deal_id:deal_id, deal_type_id: deal_type_id},
                success: function(data){
                    if(data.result == false){
                        alert("Ошибка при изменении статуса сделки");
                    }
                    else if(data.result == "incorrect_status"){
                        alert("Отказ клиента недоступна в текущем статусе");
                    }
                    else{
                        alert("Статус успешно изменен на 'Отказ клиента'");
                        window.location.href = "/admin/deal-list?type=list";
                    }
                }
            });
        }

        function setDealUser(deal_user_num,ob){
            $("#deal_user_id" +deal_user_num).val($(ob).val());
        }

        function saveNewUserTask(){
            $.ajax({
                type: 'POST',
                url: "/admin/save-new-user-task",
                data: $("#deal-tasks-form").serialize(),
                success: function(data){
                    if(data.result == false){
                        alert("Ошибка при сохранении новой задачи");
                    }
                    else if(data.result == "error_user"){
                        alert("Ответственный не найден в базе");
                    }
                    else if(data.result == "error_sending_mail"){
                        alert("Ошибка при отправке письмо напоминание о задаче");
                    }
                    else if(data.result == "incorrect_date"){
                        alert("Дата задачи неверно указаны");
                    }
                    else{
                        document.getElementById("deal-tasks-form").reset();
                        $(".task-small-card-block").empty();
                        $(".task-small-card-block").load("/admin/load-deal-task/<?php echo e($row['deal_id']); ?>");
                    }
                }
            });
        }

        function completeDealTask(user_task_id,ob){
            if (!confirm('Вы действительно хотите выполнить эту задачу?')) {
                return false;
            }

            $.ajax({
                type: 'POST',
                url: "/admin/complete-user-task",
                data: {_token: CSRF_TOKEN, user_task_id: user_task_id},
                success: function(data){
                    if(data.result == false){
                        alert("Ошибка при завершении задачи");
                    }
                    else{
                        $(".task-small-card-block").empty();
                        $(".task-small-card-block").load("/admin/load-deal-task/<?php echo e($row['deal_id']); ?>");
                    }
                }
            });
        }

        function addNewClient(){
            $(".client-select-block").css("display","none");
            $("#client_id_list").val(0);
            $("#deal_client_id").val(0);
            $(".deal-client-input").val("");
            $(".deal-client-input").attr("readonly",false);
        }

        function setClientInfo(){
            client_fio = $( "#client_id_list option:selected" ).data("client-fio");
            client_id = $( "#client_id_list option:selected" ).data("client-id");
            client_email = $( "#client_id_list option:selected" ).data("client-email");
            client_phone = $( "#client_id_list option:selected" ).data("client-phone");
            $("#deal_client_id").val(client_id);
            $("#deal-card-1-form-name").val(client_fio);
            $("#deal-card-1-form-phone").val(client_phone);
            $("#deal-card-1-form-email").val(client_email);

        }

        function showClientSelectBlock(){
            $("#client_id_list").val(0);
            $(".client-select-block").fadeIn();
            $(".deal-client-input").attr("readonly",true);
        }

        function addNewCompany(){
            $(".company-select-block").css("display","none");
            $("#company_id_list").val(0);
            $("#company_id").val(0);
            $(".deal-company-input").val("");
            $("#deal-card-4-form-bank").val(0);
            $(".deal-company-input").attr("readonly",false);
        }

        function setCompanyInfo(){
            company_id = $( "#company_id_list option:selected" ).data("company-id");
            company_name = $( "#company_id_list option:selected" ).data("company-name");
            company_address = $( "#company_id_list option:selected" ).data("company-address");
            company_bank_bin = $( "#company_id_list option:selected" ).data("company-bin");
            company_bank_id = $( "#company_id_list option:selected" ).data("company-bank-id");
            company_bank_iik = $( "#company_id_list option:selected" ).data("company-iik");
            company_ceo_position = $( "#company_id_list option:selected" ).data("company-ceo-position");
            company_ceo_name = $( "#company_id_list option:selected" ).data("company-ceo-name");
            company_delivery_address = $( "#company_id_list option:selected" ).data("company-delivery-address");
            company_okpo = $( "#company_id_list option:selected" ).data("company-okpo");
            $("#company_id").val(company_id);
            $("#deal-card-4-form-companyName").val(company_name);
            $("#deal-card-4-form-companyAddress").val(company_address);
            $("#deal-card-4-form-bankBIN").val(company_bank_bin);
            $("#deal-card-4-form-bank").val(company_bank_id);
            $("#deal-card-4-form-bankIIK").val(company_bank_iik);
            $("#deal-card-4-form-companyCEOPosition").val(company_ceo_position);
            $("#deal-card-4-form-companyCEOName").val(company_ceo_name);
            $("#deal-card-4-form-companyDeliveryAddress").val(company_delivery_address);
            $("#deal-card-4-form-companyOkpo").val(company_okpo);

        }

        function showCompanySelectBlock(){
            $("#company_id_list").val(0);
            $(".company-select-block").fadeIn();
            $(".deal-company-input").attr("readonly",true);
        }

        function addClientAnswer(){
            if($("#deal-card-3-form-answer").val().length < 1 || $("#deal_user_id3").val() < 1){
                alert("Заполните ответственного и ответ клиента");
                return false;
            }

            $.ajax({
                type: 'POST',
                url: "/admin/save-client-answer",
                data: $("#deal-card-3-form").serialize(),
                success: function(data){
                    if(data.result == false){
                        alert("Ошибка при сохранение ответа клиента");
                    }
                    else if(data.result == "incorrect_status"){
                        alert("Текущая форма недоступна");
                    }
                    else{
                        $("#deal-card-3-form-answer").val("");
                        $(".client-answers-block").load("/admin/load-client-answers/" + $(".deal-id-hidden").val());
                    }
                }
            });
        }

        function deleteClientAnswer(client_answer_id,ob){
            if (!confirm('Вы действительно хотите удалить ответ клиента?')) {
                return false;
            }

            $.ajax({
                type: 'GET',
                url: "/admin/delete-client-answer",
                data: {_token: CSRF_TOKEN, client_answer_id: client_answer_id},
                success: function(data){
                    if(data.result == false){
                        alert("Ошибка при удалении ответа клиента");
                    }
                    else{
                        $(ob).closest(".task-small-card").remove();
                    }
                }
            });
        }

        function addShippingComment(){
            if($("#deal-card-8-form-comment").val().length < 1 || $("#deal_user_id8").val() < 1){
                alert("Заполните ответственного и комментарию");
                return false;
            }

            $.ajax({
                type: 'POST',
                url: "/admin/save-shipping-comment",
                data: $("#deal-card-8-form").serialize(),
                success: function(data){
                    if(data.result == false){
                        alert("Ошибка при сохранение комментарии по отгрузке");
                    }
                    else if(data.result == "incorrect_status"){
                        alert("Текущая форма недоступна");
                    }
                    else{
                        $("#deal-card-8-form-comment").val("");
                        $(".shipping-comment-block").load("/admin/load-shipping-comment/" + $(".deal-id-hidden").val());
                    }
                }
            });
        }

        function deleteShippingComment(shipping_comment_id,ob){
            if (!confirm('Вы действительно хотите удалить комментарии отгрузки?')) {
                return false;
            }

            $.ajax({
                type: 'GET',
                url: "/admin/delete-shipping-comment",
                data: {_token: CSRF_TOKEN, shipping_comment_id: shipping_comment_id},
                success: function(data){
                    if(data.result == false){
                        alert("Ошибка при удалении комментарии отгрузки");
                    }
                    else{
                        $(ob).closest(".task-small-card").remove();
                    }
                }
            });
        }

        function addDeliveryComment(){
            if($("#deal-card-9-form-comment").val().length < 1 || $("#deal_user_id9").val() < 1){
                alert("Заполните ответственного и комментарию");
                return false;
            }

            $.ajax({
                type: 'POST',
                url: "/admin/save-delivery-comment",
                data: $("#deal-card-9-form").serialize(),
                success: function(data){
                    if(data.result == false){
                        alert("Ошибка при сохранение комментарии по доставке");
                    }
                    else if(data.result == "incorrect_status"){
                        alert("Текущая форма недоступна");
                    }
                    else{
                        $("#deal-card-9-form-comment").val("");
                        $(".delivery-comment-block").load("/admin/load-delivery-comment/" + $(".deal-id-hidden").val());
                    }
                }
            });
        }

        function deleteDeliveryComment(delivery_comment_id,ob){
            if (!confirm('Вы действительно хотите удалить комментарии доставки?')) {
                return false;
            }

            $.ajax({
                type: 'GET',
                url: "/admin/delete-delivery-comment",
                data: {_token: CSRF_TOKEN, delivery_comment_id: delivery_comment_id},
                success: function(data){
                    if(data.result == false){
                        alert("Ошибка при удалении комментарии доставки");
                    }
                    else{
                        $(ob).closest(".task-small-card").remove();
                    }
                }
            });
        }

        function downloadDealKp(){
            $.ajax({
                type: 'GET',
                url: "/admin/download-deal-kp",
                data: {_token: CSRF_TOKEN, deal_id: $(".deal-id-hidden").val()},
                success: function(data){
                    if(data.result['result'] == false){
                        alert("Ошибка при скачивании файла КП");
                    }
                    else{
                        window.open(data.result['filename']);
                    }
                }
            });
        }

        function sendKpMail(){
            $.ajax({
                type: 'GET',
                url: "/admin/send-kp-mail",
                data: {_token: CSRF_TOKEN, deal_id: $(".deal-id-hidden").val()},
                success: function(data){
                    if(data.result == false){
                        alert("Ошибка при отправки email");
                    }
                    else{
                        alert("Email успешно отправлен");
                    }
                }
            });
        }

        function createDealBill(){
            if (!$("#deal-bill-form").valid()){
                return false;
            }
            $.ajax({
                type: 'POST',
                url: "/admin/create-deal-bill-file",
                data: $("#deal-bill-form").serialize(),
                success: function(data){
                    if(data.result['result'] == false){
                        alert("Ошибка при создании счета");
                    }
                    else{
                        document.getElementById("deal-bill-form").reset();
                        $(".deal-bill-file-block").empty();
                        $(".deal-bill-file-block").load("/admin/load-deal-bill-file/" + $(".deal-id-hidden").val());
                    }
                }
            });
        }

        function sendDealBill(deal_file_id,deal_file_deal_id){
            $.ajax({
                type: 'GET',
                url: "/admin/send-bill-mail",
                data: {_token: CSRF_TOKEN, deal_file_deal_id: deal_file_deal_id, deal_file_id:deal_file_id},
                success: function(data){
                    if(data.result == false){
                        alert("Ошибка при отправки email");
                    }
                    else{
                        alert("Email успешно отправлен");
                    }
                }
            });
        }

        function deleteDealBill(deal_file_id,deal_file_deal_id){
            $.ajax({
                type: 'GET',
                url: "/admin/delete-deal-file",
                data: {_token: CSRF_TOKEN, deal_file_deal_id: deal_file_deal_id, deal_file_id:deal_file_id},
                success: function(data){
                    if(data.result == false){
                        alert("Ошибка при удалении счета на оплату");
                    }
                    else{
                        alert("Счет на оплату успешно удален");
                        $(".deal-bill-file-block").empty();
                        $(".deal-bill-file-block").load("/admin/load-deal-bill-file/" + $(".deal-id-hidden").val());
                    }
                }
            });
        }

        function deleteDealBrandFile(deal_file_id,deal_file_deal_id,ob){
            $.ajax({
                type: 'GET',
                url: "/admin/delete-deal-file",
                data: {_token: CSRF_TOKEN, deal_file_deal_id: deal_file_deal_id, deal_file_id:deal_file_id},
                success: function(data){
                    if(data.result == false){
                        alert("Ошибка при удалении файла разреза");
                    }
                    else{
                        alert("Файл разреза успешно удален");
                        $(ob).closest(".deal-brand-file-item").remove();
                    }
                }
            });
        }

        function deleteDealOtherFile(deal_file_id,deal_file_deal_id,ob){
            $.ajax({
                type: 'GET',
                url: "/admin/delete-deal-file",
                data: {_token: CSRF_TOKEN, deal_file_deal_id: deal_file_deal_id, deal_file_id:deal_file_id},
                success: function(data){
                    if(data.result == false){
                        alert("Ошибка при удалении документа");
                    }
                    else{
                        alert("Документ успешно удален");
                        $(ob).closest(".deal-other-file-item").remove();
                    }
                }
            });
        }
    </script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('admin.layout', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>