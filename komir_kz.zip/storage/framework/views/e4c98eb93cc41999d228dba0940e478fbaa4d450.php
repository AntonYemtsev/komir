<?php $__env->startSection('content'); ?>
    <div class="main-content-container container-fluid px-4">
        <!-- Page Header -->
        <div class="page-header row align-items-center no-gutters py-4">
            <div class="col-12 col-sm-2 d-flex text-center text-sm-left mb-0">
                
                <a class="change-view-type" href="/admin/deal-list?type=list">
                    <svg width="18" height="18" viewBox="0 0 31 31" fill="none" xmlns="http://www.w3.org/2000/svg">
                        <rect width="31" height="6" fill="#007BFF"/>
                        <rect width="31" height="6" fill="#007BFF"/>
                        <rect width="31" height="6" fill="#007BFF"/>
                        <rect y="12" width="31" height="7" fill="#007BFF"/>
                        <rect y="12" width="31" height="7" fill="#007BFF"/>
                        <rect y="12" width="31" height="7" fill="#007BFF"/>
                        <rect y="25" width="31" height="6" fill="#007BFF"/>
                        <rect y="25" width="31" height="6" fill="#007BFF"/>
                        <rect y="25" width="31" height="6" fill="#007BFF"/>
                    </svg>
                </a>
                <a class="change-view-type" href="/admin/deal-list?type=cards">
                    <svg width="18" height="18" viewBox="0 0 31 31" fill="none" xmlns="http://www.w3.org/2000/svg">
                        <rect x="30.9951" width="10" height="5.9991" transform="rotate(89.9917 30.9951 0)" fill="#007BFF"/>
                        <rect x="30.9951" width="10" height="5.9991" transform="rotate(89.9917 30.9951 0)" fill="#007BFF"/>
                        <rect x="30.9951" width="10" height="5.9991" transform="rotate(89.9917 30.9951 0)" fill="#979797"/>
                        <rect x="18.9971" y="0.00170898" width="20" height="6.99895" transform="rotate(89.9917 18.9971 0.00170898)" fill="#007BFF"/>
                        <rect x="18.9971" y="0.00170898" width="20" height="6.99895" transform="rotate(89.9917 18.9971 0.00170898)" fill="#007BFF"/>
                        <rect x="18.9971" y="0.00170898" width="20" height="6.99895" transform="rotate(89.9917 18.9971 0.00170898)" fill="#979797"/>
                        <rect x="5.99902" y="0.00366211" width="30.9956" height="5.9991" transform="rotate(89.9917 5.99902 0.00366211)" fill="#007BFF"/>
                        <rect x="5.99902" y="0.00366211" width="30.9956" height="5.9991" transform="rotate(89.9917 5.99902 0.00366211)" fill="#007BFF"/>
                        <rect x="5.99902" y="0.00366211" width="30.9956" height="5.9991" transform="rotate(89.9917 5.99902 0.00366211)" fill="#979797"/>
                    </svg>
                </a>
            </div>
            <div class="col-12 col-sm-7 d-flex text-center text-sm-left mb-0">
                <div class="col-6 col-sm-3">
                    <select id="deal_type_id_select" class="form-control" name="deal_type_id" onchange="searchByDeals()">
                        <option value="">Тип заявки</option>
                        <option value="0" <?php if(strlen($deal_type_id) > 0 && $deal_type_id == 0): ?> selected <?php endif; ?>>Активные</option>
                        <option value="1" <?php if($deal_type_id == 1): ?> selected <?php endif; ?>>Завершенные</option>
                        <option value="2" <?php if($deal_type_id == 2): ?> selected <?php endif; ?>>Отказанные</option>
                    </select>
                </div>
                <div class="col-6 col-sm-3">
                    <select id="client_id_select" class="form-control" name="user_id" onchange="searchByDeals()">
                        <option value="0">Клиент</option>
                        <?php if(@count($client_list) > 0): ?>
                            <?php $__currentLoopData = $client_list; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $client_item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <option value="<?php echo e($client_item['client_id']); ?>" <?php if($client_item['client_id'] == $client_id): ?> selected <?php endif; ?> ><?php echo e($client_item['client_surname']); ?> <?php echo e($client_item['client_name']); ?></option>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        <?php endif; ?>
                    </select>
                </div>
                <div class="col-6 col-sm-3">
                    <select id="status_id_select" class="form-control" name="status_id" onchange="searchByDeals()">
                        <option value="0">Статус</option>
                        <?php if(@count($status_list) > 0): ?>
                            <?php $__currentLoopData = $status_list; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $status_item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <option value="<?php echo e($status_item['status_id']); ?>" <?php if($status_item['status_id'] == $status_id): ?> selected <?php endif; ?> ><?php echo e($status_item['status_name']); ?></option>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        <?php endif; ?>
                    </select>
                </div>
                <div class="col-6 col-sm-3">
                    <select id="user_id_select" class="form-control" name="user_id" onchange="searchByDeals()">
                        <option value="0">Ответственный</option>
                        <?php if(@count($user_list) > 0): ?>
                            <?php $__currentLoopData = $user_list; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $user_item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <option value="<?php echo e($user_item['user_id']); ?>" <?php if($user_item['user_id'] == $user_id): ?> selected <?php endif; ?> ><?php echo e($user_item['user_surname']); ?> <?php echo e($user_item['user_name']); ?></option>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        <?php endif; ?>
                    </select>
                </div>
            </div>
            <div class="col-12 col-sm-3 text-center text-sm-left mb-0">
                <!-- DO NOT CHANGE IDs IN DATE PICKER -->
                <div id="blog-overview-date-range" class="input-daterange input-group input-group-sm my-auto ml-auto mr-auto ml-sm-auto mr-sm-0" style="max-width: 350px;">
                    <input type="text" class="input-sm form-control date_from_input" name="date_form" placeholder="01/01/2019" id="blog-overview-date-range-1" style="height: calc(2.09375rem + 2px)" value="<?php echo e($date_from); ?>" onchange="searchByDeals()">
                    <input type="text" class="input-sm form-control date_to_input" name="date_to" placeholder="02/01/2019" id="blog-overview-date-range-2" style="height: calc(2.09375rem + 2px)" value="<?php echo e($date_to); ?>" onchange="searchByDeals()">
                    <span class="input-group-append">
                    <span class="input-group-text" style="height: calc(2.09375rem + 2px)">
                      <i class="material-icons"></i>
                    </span>
                  </span>
                </div>
            </div>
        </div>
        <!-- End Page Header -->
        <!-- Default Light Table -->
        <div class="row">
            <div class="col">
                <div class="card card-small mb-4">
                    <div class="card-header d-flex border-bottom no-gutters">
                        <div class="col-12 col-sm-6">
                            <span>Количество записей</span>
                            <select id="select-client-lines-qty" class="form-control ml-2 d-inline-block" style="width: 75px;" onchange="searchByDeals()">
                                <option value="20" <?php if($row_count == 20): ?> selected <?php endif; ?>>20</option>
                                <option value="50" <?php if($row_count == 50): ?> selected <?php endif; ?>>50</option>
                            </select>

                            <a href="/admin/deal-edit/0">
                                <button type="button" name="submit" id="client-transporter-form-submit" class="mb-2 btn btn-primary mr-2">Добавить</button>
                            </a>
                        </div>
                        <div class="col-12 col-sm-3"></div>
                        <div class="col-12 col-sm-3">
                            <div class="ml-auto input-group input-group-seamless input-group-sm" >
                                <div class="input-group-prepend">
                          <span class="input-group-text">
                            <i class="material-icons">search</i>
                          </span>
                                </div>
                                <input class="form-control"  style="height: calc(2.09375rem + 2px)" id="search_word" value="<?php echo e($search_word); ?>"></div>
                        </div>
                    </div>
                    <div class="card-body p-0 pb-3 text-center">
                        <table class="table mb-0 clients-table">
                            <thead class="bg-light">
                            <tr>
                                <th scope="col" class="border-0">#</th>
                                <th scope="col" class="border-0">Наименование сделки</th>
                                <th scope="col" class="border-0">Клиент</th>
                                <th scope="col" class="border-0">Дата</th>
                                <th scope="col" class="border-0">Статус</th>
                                <th scope="col" class="border-0">Сумма</th>
                                <th scope="col" class="border-0">Действия</th>
                            </tr>
                            </thead>
                            <tbody>
                                <?php if(@count($row) > 0): ?>
                                    <?php $__currentLoopData = $row; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $deal_item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <tr>
                                            <td><?php echo e($loop->index); ?></td>
                                            <td><?php echo e($deal_item['station_name']); ?> - <?php echo e($deal_item['mark_name']); ?>  <?php echo e($deal_item['deal_volume']); ?> тонн</td>
                                            <td><?php echo e($deal_item['client_surname']); ?> <?php echo e($deal_item['client_name']); ?></td>
                                            <td><?php echo e($deal_item['deal_datetime1_format']); ?></td>
                                            <td>
                                                <div class="pb-1 text-white" style="background-color: <?php echo e($deal_item['status_color']); ?>">
                                                    <?php echo e($deal_item['status_name']); ?>

                                                </div>
                                            </td>
                                            <td>
                                                <?php if($deal_item['deal_status_id'] <= 3): ?>
                                                    <?php echo e($deal_item['deal_kp_sum']); ?> тг.
                                                <?php elseif($deal_item['deal_status_id'] >= 4): ?>
                                                    <?
                                                    $discount_sum = $deal_item['deal_discount'];
                                                    if($deal_item['deal_discount_type'] == 1){
                                                        $discount_sum = $deal_item['deal_kp_sum']*$deal_item['deal_discount']/100;
                                                    }
                                                    ?>
                                                    <?php echo e($deal_item['deal_kp_sum']-$discount_sum); ?> тг.
                                                <?php endif; ?>
                                            </td>
                                            <td>
                                                <div class="clients-table__actions">
                                                    <div class="btn-group btn-group-sm">
                                                        <a href="/admin/deal-edit/<?php echo e($deal_item->deal_id); ?>">
                                                            <button type="button" class="btn btn-white">
                                                              <span class="text-light">
                                                                <i class="material-icons">more_vert</i>
                                                              </span> Подробнее
                                                            </button>
                                                        </a>
                                                        <button type="button" class="btn btn-white" onclick="changeDealType(<?php echo e($deal_item['deal_id']); ?>,2,this)">
                                                          <span class="text-danger">
                                                            <i class="material-icons">clear</i>
                                                          </span> Отказ клиента
                                                        </button>
                                                    </div>
                                                </div>
                                            </td>
                                        </tr>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                <?php endif; ?>

                            </tbody>
                        </table>

                        <div class="dataTables_paginate paging_bootstrap pagination" style="float: right; margin-right: 20px;">
                            <?php echo $row->appends(\Illuminate\Support\Facades\Input::except('page'))->links(); ?>

                        </div>
                    </div>
                </div>
            </div>
        </div>
        <!-- End Default Light Table -->
    </div>

    <script>
        function deleteDeal(deal_id,ob){
            if (!confirm('Вы действительно хотите удалить сделку №' + deal_id +'?')) {
                return false;
            }

            $.ajax({
                type: 'GET',
                url: "/admin/delete-deal",
                data: {_token: CSRF_TOKEN, deal_id: deal_id},
                success: function(data){
                    if(data.result == false){
                        alert("Ошибка при удалении сделки");
                    }
                    else{
                        alert("Сделка #" + deal_id + " удалена");
                        $(ob).closest("tr").remove();
                    }
                }
            });
        }

        function searchByDeals(){
            window.location.href = "/admin/deal-list?type=list&deal_type_id=" + $("#deal_type_id_select").val() + "&client_id=" + $("#client_id_select").val() + "&status_id=" + $("#status_id_select").val() + "&user_id=" + $("#user_id_select").val() + "&date_from=" + $(".date_from_input").val() + "&date_to=" + $(".date_to_input").val() + "&row_count=" + $("#select-client-lines-qty").val() + "&search_word=" + $("#search_word").val();
        }

        $("#search_word").keyup(function(event) {
            if (event.keyCode === 13) {
                searchByDeals();
            }
        });

        function changeDealType(deal_id, deal_type_id,ob){
            if (!confirm('Вы действительно хотите отметить сделку как "Отказ клиента"?')) {
                return false;
            }

            $.ajax({
                type: 'POST',
                url: "/admin/change-deal-type",
                data: {_token: CSRF_TOKEN, deal_id:deal_id, deal_type_id: deal_type_id},
                success: function(data){
                    if(data.result == false){
                        alert("Ошибка при изменении статуса сделки");
                    }
                    else{
                        alert("Статус успешно изменен на 'Отказ клиента'");
                        $(ob).closest("tr").remove();
                    }
                }
            });
        }

        function setDealUser(deal_user_num,ob){
            $("#deal_user_id" +deal_user_num).val($(ob).val());
        }
    </script>

<?php $__env->stopSection(); ?>


<?php echo $__env->make('admin.layout', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>