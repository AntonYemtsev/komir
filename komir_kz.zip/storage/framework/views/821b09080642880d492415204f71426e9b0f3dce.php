<?php if(@count($deal_bill_file_list) > 0): ?>
    <?php $__currentLoopData = $deal_bill_file_list; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $deal_bill_file_item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <div class="d-flex flex-wrap no-gutters align-items-center justify-content-between" id="deal-card-5-bill1">
            <div class="col-12">
                <p class="deal-card-5-bill-name" id="deal-card-5-bill1-name"><?php echo e($deal_bill_file_item['deal_file_name']); ?></p>
                <p class="deal-card-5-bill-date" id="deal-card-5-bill1-date"><?php echo e($deal_bill_file_item['deal_file_date_format']); ?></p>
                <a href="/deal_files/<?php echo e($deal_bill_file_item['deal_file_src']); ?>" target="_blank">
                    <button type="button" id="deal-card-5-bill1-download" class="mb-2 btn btn-sm btn-outline-primary mr-1">Скачать</button>
                </a>
                <button onclick="sendDealBill(<?php echo e($deal_bill_file_item['deal_file_id']); ?>,<?php echo e($deal_bill_file_item['deal_file_deal_id']); ?>)" type="button" id="deal-card-5-bill1-send" class="mb-2 btn btn-sm btn-outline-primary mr-1">Отправить</button>
                <button onclick="deleteDealBill(<?php echo e($deal_bill_file_item['deal_file_id']); ?>,<?php echo e($deal_bill_file_item['deal_file_deal_id']); ?>)" type="button" id="deal-card-5-bill1-send" class="mb-2 btn btn-sm btn-outline-primary mr-1">Удалить</button>
            </div>
        </div>
    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
<?php endif; ?>