<?php if(@count($deal_history_list) > 0): ?>
    <?php $__currentLoopData = $deal_history_list; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $deal_history_item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <div class="user-activity__item d-flex my-2">
            <div class="user-activity__item__content">
                <span class="text-light">
                    <?php echo e($deal_history_item['deal_history_datetime_format']); ?> <br>
                    <?php echo e($deal_history_item['user_surname']); ?> <?php echo e($deal_history_item['user_name']); ?>

                </span>
                <p style="font-weight: normal"><?=$deal_history_item['deal_history_text']?></p>
            </div>
        </div>
    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
<?php endif; ?>