<?php $__env->startSection('content'); ?>
    <div class="main-content-container container-fluid px-4">
        <!-- Page Header -->
        <div class="page-header row no-gutters py-4">
            <div class="col-12 col-sm-4 text-center text-sm-left mb-0">
                <h3 class="page-title"><?php if($row['region_id'] > 0): ?> <?php echo e($row['region_name']); ?> <?php else: ?> Добавление новой области <?php endif; ?> </h3>
            </div>
        </div>
        <!-- End Page Header -->
        <!-- Default Light Table -->
        <div class="row">
            <div class="col-lg-8 d-flex">
                <div class="col-lg-6 pl-0">
                    <div class="card card-small mb-4 pt-1">
                        <div class="card-header border-bottom text-left">
                            <h5 class="mb-0">Данные</h5>
                        </div>
                        <div class="card-body">
                            <?php if(isset($result['status'])): ?>
                                <p style="color: red; font-size: 14px; text-align: center;">
                                    <?php if(@count($result['value']) > 0): ?>
                                        <?php $__currentLoopData = $result['value']; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $error_item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                            <?php echo e($error_item); ?> <br>
                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                    <?php endif; ?>
                                </p>
                            <?php endif; ?>

                            <form id="client-contact-form" method="post" enctype="multipart/form-data" action="/admin/region-edit/<?php echo e($row->region_id); ?>">
                                <input type="hidden" name="_token" value="<?php echo e(csrf_token()); ?>">
                                <input type="hidden" name="region_id" value="<?php echo e($row->region_id); ?>">
                                <div class="form-group">
                                    <label>Область</label>
                                    <input type="text" name="region_name" placeholder="" class="form-control" value="<?php echo e($row['region_name']); ?>">
                                </div>
                                <div class="form-group">
                                    <label>Цена за 1 тонну угля без НДС</label>
                                    <input type="text" name="region_price" placeholder="" class="form-control" value="<?php echo e($row['region_price']); ?>">
                                </div>
                                <div class="form-group">
                                    <label>Цена за 1 тонну угля с НДС</label>
                                    <input type="text" name="region_price_nds" placeholder="" class="form-control" value="<?php echo e($row['region_price_nds']); ?>">
                                </div>

                                <button type="submit" name="submit" id="client-contact-form-submit" class="mb-2 btn btn-primary mr-2"><?php if($row->region_id > 0): ?> Сохранить <?php else: ?> Добавить <?php endif; ?></button>
                            </form>
                        </div>
                    </div>
                </div>

            </div>

        </div>
        <!-- End Default Light Table -->
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('admin.layout', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>