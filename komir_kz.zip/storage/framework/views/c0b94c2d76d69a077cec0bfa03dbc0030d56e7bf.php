<?php $__env->startSection('content'); ?>
    <div class="main-content-container container-fluid px-4">
        <!-- Page Header -->
        <div class="page-header row align-items-center no-gutters py-4">
            
        </div>
        <!--Main content-->
        <div class="tasks-card-wrapper">
            <div class="d-flex" style="width: auto">
                <div class="col-sm-4 tasks-card-single-wrapper">
                    <div class="tasks-card-single card card-small mb-4 pt-1">
                        <div class="card-header text-left">
                            <h5 class="mb-0">Личные данные</h5>
                        </div>
                        <div class="card-body">
                            <form class="login-form" id="profile-form" method="post">
                                <input type="hidden" name="_token" value="<?php echo e(csrf_token()); ?>">
                                <div class="form-group">
                                    <label for="login-form-email">Фамилия</label>
                                    <input type="text" id="profile-form-name" name="user_surname"  value="<?php echo e($row['user_surname']); ?>" class="form-control">
                                </div>
                                <div class="form-group">
                                    <label for="login-form-email">Имя</label>
                                    <input type="text" id="profile-form-name" name="user_name"  value="<?php echo e($row['user_name']); ?>"  class="form-control">
                                </div>
                                <div class="form-group">
                                    <label for="login-form-email">Телефон</label>
                                    <input type="text" id="profile-form-phone"  name="user_phone"  value="<?php echo e($row['user_phone']); ?>" class="form-control">
                                </div>
                                <div class="form-group">
                                    <label for="login-form-email">E-mail</label>
                                    <input type="email" id="profile-form-email"  name="email"  value="<?php echo e($row['email']); ?>" class="form-control">
                                </div>
                                <div class="form-group">
                                    <label for="login-form-password">Текущий пароль</label>
                                    <input type="password" id="profile-form-currentPassword"  name="password" class="form-control">
                                </div>
                                <div class="form-group">
                                    <label for="login-form-password">Новый пароль</label>
                                    <input type="password" id="profile-form-newPassword" name="new_password" class="form-control">
                                </div>
                                <div class="form-group">
                                    <label for="login-form-password">Подтверждение пароля</label>
                                    <input type="password" id="profile-form-confirmPassword" name="repeat_password" class="form-control">
                                </div>
                                <div class="form-group">
                                    <label for="profile-form-role">Роль</label>
                                    <select id="profile-form-role" class="form-control" name="user_role_id">
                                        <?php if(@count($role_list) > 0): ?>
                                            <?php $__currentLoopData = $role_list; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $role_item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                <option value="<?php echo e($role_item['role_id']); ?>" <?php if($role_item['role_id'] == $row['user_role_id']): ?> selected <?php endif; ?>><?php echo e($role_item['role_name']); ?></option>
                                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                        <?php endif; ?>
                                    </select>
                                </div>
                                <button onclick="updateProfileInfo()" type="button" name="submit" id="login-form-submit" class="mb-2 btn btn-primary mr-2">Обновить</button>
                            </form>
                        </div>
                    </div>
                </div>
                <div class="tasks-card-single-wrapper" id="profile-deals">
                    <div class="tasks-card-single card card-small mb-4 pt-1">
                        <div class="card-header text-left">
                            <h5 class="mb-0">Мои сделки</h5>
                            <div class="d-flex flex-wrap no-gutters mt-2">
                                <div class="col-12 col-sm-6">
                                    <span>СДЕЛОК</span>
                                    <p id="profile-deals-dealsQuantity">21</p>
                                </div>
                                <div class="col-12 col-sm-6 text-sm-right">
                                    <span>СУММА</span>
                                    <p id="profile-deals-dealsSum">3 533 245</p>
                                </div>
                            </div>
                            <div class="rounded col-12 mt-3 py-2 bg-primary"></div>
                        </div>
                        <div class="card-body">
                            <div class="rounded border-primary border px-1 py-1 mb-2 task-small-card" id="task-small-card-2">
                                <div class="d-flex align-items-center justify-content-between">
                          <span class="task-small-card-status">
                            <span class="task-small-card-status-text">
                               Наименование сделки
                            </span>
                          </span>
                                    <span class="task-small-card-date">
                            <span class="task-small-card-date-text" id="task-small-card-2-date">
                              1 дн
                            </span>
                            <span class="task-small-card-date-icon text-primary">
                               📆
                            </span>
                           </span>
                                </div>
                                <div>
                                    <p class="task-small-card-name my-2" id="task-small-card-2-name">
                                        Выставить счет и дожать клиента
                                    </p>
                                </div>
                                <div class="d-flex align-items-center justify-content-between">
                          <span class="task-small-card-responsible" id="task-small-card-2-responsible">
                              Ильдос Какимжанов
                          </span>
                                    <a href="" class="task-small-card-make text-primary">
                            <span>
                              Перейти
                            </span>
                                    </a>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
                <div class="tasks-card-single-wrapper" id="profile-tasks">
                    <div class="tasks-card-single card card-small mb-4 pt-1">
                        <div class="card-header text-left">
                            <h5 class="mb-0">Мои задачи</h5>
                            <div class="d-flex flex-wrap no-gutters mt-2">
                                <div class="col-12 col-sm-6">
                                    <span>СДЕЛОК</span>
                                    <p id="profile-deals-dealsQuantity">21</p>
                                </div>
                                <div class="col-12 col-sm-6 text-sm-right">
                                    <span>СУММА</span>
                                    <p id="profile-deals-dealsSum">3 533 245</p>
                                </div>
                            </div>
                            <div class="rounded col-12 mt-3 py-2 bg-success"></div>
                        </div>
                        <div class="card-body">
                            <div class="rounded border-success border px-1 py-1 mb-2 task-small-card" id="task-small-card-3">
                                <div class="d-flex align-items-center justify-content-between">
                          <span class="task-small-card-status">
                            <span class="task-small-card-status-text">
                               Наименование сделки
                            </span>
                          </span>
                                    <span class="task-small-card-date">
                            <span class="task-small-card-date-text" id="task-small-card-3-date">
                              1 дн
                            </span>
                            <span class="task-small-card-date-icon text-success">
                               📆
                            </span>
                           </span>
                                </div>
                                <div>
                                    <p class="task-small-card-name my-2" id="task-small-card-3-name">
                                        Выставить счет и дожать клиента
                                    </p>
                                </div>
                                <div class="d-flex align-items-center justify-content-between">
                          <span class="task-small-card-responsible" id="task-small-card-3-responsible">
                              Ильдос Какимжанов
                          </span>
                                    <a href="" class="task-small-card-make text-success">
                            <span>
                              Перейти
                            </span>
                                    </a>
                                </div>
                            </div>
                            <div class="rounded border-danger border px-1 py-1 mb-2 task-small-card" id="task-small-card-3">
                                <div class="d-flex align-items-center justify-content-between">
                          <span class="task-small-card-status">
                            <span class="task-small-card-status-text">
                               Наименование сделки
                            </span>
                          </span>
                                    <span class="task-small-card-date">
                            <span class="task-small-card-date-text" id="task-small-card-3-date">
                              1 дн
                            </span>
                            <span class="task-small-card-date-icon text-danger">
                               📆
                            </span>
                           </span>
                                </div>
                                <div>
                                    <p class="task-small-card-name my-2" id="task-small-card-3-name">
                                        Выставить счет и дожать клиента
                                    </p>
                                </div>
                                <div class="d-flex align-items-center justify-content-between">
                          <span class="task-small-card-responsible" id="task-small-card-3-responsible">
                              Ильдос Какимжанов
                          </span>
                                    <a href="" class="task-small-card-make text-danger">
                            <span>
                              Перейти
                            </span>
                                    </a>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>


            </div>
        </div>
        <!-- /Main content -->

    </div>

    <script>
        function updateProfileInfo(){
            $.ajax({
                type: 'POST',
                url: "/admin/update-profile-info",
                data: $("#profile-form").serialize(),
                success: function(data){
                    if(data.result == "incorrect_user"){
                        alert("Ваш аккаунт не найден");
                    }
                    else if(data.result == "incorrect_password"){
                        alert("Неверный текущий пароль");
                    }
                    else if(data.result == "incorrect_repeat"){
                        alert("Новый и повтор пароли не совпадает");
                    }
                    else if(data.result == false){
                        alert("Ошибка при удалении банка");
                    }
                    else{
                        alert("Данные успешно обновлены");
                    }
                }
            });
        }
    </script>

<?php $__env->stopSection(); ?>


<?php echo $__env->make('admin.layout', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>