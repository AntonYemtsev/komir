<?php $__env->startSection('content'); ?>
    <div class="main-content-container container-fluid px-4">
        <!-- Page Header -->
        <div class="page-header row align-items-center no-gutters py-4">
            <div class="col-12 col-sm-2 d-flex text-center text-sm-left mb-0">
                
                <a class="change-view-type" href="/admin/deal-list?type=list">
                    <svg width="18" height="18" viewBox="0 0 31 31" fill="none" xmlns="http://www.w3.org/2000/svg">
                        <rect width="31" height="6" fill="#979797"/>
                        <rect width="31" height="6" fill="#979797"/>
                        <rect width="31" height="6" fill="#979797"/>
                        <rect y="12" width="31" height="7" fill="#979797"/>
                        <rect y="12" width="31" height="7" fill="#979797"/>
                        <rect y="12" width="31" height="7" fill="#979797"/>
                        <rect y="25" width="31" height="6" fill="#979797"/>
                        <rect y="25" width="31" height="6" fill="#979797"/>
                        <rect y="25" width="31" height="6" fill="#979797"/>
                    </svg>
                </a>
                <a class="change-view-type" href="/admin/deal-list?type=cards">
                    <svg width="18" height="18" viewBox="0 0 31 31" fill="none" xmlns="http://www.w3.org/2000/svg">
                        <rect x="30.9951" width="10" height="5.9991" transform="rotate(89.9917 30.9951 0)" fill="#007BFF"/>
                        <rect x="30.9951" width="10" height="5.9991" transform="rotate(89.9917 30.9951 0)" fill="#007BFF"/>
                        <rect x="30.9951" width="10" height="5.9991" transform="rotate(89.9917 30.9951 0)" fill="#007BFF"/>
                        <rect x="18.9971" y="0.00170898" width="20" height="6.99895" transform="rotate(89.9917 18.9971 0.00170898)" fill="#007BFF"/>
                        <rect x="18.9971" y="0.00170898" width="20" height="6.99895" transform="rotate(89.9917 18.9971 0.00170898)" fill="#007BFF"/>
                        <rect x="18.9971" y="0.00170898" width="20" height="6.99895" transform="rotate(89.9917 18.9971 0.00170898)" fill="#007BFF"/>
                        <rect x="5.99902" y="0.00366211" width="30.9956" height="5.9991" transform="rotate(89.9917 5.99902 0.00366211)" fill="#007BFF"/>
                        <rect x="5.99902" y="0.00366211" width="30.9956" height="5.9991" transform="rotate(89.9917 5.99902 0.00366211)" fill="#007BFF"/>
                        <rect x="5.99902" y="0.00366211" width="30.9956" height="5.9991" transform="rotate(89.9917 5.99902 0.00366211)" fill="#007BFF"/>
                    </svg>
                </a>
            </div>
            <div class="col-12 col-sm-7 d-flex text-center text-sm-left mb-0">
                <div class="col-6 col-sm-3">
                    <select id="deal_type_id_select" class="form-control" name="deal_type_id" onchange="searchByDeals()">
                        <option value="">Тип заявки</option>
                        <option value="0" <?php if(strlen($deal_type_id) > 0 && $deal_type_id == 0): ?> selected <?php endif; ?>>Активные</option>
                        <option value="1" <?php if($deal_type_id == 1): ?> selected <?php endif; ?>>Завершенные</option>
                        <option value="2" <?php if($deal_type_id == 2): ?> selected <?php endif; ?>>Отказанные</option>
                    </select>
                </div>
                <div class="col-6 col-sm-3">
                    <select id="client_id_select" class="form-control" name="user_id" onchange="searchByDeals()">
                        <option value="0">Клиент</option>
                        <?php if(@count($client_list) > 0): ?>
                            <?php $__currentLoopData = $client_list; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $client_item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <option value="<?php echo e($client_item['client_id']); ?>" <?php if($client_item['client_id'] == $client_id): ?> selected <?php endif; ?> ><?php echo e($client_item['client_surname']); ?> <?php echo e($client_item['client_name']); ?></option>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        <?php endif; ?>
                    </select>
                </div>
                <div class="col-6 col-sm-3">
                    <select id="status_id_select" class="form-control" name="status_id" onchange="searchByDeals()">
                        <option value="0">Статус</option>
                        <?php if(@count($status_list) > 0): ?>
                            <?php $__currentLoopData = $status_list; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $status_item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <option value="<?php echo e($status_item['status_id']); ?>" <?php if($status_item['status_id'] == $status_id): ?> selected <?php endif; ?> ><?php echo e($status_item['status_name']); ?></option>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        <?php endif; ?>
                    </select>
                </div>
                <div class="col-6 col-sm-3">
                    <select id="user_id_select" class="form-control" name="user_id" onchange="searchByDeals()">
                        <option value="0">Ответственный</option>
                        <?php if(@count($user_list) > 0): ?>
                            <?php $__currentLoopData = $user_list; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $user_item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <option value="<?php echo e($user_item['user_id']); ?>" <?php if($user_item['user_id'] == $user_id): ?> selected <?php endif; ?> ><?php echo e($user_item['user_surname']); ?> <?php echo e($user_item['user_name']); ?></option>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        <?php endif; ?>
                    </select>
                </div>
            </div>
            <div class="col-12 col-sm-3 text-center text-sm-left mb-0">
                <!-- DO NOT CHANGE IDs IN DATE PICKER -->
                <div id="blog-overview-date-range" class="input-daterange input-group input-group-sm my-auto ml-auto mr-auto ml-sm-auto mr-sm-0" style="max-width: 350px;">
                    <input type="text" class="input-sm form-control date_from_input" name="date_from" placeholder="01/01/2019" id="blog-overview-date-range-1" style="height: calc(2.09375rem + 2px)" value="<?php echo e($date_from); ?>" onchange="searchByDeals()">
                    <input type="text" class="input-sm form-control date_to_input" name="date_to" placeholder="02/01/2019" id="blog-overview-date-range-2" style="height: calc(2.09375rem + 2px)" value="<?php echo e($date_to); ?>" onchange="searchByDeals()">
                    <span class="input-group-append">
                    <span class="input-group-text" style="height: calc(2.09375rem + 2px)">
                      <i class="material-icons"></i>
                    </span>
                  </span>
                </div>
            </div>
        </div>
        <!--Main content-->
        <div class="deal-card-wrapper dragscroll">
            <div class="d-flex" style="width: auto">
                <div class="deal-card-single-wrapper" id="deal-card-1">
                    <div class="deal-card-single card card-small mb-4 pt-1">
                        <div class="card-header text-left">
                            <h5 class="mb-0">Заявка</h5>
                            <div class="d-flex flex-wrap no-gutters mt-2">
                                <div class="col-12 col-sm-6">
                                    <span>СДЕЛОК</span>
                                    <p id="tasks-card-1-dealsQuantity"><?php echo e(@count($row_list[1])); ?></p>
                                </div>
                                <div class="col-12 col-sm-6 text-sm-right">
                                    <span>СУММА</span>
                                    <?
                                    $all_deals_sum1 = DB::select( DB::raw("select
                                                                                         COALESCE( sum(CASE
                                                                                         WHEN t.deal_discount_type = 1 THEN t.deal_kp_sum - t.deal_kp_sum*t.deal_discount/100
                                                                                         ELSE t.deal_kp_sum - t.deal_discount
                                                                                         END),0) as deal_kp_sum_res
                                                                                    from deals t
                                                                                    where t.deal_status_id = 1"));
                                    ?>
                                    <p id="tasks-card-1-dealsSum"><?php echo e($all_deals_sum1[0]->deal_kp_sum_res); ?></p>
                                </div>
                            </div>
                            <div class="rounded col-12 mt-3 py-2" style="background-color: #EA5876"></div>
                        </div>
                        <div class="card-body">
                            <?php if(@count($row_list[1]) > 0): ?>
                                <?php $__currentLoopData = $row_list[1]; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $row_item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <div class="rounded border-primary border px-1 py-1 mb-2 task-small-card">
                                        <div class="d-flex align-items-center justify-content-between">

                                            <span class="task-small-card-client">
                                                <span class="task-small-card-status-text">
                                                   <?php echo e($row_item['client_surname']); ?> <?php echo e($row_item['client_name']); ?>

                                                </span>
                                            </span>

                                            <span class="task-small-card-date">
                                                <span class="task-small-card-date-text">
                                                  <?php echo e($row_item['deal_datetime1_format']); ?>

                                                </span>
                                                <span class="task-small-card-date-icon text-primary">
                                                   📆
                                                </span>
                                            </span>
                                        </div>
                                        <div>
                                            <p class="task-small-card-name my-2">
                                                <?php echo e($row_item['station_name']); ?> - <?php echo e($row_item['mark_name']); ?> <?php echo e($row_item['deal_volume']); ?> тонн
                                            </p>
                                        </div>
                                        <div class="d-flex align-items-center justify-content-between">
                                            <span class="task-small-card-price">
                                               <?php if($row_item['deal_status_id'] <= 3): ?>
                                                    <?php echo e($row_item['deal_kp_sum']); ?> тг.
                                                <?php elseif($row_item['deal_status_id'] >= 4): ?>
                                                    <?
                                                    $discount_sum = $row_item['deal_discount'];
                                                    if($row_item['deal_discount_type'] == 1){
                                                        $discount_sum = $row_item['deal_kp_sum']*$row_item['deal_discount']/100;
                                                    }
                                                    ?>
                                                    <?php echo e($row_item['deal_kp_sum']-$discount_sum); ?> тг.
                                                <?php endif; ?>
                                            </span>

                                            <span class="task-small-card-status">
                                                Нет задач
                                                <span class="task-small-card-status-icon text-warning">
                                                    ⚫
                                                </span>
                                            </span>
                                        </div>
                                    </div>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            <?php endif; ?>
                        </div>
                    </div>
                </div>
                <div class="deal-card-single-wrapper" id="deal-card-2">
                    <div class="deal-card-single card card-small mb-4 pt-1">
                        <div class="card-header text-left">
                            <h5 class="mb-0">Расчет КП</h5>
                            <div class="d-flex flex-wrap no-gutters mt-2">
                                <div class="col-12 col-sm-6">
                                    <span>СДЕЛОК</span>
                                    <p id="tasks-card-2-dealsQuantity"><?php echo e(@count($row_list[2])); ?></p>
                                </div>
                                <div class="col-12 col-sm-6 text-sm-right">
                                    <span>СУММА</span>
                                    <?
                                    $all_deals_sum2 = DB::select( DB::raw("select
                                                                                         COALESCE( sum(CASE
                                                                                         WHEN t.deal_discount_type = 1 THEN t.deal_kp_sum - t.deal_kp_sum*t.deal_discount/100
                                                                                         ELSE t.deal_kp_sum - t.deal_discount
                                                                                         END),0) as deal_kp_sum_res
                                                                                    from deals t
                                                                                    where t.deal_status_id = 2"));
                                    ?>
                                    <p id="tasks-card-2-dealsSum"><?php echo e($all_deals_sum2[0]->deal_kp_sum_res); ?></p>
                                </div>
                            </div>
                            <div class="rounded col-12 mt-3 py-2" style="background-color: #00B8D8"></div>
                        </div>
                        <div class="card-body">
                            <?php if(@count($row_list[2]) > 0): ?>
                                <?php $__currentLoopData = $row_list[2]; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $row_item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <div class="rounded border-primary border px-1 py-1 mb-2 task-small-card">
                                        <div class="d-flex align-items-center justify-content-between">

                                            <span class="task-small-card-client">
                                                <span class="task-small-card-status-text">
                                                   <?php echo e($row_item['client_surname']); ?> <?php echo e($row_item['client_name']); ?>

                                                </span>
                                            </span>

                                            <span class="task-small-card-date">
                                                <span class="task-small-card-date-text">
                                                  <?php echo e($row_item['deal_datetime1_format']); ?>

                                                </span>
                                                <span class="task-small-card-date-icon text-primary">
                                                   📆
                                                </span>
                                            </span>
                                        </div>
                                        <div>
                                            <p class="task-small-card-name my-2">
                                                <?php echo e($row_item['station_name']); ?> - <?php echo e($row_item['mark_name']); ?> <?php echo e($row_item['deal_volume']); ?> тонн
                                            </p>
                                        </div>
                                        <div class="d-flex align-items-center justify-content-between">
                                            <span class="task-small-card-price">
                                               <?php if($row_item['deal_status_id'] <= 3): ?>
                                                    <?php echo e($row_item['deal_kp_sum']); ?> тг.
                                                <?php elseif($row_item['deal_status_id'] >= 4): ?>
                                                    <?
                                                    $discount_sum = $row_item['deal_discount'];
                                                    if($row_item['deal_discount_type'] == 1){
                                                        $discount_sum = $row_item['deal_kp_sum']*$row_item['deal_discount']/100;
                                                    }
                                                    ?>
                                                    <?php echo e($row_item['deal_kp_sum']-$discount_sum); ?> тг.
                                                <?php endif; ?>
                                            </span>

                                            <span class="task-small-card-status">
                                                Нет задач
                                                <span class="task-small-card-status-icon text-warning">
                                                    ⚫
                                                </span>
                                            </span>
                                        </div>
                                    </div>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            <?php endif; ?>
                        </div>
                    </div>
                </div>
                <div class="deal-card-single-wrapper" id="deal-card-3">
                    <div class="deal-card-single card card-small mb-4 pt-1">
                        <div class="card-header text-left">
                            <h5 class="mb-0">Переговоры</h5>
                            <div class="d-flex flex-wrap no-gutters mt-2">
                                <div class="col-12 col-sm-6">
                                    <span>СДЕЛОК</span>
                                    <p id="tasks-card-3-dealsQuantity"><?php echo e(@count($row_list[3])); ?></p>
                                </div>
                                <div class="col-12 col-sm-6 text-sm-right">
                                    <span>СУММА</span>
                                    <?
                                    $all_deals_sum3 = DB::select( DB::raw("select
                                                                                         COALESCE( sum(CASE
                                                                                         WHEN t.deal_discount_type = 1 THEN t.deal_kp_sum - t.deal_kp_sum*t.deal_discount/100
                                                                                         ELSE t.deal_kp_sum - t.deal_discount
                                                                                         END),0) as deal_kp_sum_res
                                                                                    from deals t
                                                                                    where t.deal_status_id = 3"));
                                    ?>
                                    <p id="tasks-card-3-dealsSum"><?php echo e($all_deals_sum3[0]->deal_kp_sum_res); ?></p>
                                </div>
                            </div>
                            <div class="rounded col-12 mt-3 py-2" style="background-color: #313541"></div>
                        </div>
                        <div class="card-body">
                            <?php if(@count($row_list[3]) > 0): ?>
                                <?php $__currentLoopData = $row_list[3]; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $row_item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <a href="/admin/deal-edit/<?php echo e($row_item['deal_id']); ?>">
                                        <div class="rounded border-primary border px-1 py-1 mb-2 task-small-card">
                                            <div class="d-flex align-items-center justify-content-between">

                                                <span class="task-small-card-client">
                                                    <span class="task-small-card-status-text">
                                                       <?php echo e($row_item['client_surname']); ?> <?php echo e($row_item['client_name']); ?>

                                                    </span>
                                                </span>

                                                <span class="task-small-card-date">
                                                    <span class="task-small-card-date-text">
                                                      <?php echo e($row_item['deal_datetime1_format']); ?>

                                                    </span>
                                                    <span class="task-small-card-date-icon text-primary">
                                                       📆
                                                    </span>
                                                </span>
                                            </div>
                                            <div>
                                                <p class="task-small-card-name my-2">
                                                    <?php echo e($row_item['station_name']); ?> - <?php echo e($row_item['mark_name']); ?> <?php echo e($row_item['deal_volume']); ?> тонн
                                                </p>
                                            </div>
                                            <div class="d-flex align-items-center justify-content-between">
                                                <span class="task-small-card-price">
                                                   <?php if($row_item['deal_status_id'] <= 3): ?>
                                                        <?php echo e($row_item['deal_kp_sum']); ?> тг.
                                                    <?php elseif($row_item['deal_status_id'] >= 4): ?>
                                                        <?
                                                        $discount_sum = $row_item['deal_discount'];
                                                        if($row_item['deal_discount_type'] == 1){
                                                            $discount_sum = $row_item['deal_kp_sum']*$row_item['deal_discount']/100;
                                                        }
                                                        ?>
                                                        <?php echo e($row_item['deal_kp_sum']-$discount_sum); ?> тг.
                                                    <?php endif; ?>
                                                </span>

                                                <span class="task-small-card-status">
                                                    Нет задач
                                                    <span class="task-small-card-status-icon text-warning">
                                                        ⚫
                                                    </span>
                                                </span>
                                            </div>
                                        </div>
                                    </a>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            <?php endif; ?>
                        </div>
                    </div>
                </div>
                <div class="deal-card-single-wrapper" id="deal-card-4">
                    <div class="deal-card-single card card-small mb-4 pt-1">
                        <div class="card-header text-left">
                            <h5 class="mb-0">Договор</h5>
                            <div class="d-flex flex-wrap no-gutters mt-2">
                                <div class="col-12 col-sm-6">
                                    <span>СДЕЛОК</span>
                                    <p id="tasks-card-4-dealsQuantity"><?php echo e(@count($row_list[4])); ?></p>
                                </div>
                                <div class="col-12 col-sm-6 text-sm-right">
                                    <span>СУММА</span>
                                    <?
                                    $all_deals_sum4 = DB::select( DB::raw("select
                                                                                         COALESCE( sum(CASE
                                                                                         WHEN t.deal_discount_type = 1 THEN t.deal_kp_sum - t.deal_kp_sum*t.deal_discount/100
                                                                                         ELSE t.deal_kp_sum - t.deal_discount
                                                                                         END),0) as deal_kp_sum_res
                                                                                    from deals t
                                                                                    where t.deal_status_id = 4"));
                                    ?>
                                    <p id="tasks-card-4-dealsSum"><?php echo e($all_deals_sum4[0]->deal_kp_sum_res); ?></p>
                                </div>
                            </div>
                            <div class="rounded col-12 mt-3 py-2" style="background-color: #674EEC"></div>
                        </div>
                        <div class="card-body">
                            <?php if(@count($row_list[4]) > 0): ?>
                                <?php $__currentLoopData = $row_list[4]; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $row_item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <a href="/admin/deal-edit/<?php echo e($row_item['deal_id']); ?>">
                                        <div class="rounded border-primary border px-1 py-1 mb-2 task-small-card">
                                            <div class="d-flex align-items-center justify-content-between">

                                                <span class="task-small-card-client">
                                                    <span class="task-small-card-status-text">
                                                       <?php echo e($row_item['client_surname']); ?> <?php echo e($row_item['client_name']); ?>

                                                    </span>
                                                </span>

                                                <span class="task-small-card-date">
                                                    <span class="task-small-card-date-text">
                                                      <?php echo e($row_item['deal_datetime1_format']); ?>

                                                    </span>
                                                    <span class="task-small-card-date-icon text-primary">
                                                       📆
                                                    </span>
                                                </span>
                                            </div>
                                            <div>
                                                <p class="task-small-card-name my-2">
                                                    <?php echo e($row_item['station_name']); ?> - <?php echo e($row_item['mark_name']); ?> <?php echo e($row_item['deal_volume']); ?> тонн
                                                </p>
                                            </div>
                                            <div class="d-flex align-items-center justify-content-between">
                                                <span class="task-small-card-price">
                                                   <?php if($row_item['deal_status_id'] <= 3): ?>
                                                        <?php echo e($row_item['deal_kp_sum']); ?> тг.
                                                    <?php elseif($row_item['deal_status_id'] >= 4): ?>
                                                        <?
                                                        $discount_sum = $row_item['deal_discount'];
                                                        if($row_item['deal_discount_type'] == 1){
                                                            $discount_sum = $row_item['deal_kp_sum']*$row_item['deal_discount']/100;
                                                        }
                                                        ?>
                                                        <?php echo e($row_item['deal_kp_sum']-$discount_sum); ?> тг.
                                                    <?php endif; ?>
                                                </span>

                                                <span class="task-small-card-status">
                                                    Нет задач
                                                    <span class="task-small-card-status-icon text-warning">
                                                        ⚫
                                                    </span>
                                                </span>
                                            </div>
                                        </div>
                                    </a>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            <?php endif; ?>
                        </div>
                    </div>
                </div>
                <div class="deal-card-single-wrapper" id="deal-card-5">
                    <div class="deal-card-single card card-small mb-4 pt-1">
                        <div class="card-header text-left">
                            <h5 class="mb-0">Счет на оплату</h5>
                            <div class="d-flex flex-wrap no-gutters mt-2">
                                <div class="col-12 col-sm-6">
                                    <span>СДЕЛОК</span>
                                    <p id="tasks-card-5-dealsQuantity"><?php echo e(@count($row_list[5])); ?></p>
                                </div>
                                <div class="col-12 col-sm-6 text-sm-right">
                                    <span>СУММА</span>
                                    <?
                                    $all_deals_sum5 = DB::select( DB::raw("select
                                                                                         COALESCE( sum(CASE
                                                                                         WHEN t.deal_discount_type = 1 THEN t.deal_kp_sum - t.deal_kp_sum*t.deal_discount/100
                                                                                         ELSE t.deal_kp_sum - t.deal_discount
                                                                                         END),0) as deal_kp_sum_res
                                                                                    from deals t
                                                                                    where t.deal_status_id = 5"));
                                    ?>
                                    <p id="tasks-card-5-dealsSum"><?php echo e($all_deals_sum5[0]->deal_kp_sum_res); ?></p>
                                </div>
                            </div>
                            <div class="rounded col-12 mt-3 py-2" style="background-color: #17C671"></div>
                        </div>
                        <div class="card-body">
                            <?php if(@count($row_list[5]) > 0): ?>
                                <?php $__currentLoopData = $row_list[5]; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $row_item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <a href="/admin/deal-edit/<?php echo e($row_item['deal_id']); ?>">
                                        <div class="rounded border-primary border px-1 py-1 mb-2 task-small-card">
                                            <div class="d-flex align-items-center justify-content-between">

                                                <span class="task-small-card-client">
                                                    <span class="task-small-card-status-text">
                                                       <?php echo e($row_item['client_surname']); ?> <?php echo e($row_item['client_name']); ?>

                                                    </span>
                                                </span>

                                                <span class="task-small-card-date">
                                                    <span class="task-small-card-date-text">
                                                      <?php echo e($row_item['deal_datetime1_format']); ?>

                                                    </span>
                                                    <span class="task-small-card-date-icon text-primary">
                                                       📆
                                                    </span>
                                                </span>
                                            </div>
                                            <div>
                                                <p class="task-small-card-name my-2">
                                                    <?php echo e($row_item['station_name']); ?> - <?php echo e($row_item['mark_name']); ?> <?php echo e($row_item['deal_volume']); ?> тонн
                                                </p>
                                            </div>
                                            <div class="d-flex align-items-center justify-content-between">
                                                <span class="task-small-card-price">
                                                   <?php if($row_item['deal_status_id'] <= 3): ?>
                                                        <?php echo e($row_item['deal_kp_sum']); ?> тг.
                                                    <?php elseif($row_item['deal_status_id'] >= 4): ?>
                                                        <?
                                                        $discount_sum = $row_item['deal_discount'];
                                                        if($row_item['deal_discount_type'] == 1){
                                                            $discount_sum = $row_item['deal_kp_sum']*$row_item['deal_discount']/100;
                                                        }
                                                        ?>
                                                        <?php echo e($row_item['deal_kp_sum']-$discount_sum); ?> тг.
                                                    <?php endif; ?>
                                                </span>

                                                <span class="task-small-card-status">
                                                    Нет задач
                                                    <span class="task-small-card-status-icon text-warning">
                                                        ⚫
                                                    </span>
                                                </span>
                                            </div>
                                        </div>
                                    </a>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            <?php endif; ?>
                        </div>
                    </div>
                </div>
                <div class="deal-card-single-wrapper" id="deal-card-6">
                    <div class="deal-card-single card card-small mb-4 pt-1">
                        <div class="card-header text-left">
                            <h5 class="mb-0">Заявка разрезу</h5>
                            <div class="d-flex flex-wrap no-gutters mt-2">
                                <div class="col-12 col-sm-6">
                                    <span>СДЕЛОК</span>
                                    <p id="tasks-card-6-dealsQuantity"><?php echo e(@count($row_list[6])); ?></p>
                                </div>
                                <div class="col-12 col-sm-6 text-sm-right">
                                    <span>СУММА</span>
                                    <?
                                    $all_deals_sum6 = DB::select( DB::raw("select
                                                                                         COALESCE( sum(CASE
                                                                                         WHEN t.deal_discount_type = 1 THEN t.deal_kp_sum - t.deal_kp_sum*t.deal_discount/100
                                                                                         ELSE t.deal_kp_sum - t.deal_discount
                                                                                         END),0) as deal_kp_sum_res
                                                                                    from deals t
                                                                                    where t.deal_status_id = 6"));
                                    ?>
                                    <p id="tasks-card-6-dealsSum"><?php echo e($all_deals_sum6[0]->deal_kp_sum_res); ?></p>
                                </div>
                            </div>
                            <div class="rounded col-12 mt-3 py-2" style="background-color: #C4183C"></div>
                        </div>
                        <div class="card-body">
                            <?php if(@count($row_list[6]) > 0): ?>
                                <?php $__currentLoopData = $row_list[6]; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $row_item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <a href="/admin/deal-edit/<?php echo e($row_item['deal_id']); ?>">
                                        <div class="rounded border-primary border px-1 py-1 mb-2 task-small-card">
                                            <div class="d-flex align-items-center justify-content-between">

                                                <span class="task-small-card-client">
                                                    <span class="task-small-card-status-text">
                                                       <?php echo e($row_item['client_surname']); ?> <?php echo e($row_item['client_name']); ?>

                                                    </span>
                                                </span>

                                                <span class="task-small-card-date">
                                                    <span class="task-small-card-date-text">
                                                      <?php echo e($row_item['deal_datetime1_format']); ?>

                                                    </span>
                                                    <span class="task-small-card-date-icon text-primary">
                                                       📆
                                                    </span>
                                                </span>
                                            </div>
                                            <div>
                                                <p class="task-small-card-name my-2">
                                                    <?php echo e($row_item['station_name']); ?> - <?php echo e($row_item['mark_name']); ?> <?php echo e($row_item['deal_volume']); ?> тонн
                                                </p>
                                            </div>
                                            <div class="d-flex align-items-center justify-content-between">
                                                <span class="task-small-card-price">
                                                   <?php if($row_item['deal_status_id'] <= 3): ?>
                                                        <?php echo e($row_item['deal_kp_sum']); ?> тг.
                                                    <?php elseif($row_item['deal_status_id'] >= 4): ?>
                                                        <?
                                                        $discount_sum = $row_item['deal_discount'];
                                                        if($row_item['deal_discount_type'] == 1){
                                                            $discount_sum = $row_item['deal_kp_sum']*$row_item['deal_discount']/100;
                                                        }
                                                        ?>
                                                        <?php echo e($row_item['deal_kp_sum']-$discount_sum); ?> тг.
                                                    <?php endif; ?>
                                                </span>

                                                <span class="task-small-card-status">
                                                    Нет задач
                                                    <span class="task-small-card-status-icon text-warning">
                                                        ⚫
                                                    </span>
                                                </span>
                                            </div>
                                        </div>
                                    </a>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            <?php endif; ?>
                        </div>
                    </div>
                </div>
                <div class="deal-card-single-wrapper" id="deal-card-7">
                    <div class="deal-card-single card card-small mb-4 pt-1">
                        <div class="card-header text-left">
                            <h5 class="mb-0">Оплата разрезу</h5>
                            <div class="d-flex flex-wrap no-gutters mt-2">
                                <div class="col-12 col-sm-6">
                                    <span>СДЕЛОК</span>
                                    <p id="tasks-card-7-dealsQuantity"><?php echo e(@count($row_list[7])); ?></p>
                                </div>
                                <div class="col-12 col-sm-6 text-sm-right">
                                    <span>СУММА</span>
                                    <?
                                    $all_deals_sum7 = DB::select( DB::raw("select
                                                                                         COALESCE( sum(CASE
                                                                                         WHEN t.deal_discount_type = 1 THEN t.deal_kp_sum - t.deal_kp_sum*t.deal_discount/100
                                                                                         ELSE t.deal_kp_sum - t.deal_discount
                                                                                         END),0) as deal_kp_sum_res
                                                                                    from deals t
                                                                                    where t.deal_status_id = 7"));
                                    ?>
                                    <p id="tasks-card-7-dealsSum"><?php echo e($all_deals_sum7[0]->deal_kp_sum_res); ?></p>
                                </div>
                            </div>
                            <div class="rounded col-12 mt-3 py-2" style="background-color: #F7B422"></div>
                        </div>
                        <div class="card-body">
                            <?php if(@count($row_list[7]) > 0): ?>
                                <?php $__currentLoopData = $row_list[7]; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $row_item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <a href="/admin/deal-edit/<?php echo e($row_item['deal_id']); ?>">
                                        <div class="rounded border-primary border px-1 py-1 mb-2 task-small-card">
                                            <div class="d-flex align-items-center justify-content-between">

                                                <span class="task-small-card-client">
                                                    <span class="task-small-card-status-text">
                                                       <?php echo e($row_item['client_surname']); ?> <?php echo e($row_item['client_name']); ?>

                                                    </span>
                                                </span>

                                                <span class="task-small-card-date">
                                                    <span class="task-small-card-date-text">
                                                      <?php echo e($row_item['deal_datetime1_format']); ?>

                                                    </span>
                                                    <span class="task-small-card-date-icon text-primary">
                                                       📆
                                                    </span>
                                                </span>
                                            </div>
                                            <div>
                                                <p class="task-small-card-name my-2">
                                                    <?php echo e($row_item['station_name']); ?> - <?php echo e($row_item['mark_name']); ?> <?php echo e($row_item['deal_volume']); ?> тонн
                                                </p>
                                            </div>
                                            <div class="d-flex align-items-center justify-content-between">
                                                <span class="task-small-card-price">
                                                   <?php if($row_item['deal_status_id'] <= 3): ?>
                                                        <?php echo e($row_item['deal_kp_sum']); ?> тг.
                                                    <?php elseif($row_item['deal_status_id'] >= 4): ?>
                                                        <?
                                                        $discount_sum = $row_item['deal_discount'];
                                                        if($row_item['deal_discount_type'] == 1){
                                                            $discount_sum = $row_item['deal_kp_sum']*$row_item['deal_discount']/100;
                                                        }
                                                        ?>
                                                        <?php echo e($row_item['deal_kp_sum']-$discount_sum); ?> тг.
                                                    <?php endif; ?>
                                                </span>

                                                <span class="task-small-card-status">
                                                    Нет задач
                                                    <span class="task-small-card-status-icon text-warning">
                                                        ⚫
                                                    </span>
                                                </span>
                                            </div>
                                        </div>
                                    </a>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            <?php endif; ?>
                        </div>
                    </div>
                </div>
                <div class="deal-card-single-wrapper" id="deal-card-8">
                    <div class="deal-card-single card card-small mb-4 pt-1">
                        <div class="card-header text-left">
                            <h5 class="mb-0">Отгрузка</h5>
                            <div class="d-flex flex-wrap no-gutters mt-2">
                                <div class="col-12 col-sm-6">
                                    <span>СДЕЛОК</span>
                                    <p id="tasks-card-8-dealsQuantity"><?php echo e(@count($row_list[8])); ?></p>
                                </div>
                                <div class="col-12 col-sm-6 text-sm-right">
                                    <span>СУММА</span>
                                    <?
                                    $all_deals_sum8 = DB::select( DB::raw("select
                                                                                         COALESCE( sum(CASE
                                                                                         WHEN t.deal_discount_type = 1 THEN t.deal_kp_sum - t.deal_kp_sum*t.deal_discount/100
                                                                                         ELSE t.deal_kp_sum - t.deal_discount
                                                                                         END),0) as deal_kp_sum_res
                                                                                    from deals t
                                                                                    where t.deal_status_id = 8"));
                                    ?>
                                    <p id="tasks-card-8-dealsSum"><?php echo e($all_deals_sum8[0]->deal_kp_sum_res); ?></p>
                                </div>
                            </div>
                            <div class="rounded col-12 mt-3 py-2" style="background-color: #A8AEB4"></div>
                        </div>
                        <div class="card-body">
                            <?php if(@count($row_list[8]) > 0): ?>
                                <?php $__currentLoopData = $row_list[8]; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $row_item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <a href="/admin/deal-edit/<?php echo e($row_item['deal_id']); ?>">
                                        <div class="rounded border-primary border px-1 py-1 mb-2 task-small-card">
                                            <div class="d-flex align-items-center justify-content-between">

                                                <span class="task-small-card-client">
                                                    <span class="task-small-card-status-text">
                                                       <?php echo e($row_item['client_surname']); ?> <?php echo e($row_item['client_name']); ?>

                                                    </span>
                                                </span>

                                                <span class="task-small-card-date">
                                                    <span class="task-small-card-date-text">
                                                      <?php echo e($row_item['deal_datetime1_format']); ?>

                                                    </span>
                                                    <span class="task-small-card-date-icon text-primary">
                                                       📆
                                                    </span>
                                                </span>
                                            </div>
                                            <div>
                                                <p class="task-small-card-name my-2">
                                                    <?php echo e($row_item['station_name']); ?> - <?php echo e($row_item['mark_name']); ?> <?php echo e($row_item['deal_volume']); ?> тонн
                                                </p>
                                            </div>
                                            <div class="d-flex align-items-center justify-content-between">
                                                <span class="task-small-card-price">
                                                   <?php if($row_item['deal_status_id'] <= 3): ?>
                                                        <?php echo e($row_item['deal_kp_sum']); ?> тг.
                                                    <?php elseif($row_item['deal_status_id'] >= 4): ?>
                                                        <?
                                                        $discount_sum = $row_item['deal_discount'];
                                                        if($row_item['deal_discount_type'] == 1){
                                                            $discount_sum = $row_item['deal_kp_sum']*$row_item['deal_discount']/100;
                                                        }
                                                        ?>
                                                        <?php echo e($row_item['deal_kp_sum']-$discount_sum); ?> тг.
                                                    <?php endif; ?>
                                                </span>

                                                <span class="task-small-card-status">
                                                    Нет задач
                                                    <span class="task-small-card-status-icon text-warning">
                                                        ⚫
                                                    </span>
                                                </span>
                                            </div>
                                        </div>
                                    </a>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            <?php endif; ?>
                        </div>
                    </div>
                </div>
                <div class="deal-card-single-wrapper" id="deal-card-9">
                    <div class="deal-card-single card card-small mb-4 pt-1">
                        <div class="card-header text-left">
                            <h5 class="mb-0">Доставка</h5>
                            <div class="d-flex flex-wrap no-gutters mt-2">
                                <div class="col-12 col-sm-6">
                                    <span>СДЕЛОК</span>
                                    <p id="tasks-card-9-dealsQuantity"><?php echo e(@count($row_list[9])); ?></p>
                                </div>
                                <div class="col-12 col-sm-6 text-sm-right">
                                    <span>СУММА</span>
                                    <?
                                    $all_deals_sum9 = DB::select( DB::raw("select
                                                                                         COALESCE( sum(CASE
                                                                                         WHEN t.deal_discount_type = 1 THEN t.deal_kp_sum - t.deal_kp_sum*t.deal_discount/100
                                                                                         ELSE t.deal_kp_sum - t.deal_discount
                                                                                         END),0) as deal_kp_sum_res
                                                                                    from deals t
                                                                                    where t.deal_status_id = 9"));
                                    ?>
                                    <p id="tasks-card-9-dealsSum"><?php echo e($all_deals_sum9[0]->deal_kp_sum_res); ?></p>
                                </div>
                            </div>
                            <div class="rounded col-12 mt-3 py-2" style="background-color: #B3D7FF"></div>
                        </div>
                        <div class="card-body">
                            <?php if(@count($row_list[9]) > 0): ?>
                                <?php $__currentLoopData = $row_list[9]; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $row_item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <a href="/admin/deal-edit/<?php echo e($row_item['deal_id']); ?>">
                                        <div class="rounded border-primary border px-1 py-1 mb-2 task-small-card">
                                            <div class="d-flex align-items-center justify-content-between">

                                                <span class="task-small-card-client">
                                                    <span class="task-small-card-status-text">
                                                       <?php echo e($row_item['client_surname']); ?> <?php echo e($row_item['client_name']); ?>

                                                    </span>
                                                </span>

                                                <span class="task-small-card-date">
                                                    <span class="task-small-card-date-text">
                                                      <?php echo e($row_item['deal_datetime1_format']); ?>

                                                    </span>
                                                    <span class="task-small-card-date-icon text-primary">
                                                       📆
                                                    </span>
                                                </span>
                                            </div>
                                            <div>
                                                <p class="task-small-card-name my-2">
                                                    <?php echo e($row_item['station_name']); ?> - <?php echo e($row_item['mark_name']); ?> <?php echo e($row_item['deal_volume']); ?> тонн
                                                </p>
                                            </div>
                                            <div class="d-flex align-items-center justify-content-between">
                                                <span class="task-small-card-price">
                                                   <?php if($row_item['deal_status_id'] <= 3): ?>
                                                        <?php echo e($row_item['deal_kp_sum']); ?> тг.
                                                    <?php elseif($row_item['deal_status_id'] >= 4): ?>
                                                        <?
                                                        $discount_sum = $row_item['deal_discount'];
                                                        if($row_item['deal_discount_type'] == 1){
                                                            $discount_sum = $row_item['deal_kp_sum']*$row_item['deal_discount']/100;
                                                        }
                                                        ?>
                                                        <?php echo e($row_item['deal_kp_sum']-$discount_sum); ?> тг.
                                                    <?php endif; ?>
                                                </span>

                                                <span class="task-small-card-status">
                                                    Нет задач
                                                    <span class="task-small-card-status-icon text-warning">
                                                        ⚫
                                                    </span>
                                                </span>
                                            </div>
                                        </div>
                                    </a>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            <?php endif; ?>
                        </div>
                    </div>
                </div>




            </div>
        </div>
        <!-- /Main content -->

    </div>

    <script>
        function deleteDeal(deal_id,ob){
            if (!confirm('Вы действительно хотите удалить сделку №' + deal_id +'?')) {
                return false;
            }

            $.ajax({
                type: 'GET',
                url: "/admin/delete-deal",
                data: {_token: CSRF_TOKEN, deal_id: deal_id},
                success: function(data){
                    if(data.result == false){
                        alert("Ошибка при удалении сделки");
                    }
                    else{
                        alert("Сделка #" + deal_id + " удалена");
                        $(ob).closest("tr").remove();
                    }
                }
            });
        }

        function searchByDeals(){
            window.location.href = "/admin/deal-list?type=cards&deal_type_id=" + $("#deal_type_id_select").val() + "&client_id=" + $("#client_id_select").val() + "&status_id=" + $("#status_id_select").val() + "&user_id=" + $("#user_id_select").val() + "&date_from=" + $(".date_from_input").val() + "&date_to=" + $(".date_to_input").val();
        }

        $("#search_word").keyup(function(event) {
            if (event.keyCode === 13) {
                searchByDeals();
            }
        });
    </script>

<?php $__env->stopSection(); ?>


<?php echo $__env->make('admin.layout', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>