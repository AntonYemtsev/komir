<?php $__env->startSection('content'); ?>
    <div class="main-content-container container-fluid px-4">
        <!-- Page Header -->
        <div class="page-header row no-gutters py-4">
            <div class="col-12 col-sm-4 text-center text-sm-left mb-0">
                
            </div>
        </div>
        <!-- End Page Header -->
        <!-- Default Light Table -->
        <div class="row">
            <div class="col-lg-12 d-flex">
                <div class="col-lg-12 pl-0">
                    <div class="card card-small mb-4 pt-1">
                        <div class="card-header border-bottom text-left">
                            <h5 class="mb-0">Данные</h5>
                        </div>
                        <div class="card-body">
                            <?php if(isset($result['status'])): ?>
                                <p style="color: red; font-size: 14px; text-align: center;">
                                    <?php if(@count($result['value']) > 0): ?>
                                        <?php $__currentLoopData = $result['value']; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $error_item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                            <?php echo e($error_item); ?> <br>
                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                    <?php endif; ?>
                                </p>
                            <?php endif; ?>

                            <form id="client-contact-form" method="post" enctype="multipart/form-data" action="/admin/deal-template-file-edit/<?php echo e($row->deal_template_file_id); ?>">
                                <input type="hidden" name="_token" value="<?php echo e(csrf_token()); ?>">
                                <input type="hidden" name="deal_template_file_id" value="<?php echo e($row->deal_template_file_id); ?>">
                                <div class="form-group">
                                    <label>Тип шаблона файла</label>
                                    <select class="form-control" name="deal_template_type_id">
                                        <option value="0">Выберите тип шаблона файла</option>
                                        <option value="1" <?php if($row->deal_template_type_id == 1): ?> selected <?php endif; ?>>Коммерческое предложение</option>
                                        <option value="2" <?php if($row->deal_template_type_id == 2): ?> selected <?php endif; ?>>Счет на оплату</option>
                                        <option value="3" <?php if($row->deal_template_type_id == 3): ?> selected <?php endif; ?>>Приложение №3</option>
                                    </select>
                                </div>
                                <div class="form-group">
                                    <label>HTML шаблон файла</label>
                                    <textarea class="form-control" id="editor1_new" rows="10" name="deal_template_text"><?php echo e($row->deal_template_text); ?></textarea>
                                </div>

                                <button type="submit" name="submit" id="client-contact-form-submit" class="mb-2 btn btn-primary mr-2"><?php if($row->deal_template_file_id > 0): ?> Сохранить <?php else: ?> Добавить <?php endif; ?></button>
                            </form>
                        </div>
                    </div>
                </div>

            </div>

        </div>
        <!-- End Default Light Table -->
    </div>

    <script>
        editor = CKEDITOR.replace( 'editor1_new', {
            toolbar: [
                { name: 'document', groups: [ 'mode', 'document', 'doctools' ], items: [ 'Source'] },
                { name: 'basicstyles', items : [ 'Bold','Italic','Underline','Strike','-', 'Maximize' ] },
            ],
            forcePasteAsPlainText: true,
            allowedContent: {
                script: true,
                div: true,
                $1: {
                    // This will set the default set of elements
                    attributes: true,
                    styles: true,
                    classes: true
                }
            }
        });
    </script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('admin.layout', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>