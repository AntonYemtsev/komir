<?php

use Illuminate\Database\Seeder;

class ClientsTableSeeder extends Seeder
{

    /**
     * Auto generated seed file
     *
     * @return void
     */
    public function run()
    {
        

        \DB::table('clients')->delete();
        
        \DB::table('clients')->insert(array (
            0 => 
            array (
                'client_id' => 4,
                'client_name' => 'Адильбек',
                'client_surname' => 'Халихов',
                'client_phone' => '+7015533120',
                'client_email' => 'asads@mail.ru',
                'client_region_id' => 1,
                'client_station_id' => 1,
                'client_receiver_code' => 1231313,
                'client_company_id' => 4,
                'is_discount' => 1,
                'created_at' => '2019-02-16 17:59:12',
                'updated_at' => '2019-02-16 18:07:18',
            ),
        ));
        
        
    }
}