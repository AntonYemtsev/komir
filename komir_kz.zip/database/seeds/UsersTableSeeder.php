<?php

use Illuminate\Database\Seeder;

class UsersTableSeeder extends Seeder
{

    /**
     * Auto generated seed file
     *
     * @return void
     */
    public function run()
    {
        

        \DB::table('users')->delete();
        
        \DB::table('users')->insert(array (
            0 => 
            array (
                'user_id' => 1,
                'user_name' => 'Админ',
                'user_surname' => 'Админов',
                'email' => 'admin@admin.com',
                'user_phone' => '+77015533120',
                'password' => '$2y$10$UBfiXLOzuJvI40c.VKNgge9GsAixUOf7R5vCbgZxKx3.4DD8vhvha',
                'user_role_id' => 1,
                'is_blocked' => 0,
                'date_last_login' => '2019-02-16 20:09:30',
                'password_changed_time' => '2016-07-18 10:37:56',
                'image' => '1520074721_user.jpeg',
                'reset_token' => NULL,
                'remember_token' => 'P8yn7jnmeFrsgvpiTls68x7YXcS0D5Aavzlp26uTxrbySqAV37LDi1jkr549',
                'created_at' => NULL,
                'updated_at' => '2019-02-16 14:09:30',
            ),
        ));
        
        
    }
}