<?php

use Illuminate\Database\Seeder;

class StationsTableSeeder extends Seeder
{

    /**
     * Auto generated seed file
     *
     * @return void
     */
    public function run()
    {
        

        \DB::table('stations')->delete();
        
        \DB::table('stations')->insert(array (
            0 => 
            array (
                'station_id' => 1,
                'station_name' => 'Адыр',
                'station_code' => '691406',
                'station_km' => 559,
                'station_region_id' => 1,
                'station_rate' => 2119,
                'station_rate_nds' => 2373,
                'station_brand_id' => 1,
                'created_at' => '2019-02-16 17:55:23',
                'updated_at' => '2019-02-16 17:55:23',
            ),
        ));
        
        
    }
}