<?php

use Illuminate\Database\Seeder;

class FractionsTableSeeder extends Seeder
{

    /**
     * Auto generated seed file
     *
     * @return void
     */
    public function run()
    {
        

        \DB::table('fractions')->delete();
        
        
        
    }
}