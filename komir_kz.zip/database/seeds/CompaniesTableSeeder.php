<?php

use Illuminate\Database\Seeder;

class CompaniesTableSeeder extends Seeder
{

    /**
     * Auto generated seed file
     *
     * @return void
     */
    public function run()
    {
        

        \DB::table('companies')->delete();
        
        \DB::table('companies')->insert(array (
            0 => 
            array (
                'company_id' => 4,
                'company_name' => 'цйцуцйу',
                'company_ceo_position' => 'йцуйцуцй',
                'company_ceo_name' => 'уцйуйцуцйу',
                'сompany_address' => 'фывыфвыфв',
                'company_bank_id' => 1,
                'company_bank_iik' => 'уйцуцйуцй',
                'company_bank_bin' => 'йцуцйуйцу',
                'created_at' => '2019-02-16 17:59:12',
                'updated_at' => '2019-02-16 17:59:12',
            ),
        ));
        
        
    }
}