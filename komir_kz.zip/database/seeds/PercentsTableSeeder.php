<?php

use Illuminate\Database\Seeder;

class PercentsTableSeeder extends Seeder
{

    /**
     * Auto generated seed file
     *
     * @return void
     */
    public function run()
    {
        

        \DB::table('percents')->delete();
        
        
        
    }
}