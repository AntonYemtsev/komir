<?php

use Illuminate\Database\Seeder;

class RegionsTableSeeder extends Seeder
{

    /**
     * Auto generated seed file
     *
     * @return void
     */
    public function run()
    {
        

        \DB::table('regions')->delete();
        
        \DB::table('regions')->insert(array (
            0 => 
            array (
                'region_id' => 1,
                'region_name' => 'Павлодарская',
                'region_price' => 5589.0,
                'region_price_nds' => 6259.12,
                'created_at' => '2019-02-16 17:35:13',
                'updated_at' => '2019-02-16 17:35:13',
            ),
        ));
        
        
    }
}