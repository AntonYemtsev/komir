<?php

use Illuminate\Database\Seeder;

class BanksTableSeeder extends Seeder
{

    /**
     * Auto generated seed file
     *
     * @return void
     */
    public function run()
    {
        

        \DB::table('banks')->delete();
        
        \DB::table('banks')->insert(array (
            0 => 
            array (
                'bank_id' => 1,
                'bank_bik' => 'ABNAKZKX',
                'bank_name' => 'АО "First Heartland Bank"',
                'created_at' => '2019-02-16 17:29:07',
                'updated_at' => '2019-02-16 17:29:07',
            ),
        ));
        
        
    }
}