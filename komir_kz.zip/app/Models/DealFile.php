<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;

class DealFile extends Model
{
    protected $table = 'deal_files';
    protected $primaryKey = 'deal_file_id';
}
