<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;

class Percent extends Model
{
    protected $table = 'percents';
    protected $primaryKey = 'percent_id';
}
