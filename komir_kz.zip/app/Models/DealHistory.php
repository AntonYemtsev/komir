<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;

class DealHistory extends Model
{
    protected $table = 'deal_histories';
    protected $primaryKey = 'deal_history_id';
}
