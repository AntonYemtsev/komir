<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;

class ShippingComment extends Model
{
    protected $table = 'shipping_comments';
    protected $primaryKey = 'shipping_comment_id';
}
