<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;

class Fraction extends Model
{
    protected $table = 'fractions';
    protected $primaryKey = 'fraction_id';
}
