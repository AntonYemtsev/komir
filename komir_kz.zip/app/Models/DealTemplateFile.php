<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;

class DealTemplateFile extends Model
{
    protected $table = 'deal_template_files';
    protected $primaryKey = 'deal_template_file_id';
}
