<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;

class ClientAnswer extends Model
{
    protected $table = 'client_answers';
    protected $primaryKey = 'client_answer_id';
}
