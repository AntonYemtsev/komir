<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;

class DeliveryComment extends Model
{
    protected $table = 'delivery_comments';
    protected $primaryKey = 'delivery_comment_id';
}
