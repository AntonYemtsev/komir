<?php

namespace App\Http\Controllers\Admin;

use App\Models\Bank;
use App\Models\Brand;
use App\Models\Client;
use App\Models\ClientAnswer;
use App\Models\Company;
use App\Models\Deal;
use App\Models\DealFile;
use App\Models\DealHistory;
use App\Models\DealTemplateFile;
use App\Models\Delivery;
use App\Models\DeliveryComment;
use App\Models\Fraction;
use App\Models\Mark;
use App\Models\Payment;
use App\Models\Percent;
use App\Models\Region;
use App\Models\Role;
use App\Models\ShippingComment;
use App\Models\Station;
use App\Models\Status;
use App\Models\Task;
use App\Models\Timezone;
use App\Models\UserTask;
use Barryvdh\DomPDF\Facade as PDF;
use Illuminate\Http\Request;
use App\Http\Requests;
use App\Http\Controllers\Controller;
use App\Models\Users;
use Illuminate\Support\Facades\Validator;
use Illuminate\Support\MessageBag;
use Illuminate\Support\Facades\Storage;
use Illuminate\Support\Facades\File;
use App\Helpers;
use Auth;
use Hash;
use Mail;
use DB;
use Symfony\Component\Yaml\Tests\B;

class AdminController extends Controller
{
    public function login(Request $request)
    {
        if(Auth::check()){
            return redirect('/admin/index');
        }

        if(isset($request->email)){
            if (Auth::attempt(['email' => $request->email, 'password' => $request->password])){
                $user_item = Users::where("email","=",$request->email)->first();
                if(@count($user_item) > 0){
                    $offset= strtotime("+6 hours 0 minutes");
                    $user_item->date_last_login = date("Y-m-d H:i:s", $offset);
                    $user_item->save();
                }

                return redirect('/admin/index');
            }
            else{
                return view('admin.login', [
                    'email' => $request->email,
                    'error' => 'Неправильный логин или пароль'
                ]);
            }
        }
        else{
            return view('admin.login', [
                'email' => '',
                'error' => 'Неправильный логин или пароль'
            ]);
        }
    }

    public function index(){
        if(!Auth::check()){
            return redirect('/login');
        }

        return view('admin.index');
    }

    public function cyr2lat ($text) {

        $cyr2lat_replacements = array (
            "А" => "a","Б" => "b","В" => "v","Г" => "g","Д" => "d",
            "Е" => "e","Ё" => "yo","Ж" => "dg","З" => "z","И" => "i",
            "Й" => "y","К" => "k","Л" => "l","М" => "m","Н" => "n",
            "О" => "o","П" => "p","Р" => "r","С" => "s","Т" => "t",
            "У" => "u","Ф" => "f","Х" => "kh","Ц" => "ts","Ч" => "ch",
            "Ш" => "sh","Щ" => "csh","Ъ" => "","Ы" => "i","Ь" => "",
            "Э" => "e","Ю" => "yu","Я" => "ya",

            "а" => "a","б" => "b","в" => "v","г" => "g","д" => "d",
            "е" => "e","ё" => "yo","ж" => "dg","з" => "z","и" => "i",
            "й" => "y","к" => "k","л" => "l","м" => "m","н" => "n",
            "о" => "o","п" => "p","р" => "r","с" => "s","т" => "t",
            "у" => "u","ф" => "f","х" => "kh","ц" => "ts","ч" => "ch",
            "ш" => "sh","щ" => "sch","ъ" => "","ы" => "y","ь" => "",
            "э" => "e","ю" => "yu","я" => "ya",
            "(" => "", ")" => "", "," => "", "." => "",

            "-" => "-"," " => "-", "+" => "", "®" => "", "«" => "", "»" => "", '"' => "", "`" => "", "&" => "", "#" => "", ":" => "", ";" => "", "/" => "", "?" => ""
        );
        $a = str_replace("---","-",strtolower (strtr (trim($text),$cyr2lat_replacements)));
        $b = str_replace("--","-",$a);
        return $b;
    }

    public function userList(Request $request){
        $row_count = 20;
        if(isset($request->row_count)){
            $row_count = $request->row_count;
        }
        $row = Users::LeftJoin('roles','users.user_role_id','=','roles.role_id')
            ->select('users.*','roles.role_name');

        if(isset($request->search_word) && strlen($request->search_word) > 0){
            $row = $row->where(function($query) use ($request)
            {
                $query->where("user_name","like","%" . $request->search_word . "%")->orWhere("user_surname","like","%" . $request->search_word . "%");
            });
        }
        $row = $row->paginate($row_count);
        return view('admin.user-list', [ 'row' => $row, 'row_count' => $row_count,'search_word' => $request->search_word]);
    }

    public function userEdit(Request $request){
        $user_id = $request->user_id;

        $row = Users::find($user_id);
        $role_list = Role::all();
        if(@count($row) < 1){
            $row = new Users();
            $row->user_id = 0;
        }
        return view('admin.user-edit', ['row' => $row, 'role_list' => $role_list]);
    }

    public function deleteUser(Request $request){
        $user_id = $request->user_id;
        $user_row = Users::find($user_id);
        if(@count($user_row) > 0){
            $this->deleteFile("user_photo",$user_row->image);
        }

        $result = Users::where('user_id', '=', $user_id)->delete();
        return response()->json(['result'=>$result]);
    }

    public function saveUser(Request $request){
        $messages = array(
            'user_surname.required' => 'Укажите Фамилию',
            'user_name.required' => 'Укажите Имя',
            'email.required' => 'Укажите Email',
            'email.email' => 'Неправильный формат Email'
        );
        $validator = Validator::make($request->all(), [
            'user_surname' => 'required',
            'user_name' => 'required',
            'email' => 'required|email'
        ], $messages);

        if ($validator->fails()) {
            $messages = $validator->errors();
            $error = $messages->all();

            $result['value'] = $error;
            $result['status'] = false;
            $role_list = Role::all();
            return view('admin.user-edit', [ 'row' => $request, 'role_list' => $role_list, 'result' => $result ]);
        }

        $is_new_user = 0;
        $rand_str = "";
        $old_file_name = "";
        if($request->user_id > 0) {
            $user_item = Users::find($request->user_id);
            $old_file_name = $user_item->image;
        }
        else {
            $user_item = new Users();
            $is_new_user = 1;
            $characters = '0123456789abcdefghijklmnopqrstuvwxyz';
            for ($i = 0; $i < 14; $i++) {
                $rand_str .= $characters[rand(0, strlen($characters) - 1)];
            }
            $user_item->password = Hash::make($rand_str);
        }

        if($request->hasFile('image')){
            $this->deleteFile("user_photo",$old_file_name);
            $file = $request->image;
            $file_name = time() . "_user.";
            $file_extension = $file->extension($file_name);
            $file_name = $file_name . $file_extension;
            Storage::disk('user_photo')->put($file_name,  File::get($file));
            $user_item->image = $file_name;
        }

        $user_item->user_surname = $request->user_surname;
        $user_item->user_name = $request->user_name;
        $user_item->user_phone = $request->user_phone;
        $user_item->email = $request->email;
        $user_item->user_role_id = $request->user_role_id;

        if($user_item->save()){
            if($is_new_user == 100){
                $email_to = $request->email;
                $message_str = 'Уважаемый (-ая), ' . $request->fio .'!<br>Ваш пароль для входа в личный кабинет: ' . $rand_str;
                Mail::send(['html' => 'admin.email'], ['text' => $message_str], function($message) use ($email_to)
                {
                    $message->to($email_to)->subject("Регистрация на сайте");
                });
            }
            return redirect('/admin/user-list');
        }
        else{
            $error[0] = 'Ошибка при сохранении';
            $result['value'] = $error;
            $result['status'] = false;
            $role_list = Role::all();
            return view('admin.user-edit', [ 'row' => $request, 'role_list' => $role_list, 'result' => $result ]);
        }
    }

    public function deleteFile($path,$old_file_name){
        if(strlen($old_file_name) > 0){
            if(Storage::disk($path)->has($old_file_name)){
                Storage::disk($path)->delete($old_file_name);
            }
        }
    }

    public function changePasswordEdit(){
        return view('admin.change-password-edit');
    }

    public function changePassword(Request $request){
        $messages = array(
            'old_password.required' => 'Укажите старый пароль!',
            'new_password.required' => 'Укажите новый пароль!',
            'new_password.different' => 'Новый пароль совпадает со старым паролем!',
            'repeat_new_password.required' => 'Укажите повтор нового пароля!',
            'repeat_new_password.same' => 'Повтор пароля не совпадает!'
        );
        $validator = Validator::make($request->all(), [
            'old_password' => 'required',
            'new_password' => 'required|different:old_password',
            'repeat_new_password' => 'required|same:new_password'
        ], $messages);

        if ($validator->fails()) {
            $messages = $validator->errors();
            $error = $messages->all();

            $result['value'] = $error;
            $result['status'] = false;
            return view('admin.change-password-edit', ['result' => $result ]);
        }

        $user = Users::where('user_id','=',Auth::user()->user_id)->first();
        $count = Hash::check($request->old_password, $user->password);
        if($count == false){
            $error[0] = "Неправильно указан старый пароль!";
            $result['value'] = $error;
            $result['status'] = false;
            return view('admin.change-password-edit', ['result' => $result ]);
        }

        $user = Users::where('user_id','=',Auth::user()->user_id)->first();
        $user->password = Hash::make($request->new_password);
        $offset= strtotime("+6 hours 0 minutes");
        $user->password_changed_time = date("Y-m-d H:i:s", $offset);
        if($user->save()){
            $error[0] = "Пароль успешно изменен!";
            $result['value'] = $error;
            $result['status'] = false;
            return view('admin.change-password-edit', ['result' => $result ]);
        }
        else{
            $error[0] = "Ошибка при изменени пароля!";
            $result['value'] = $error;
            $result['status'] = false;
            return view('admin.change-password-edit', ['result' => $result ]);
        }
    }

    public function resetPassword(){
        $email = "";
        $error = "";
        return view('admin.reset-password',['email' => $email, 'error' => $error]);
    }

    public function resetPasswordEdit(Request $request){
        $messages = array(
            'reset_email.required' => 'Укажите Email!'
        );
        $validator = Validator::make($request->all(), [
            'reset_email' => 'required'
        ], $messages);

        if ($validator->fails()) {
            $messages = $validator->errors();
            $error = $messages->all();
            return view('admin.reset-password',['email' => $request->reset_email, 'error' => $error[0]]);
        }

        $user = Users::where('email','=',$request->reset_email)->first();

        if(@count($user) > 0){
            $rand_str = "";
            $characters = '0123456789abcdefghijklmnopqrstuvwxyz';
            for ($i = 0; $i < 14; $i++) {
                $rand_str .= $characters[rand(0, strlen($characters) - 1)];
            }
            $user->password = Hash::make($rand_str);
            $offset= strtotime("+6 hours 0 minutes");
            $user->password_changed_time = date("Y-m-d H:i:s",$offset);
            $user->save();

            $email_to = $request->reset_email;
            $message_str = 'Ваш новый пароль для входа в личный кабинет : ' . $rand_str;
            Mail::send(['html' => 'admin.email'], ['text' => $message_str], function($message) use ($email_to)
            {
                $message->to($email_to)->subject("Сброс пароля на сайте");
            });
            return view('admin.reset-password',['email' => $request->reset_email, 'error' => "Пароль успешно сброшен и отправлен на почту!"]);
        }
        else{
            return view('admin.reset-password',['email' => $request->reset_email, 'error' => "Пользователя с таким Email не существует!"]);
        }
    }


    public function regionList(Request $request){
        $row_count = 20;
        if(isset($request->row_count)){
            $row_count = $request->row_count;
        }
        $row = Region::select('regions.*');

        if(isset($request->search_word) && strlen($request->search_word) > 0){
            $row = $row->where("region_name","like","%" . $request->search_word . "%");
        }
        $row = $row->paginate($row_count);
        return view('admin.region-list', [ 'row' => $row, 'row_count' => $row_count,'search_word' => $request->search_word]);
    }

    public function regionEdit(Request $request){
        $region_id = $request->region_id;

        $row = Region::find($region_id);
        if(@count($row) < 1){
            $row = new Region();
            $row->region_id = 0;
        }
        return view('admin.region-edit', ['row' => $row]);
    }

    public function deleteRegion(Request $request){
        $region_id = $request->region_id;
        $result = Region::where('region_id', '=', $region_id)->delete();
        return response()->json(['result'=>$result]);
    }

    public function saveRegion(Request $request){
        $messages = array(
            'region_name.required' => 'Укажите Область'
        );
        $validator = Validator::make($request->all(), [
            'region_name' => 'required'
        ], $messages);

        if ($validator->fails()) {
            $messages = $validator->errors();
            $error = $messages->all();

            $result['value'] = $error;
            $result['status'] = false;
            $role_list = Role::all();
            return view('admin.region-edit', [ 'row' => $request, 'role_list' => $role_list, 'result' => $result ]);
        }

        if($request->region_id > 0) {
            $region_item = Region::find($request->region_id);
        }
        else {
            $region_item = new Region();
        }

        $region_item->region_name = $request->region_name;
        $region_item->region_price = $request->region_price;
        $region_item->region_price_nds = $request->region_price_nds;

        if($region_item->save()){
            return redirect('/admin/region-list');
        }
        else{
            $error[0] = 'Ошибка при сохранении';
            $result['value'] = $error;
            $result['status'] = false;
            $role_list = Role::all();
            return view('admin.region-edit', [ 'row' => $request, 'role_list' => $role_list, 'result' => $result ]);
        }
    }

    public function bankList(Request $request){
        $row_count = 20;
        if(isset($request->row_count)){
            $row_count = $request->row_count;
        }
        $row = Bank::select('banks.*');

        if(isset($request->search_word) && strlen($request->search_word) > 0){
            $row = $row->where("bank_name","like","%" . $request->search_word . "%");
        }
        $row = $row->paginate($row_count);
        return view('admin.bank-list', [ 'row' => $row, 'row_count' => $row_count,'search_word' => $request->search_word]);
    }

    public function bankEdit(Request $request){
        $bank_id = $request->bank_id;

        $row = Bank::find($bank_id);
        if(@count($row) < 1){
            $row = new Bank();
            $row->bank_id = 0;
        }
        return view('admin.bank-edit', ['row' => $row]);
    }

    public function deleteBank(Request $request){
        $bank_id = $request->bank_id;
        $result = Bank::where('bank_id', '=', $bank_id)->delete();
        return response()->json(['result'=>$result]);
    }

    public function saveBank(Request $request){
        $messages = array(
            'bank_name.required' => 'Укажите Наименование на русском языке'
        );
        $validator = Validator::make($request->all(), [
            'bank_name' => 'required'
        ], $messages);

        if ($validator->fails()) {
            $messages = $validator->errors();
            $error = $messages->all();

            $result['value'] = $error;
            $result['status'] = false;
            $role_list = Role::all();
            return view('admin.bank-edit', [ 'row' => $request, 'role_list' => $role_list, 'result' => $result ]);
        }

        if($request->bank_id > 0) {
            $bank_item = Bank::find($request->bank_id);
        }
        else {
            $bank_item = new Bank();
        }

        $bank_item->bank_name = $request->bank_name;
        $bank_item->bank_bik = $request->bank_bik;

        if($bank_item->save()){
            return redirect('/admin/bank-list');
        }
        else{
            $error[0] = 'Ошибка при сохранении';
            $result['value'] = $error;
            $result['status'] = false;
            $role_list = Role::all();
            return view('admin.bank-edit', [ 'row' => $request, 'role_list' => $role_list, 'result' => $result ]);
        }
    }

    public function paymentList(Request $request){
        $row_count = 20;
        if(isset($request->row_count)){
            $row_count = $request->row_count;
        }
        $row = Payment::select('payments.*');

        if(isset($request->search_word) && strlen($request->search_word) > 0){
            $row = $row->where("payment_name","like","%" . $request->search_word . "%");
        }
        $row = $row->paginate($row_count);
        return view('admin.payment-list', [ 'row' => $row, 'row_count' => $row_count,'search_word' => $request->search_word]);
    }

    public function paymentEdit(Request $request){
        $payment_id = $request->payment_id;

        $row = Payment::find($payment_id);
        if(@count($row) < 1){
            $row = new Payment();
            $row->payment_id = 0;
        }
        return view('admin.payment-edit', ['row' => $row]);
    }

    public function deletePayment(Request $request){
        $payment_id = $request->payment_id;
        $result = Payment::where('payment_id', '=', $payment_id)->delete();
        return response()->json(['result'=>$result]);
    }

    public function savePayment(Request $request){
        $messages = array(
            'payment_name.required' => 'Укажите Наименование'
        );
        $validator = Validator::make($request->all(), [
            'payment_name' => 'required'
        ], $messages);

        if ($validator->fails()) {
            $messages = $validator->errors();
            $error = $messages->all();

            $result['value'] = $error;
            $result['status'] = false;
            $role_list = Role::all();
            return view('admin.payment-edit', [ 'row' => $request, 'role_list' => $role_list, 'result' => $result ]);
        }

        if($request->payment_id > 0) {
            $payment_item = Payment::find($request->payment_id);
        }
        else {
            $payment_item = new Payment();
        }

        $payment_item->payment_name = $request->payment_name;

        if($payment_item->save()){
            return redirect('/admin/payment-list');
        }
        else{
            $error[0] = 'Ошибка при сохранении';
            $result['value'] = $error;
            $result['status'] = false;
            $role_list = Role::all();
            return view('admin.payment-edit', [ 'row' => $request, 'role_list' => $role_list, 'result' => $result ]);
        }
    }

    public function deliveryList(Request $request){
        $row_count = 20;
        if(isset($request->row_count)){
            $row_count = $request->row_count;
        }
        $row = Delivery::select('deliveries.*');

        if(isset($request->search_word) && strlen($request->search_word) > 0){
            $row = $row->where("delivery_name","like","%" . $request->search_word . "%");
        }
        $row = $row->paginate($row_count);
        return view('admin.delivery-list', [ 'row' => $row, 'row_count' => $row_count,'search_word' => $request->search_word]);
    }

    public function deliveryEdit(Request $request){
        $delivery_id = $request->delivery_id;

        $row = Delivery::find($delivery_id);
        if(@count($row) < 1){
            $row = new Delivery();
            $row->delivery_id = 0;
        }
        return view('admin.delivery-edit', ['row' => $row]);
    }

    public function deleteDelivery(Request $request){
        $delivery_id = $request->delivery_id;
        $result = Delivery::where('delivery_id', '=', $delivery_id)->delete();
        return response()->json(['result'=>$result]);
    }

    public function saveDelivery(Request $request){
        $messages = array(
            'delivery_name.required' => 'Укажите Наименование'
        );
        $validator = Validator::make($request->all(), [
            'delivery_name' => 'required'
        ], $messages);

        if ($validator->fails()) {
            $messages = $validator->errors();
            $error = $messages->all();

            $result['value'] = $error;
            $result['status'] = false;
            $role_list = Role::all();
            return view('admin.delivery-edit', [ 'row' => $request, 'role_list' => $role_list, 'result' => $result ]);
        }

        if($request->delivery_id > 0) {
            $delivery_item = Delivery::find($request->delivery_id);
        }
        else {
            $delivery_item = new Delivery();
        }

        $delivery_item->delivery_name = $request->delivery_name;

        if($delivery_item->save()){
            return redirect('/admin/delivery-list');
        }
        else{
            $error[0] = 'Ошибка при сохранении';
            $result['value'] = $error;
            $result['status'] = false;
            $role_list = Role::all();
            return view('admin.delivery-edit', [ 'row' => $request, 'role_list' => $role_list, 'result' => $result ]);
        }
    }

    public function brandList(Request $request){
        $row_count = 20;
        if(isset($request->row_count)){
            $row_count = $request->row_count;
        }
        $row = Brand::select('brands.*');

        if(isset($request->search_word) && strlen($request->search_word) > 0){
            $row = $row->where("brand_name","like","%" . $request->search_word . "%");
        }
        $row = $row->paginate($row_count);
        return view('admin.brand-list', [ 'row' => $row, 'row_count' => $row_count,'search_word' => $request->search_word]);
    }

    public function brandEdit(Request $request){
        $brand_id = $request->brand_id;

        $row = Brand::find($brand_id);
        if(@count($row) < 1){
            $row = new Brand();
            $row->brand_id = 0;
        }
        return view('admin.brand-edit', ['row' => $row]);
    }

    public function deleteBrand(Request $request){
        $brand_id = $request->brand_id;
        $result = Brand::where('brand_id', '=', $brand_id)->delete();
        return response()->json(['result'=>$result]);
    }

    public function saveBrand(Request $request){
        $messages = array(
            'brand_name.required' => 'Укажите Наименование'
        );
        $validator = Validator::make($request->all(), [
            'brand_name' => 'required'
        ], $messages);

        if ($validator->fails()) {
            $messages = $validator->errors();
            $error = $messages->all();

            $result['value'] = $error;
            $result['status'] = false;
            $role_list = Role::all();
            return view('admin.brand-edit', [ 'row' => $request, 'role_list' => $role_list, 'result' => $result ]);
        }

        if($request->brand_id > 0) {
            $brand_item = Brand::find($request->brand_id);
        }
        else {
            $brand_item = new Brand();
        }

        $brand_item->brand_name = $request->brand_name;
        $brand_item->brand_email = $request->brand_email;
        $brand_item->brand_company_name = $request->brand_company_name;
        $brand_item->brand_company_ceo_name = $request->brand_company_ceo_name;

        if($brand_item->save()){
            return redirect('/admin/brand-list');
        }
        else{
            $error[0] = 'Ошибка при сохранении';
            $result['value'] = $error;
            $result['status'] = false;
            $role_list = Role::all();
            return view('admin.brand-edit', [ 'row' => $request, 'role_list' => $role_list, 'result' => $result ]);
        }
    }

    public function markList(Request $request){
        $row_count = 20;
        if(isset($request->row_count)){
            $row_count = $request->row_count;
        }
        $row = Mark::select('marks.*');

        if(isset($request->search_word) && strlen($request->search_word) > 0){
            $row = $row->where("mark_name","like","%" . $request->search_word . "%");
        }
        $row = $row->paginate($row_count);
        return view('admin.mark-list', [ 'row' => $row, 'row_count' => $row_count,'search_word' => $request->search_word]);
    }

    public function markEdit(Request $request){
        $mark_id = $request->mark_id;

        $row = Mark::find($mark_id);
        if(@count($row) < 1){
            $row = new Mark();
            $row->mark_id = 0;
        }
        return view('admin.mark-edit', ['row' => $row]);
    }

    public function deleteMark(Request $request){
        $mark_id = $request->mark_id;
        $result = Mark::where('mark_id', '=', $mark_id)->delete();
        return response()->json(['result'=>$result]);
    }

    public function saveMark(Request $request){
        $messages = array(
            'mark_name.required' => 'Укажите Наименование'
        );
        $validator = Validator::make($request->all(), [
            'mark_name' => 'required'
        ], $messages);

        if ($validator->fails()) {
            $messages = $validator->errors();
            $error = $messages->all();

            $result['value'] = $error;
            $result['status'] = false;
            $role_list = Role::all();
            return view('admin.mark-edit', [ 'row' => $request, 'role_list' => $role_list, 'result' => $result ]);
        }

        if($request->mark_id > 0) {
            $mark_item = Mark::find($request->mark_id);
        }
        else {
            $mark_item = new Mark();
        }

        $mark_item->mark_name = $request->mark_name;
        $mark_item->mark_code = $request->mark_code;

        if($mark_item->save()){
            return redirect('/admin/mark-list');
        }
        else{
            $error[0] = 'Ошибка при сохранении';
            $result['value'] = $error;
            $result['status'] = false;
            $role_list = Role::all();
            return view('admin.mark-edit', [ 'row' => $request, 'role_list' => $role_list, 'result' => $result ]);
        }
    }

    public function fractionList(Request $request){
        $row_count = 20;
        if(isset($request->row_count)){
            $row_count = $request->row_count;
        }
        $row = Fraction::select('fractions.*');

        if(isset($request->search_word) && strlen($request->search_word) > 0){
            $row = $row->where("fraction_name","like","%" . $request->search_word . "%");
        }
        $row = $row->paginate($row_count);
        return view('admin.fraction-list', [ 'row' => $row, 'row_count' => $row_count,'search_word' => $request->search_word]);
    }

    public function fractionEdit(Request $request){
        $fraction_id = $request->fraction_id;

        $row = Fraction::find($fraction_id);
        if(@count($row) < 1){
            $row = new Fraction();
            $row->fraction_id = 0;
        }
        return view('admin.fraction-edit', ['row' => $row]);
    }

    public function deleteFraction(Request $request){
        $fraction_id = $request->fraction_id;
        $result = Fraction::where('fraction_id', '=', $fraction_id)->delete();
        return response()->json(['result'=>$result]);
    }

    public function saveFraction(Request $request){
        $messages = array(
            'fraction_name.required' => 'Укажите Наименование'
        );
        $validator = Validator::make($request->all(), [
            'fraction_name' => 'required'
        ], $messages);

        if ($validator->fails()) {
            $messages = $validator->errors();
            $error = $messages->all();

            $result['value'] = $error;
            $result['status'] = false;
            $role_list = Role::all();
            return view('admin.fraction-edit', [ 'row' => $request, 'role_list' => $role_list, 'result' => $result ]);
        }

        if($request->fraction_id > 0) {
            $fraction_item = Fraction::find($request->fraction_id);
        }
        else {
            $fraction_item = new Fraction();
        }

        $fraction_item->fraction_name = $request->fraction_name;

        if($fraction_item->save()){
            return redirect('/admin/fraction-list');
        }
        else{
            $error[0] = 'Ошибка при сохранении';
            $result['value'] = $error;
            $result['status'] = false;
            $role_list = Role::all();
            return view('admin.fraction-edit', [ 'row' => $request, 'role_list' => $role_list, 'result' => $result ]);
        }
    }

    public function percentList(Request $request){
        $row_count = 20;
        if(isset($request->row_count)){
            $row_count = $request->row_count;
        }
        $row = Percent::LeftJoin("brands","percents.percent_brand_id","=","brands.brand_id")->select('percents.*',"brands.brand_name");

        if(isset($request->search_word) && strlen($request->search_word) > 0){
            $row = $row->where("percent_rate","like","%" . $request->search_word . "%");
        }
        $row = $row->paginate($row_count);
        return view('admin.percent-list', [ 'row' => $row, 'row_count' => $row_count,'search_word' => $request->search_word]);
    }

    public function percentEdit(Request $request){
        $percent_id = $request->percent_id;

        $row = Percent::find($percent_id);
        if(@count($row) < 1){
            $row = new Percent();
            $row->percent_id = 0;
        }
        return view('admin.percent-edit', ['row' => $row]);
    }

    public function deletePercent(Request $request){
        $percent_id = $request->percent_id;
        $result = Percent::where('percent_id', '=', $percent_id)->delete();
        return response()->json(['result'=>$result]);
    }

    public function savePercent(Request $request){
        $messages = array(
            'percent_brand_id.not_in' => 'Укажите Разрез'
        );
        $validator = Validator::make($request->all(), [
            'percent_brand_id' => 'required|not_in:0',
        ], $messages);

        if ($validator->fails()) {
            $messages = $validator->errors();
            $error = $messages->all();

            $result['value'] = $error;
            $result['status'] = false;
            $role_list = Role::all();
            return view('admin.percent-edit', [ 'row' => $request, 'role_list' => $role_list, 'result' => $result ]);
        }

        if($request->percent_id > 0) {
            $percent_item = Percent::find($request->percent_id);
        }
        else {
            $percent_item = new Percent();
        }

        $percent_item->percent_rate = $request->percent_rate;
        $percent_item->percent_sum_rate = $request->percent_sum_rate;
        $percent_item->percent_brand_id = $request->percent_brand_id;

        if($percent_item->save()){
            return redirect('/admin/percent-list');
        }
        else{
            $error[0] = 'Ошибка при сохранении';
            $result['value'] = $error;
            $result['status'] = false;
            $role_list = Role::all();
            return view('admin.percent-edit', [ 'row' => $request, 'role_list' => $role_list, 'result' => $result ]);
        }
    }

    public function statusList(Request $request){
        $row_count = 20;
        if(isset($request->row_count)){
            $row_count = $request->row_count;
        }
        $row = Status::select('statuses.*');

        if(isset($request->search_word) && strlen($request->search_word) > 0){
            $row = $row->where("status_name","like","%" . $request->search_word . "%");
        }
        $row = $row->paginate($row_count);
        return view('admin.status-list', [ 'row' => $row, 'row_count' => $row_count,'search_word' => $request->search_word]);
    }

    public function statusEdit(Request $request){
        $status_id = $request->status_id;

        $row = Status::find($status_id);
        if(@count($row) < 1){
            $row = new Status();
            $row->status_id = 0;
        }
        return view('admin.status-edit', ['row' => $row]);
    }

    public function deleteStatus(Request $request){
        $status_id = $request->status_id;
        $result = Status::where('status_id', '=', $status_id)->delete();
        return response()->json(['result'=>$result]);
    }

    public function saveStatus(Request $request){
        $messages = array(
            'status_name.required' => 'Укажите Наименование'
        );
        $validator = Validator::make($request->all(), [
            'status_name' => 'required'
        ], $messages);

        if ($validator->fails()) {
            $messages = $validator->errors();
            $error = $messages->all();

            $result['value'] = $error;
            $result['status'] = false;
            $role_list = Role::all();
            return view('admin.status-edit', [ 'row' => $request, 'role_list' => $role_list, 'result' => $result ]);
        }

        if($request->status_id > 0) {
            $status_item = Status::find($request->status_id);
        }
        else {
            $status_item = new Status();
        }

        $status_item->status_name = $request->status_name;
        $status_item->status_color = $request->status_color;

        if($status_item->save()){
            return redirect('/admin/status-list');
        }
        else{
            $error[0] = 'Ошибка при сохранении';
            $result['value'] = $error;
            $result['status'] = false;
            $role_list = Role::all();
            return view('admin.status-edit', [ 'row' => $request, 'role_list' => $role_list, 'result' => $result ]);
        }
    }

    public function timezoneList(Request $request){
        $row_count = 20;
        if(isset($request->row_count)){
            $row_count = $request->row_count;
        }
        $row = Timezone::select('timezones.*');

        if(isset($request->search_word) && strlen($request->search_word) > 0){
            $row = $row->where("timezone_name","like","%" . $request->search_word . "%");
        }
        $row = $row->paginate($row_count);
        return view('admin.timezone-list', [ 'row' => $row, 'row_count' => $row_count,'search_word' => $request->search_word]);
    }

    public function timezoneEdit(Request $request){
        $timezone_id = $request->timezone_id;

        $row = Timezone::find($timezone_id);
        if(@count($row) < 1){
            $row = new Timezone();
            $row->timezone_id = 0;
        }
        return view('admin.timezone-edit', ['row' => $row]);
    }

    public function deleteTimezone(Request $request){
        $timezone_id = $request->timezone_id;
        $result = Timezone::where('timezone_id', '=', $timezone_id)->delete();
        return response()->json(['result'=>$result]);
    }

    public function saveTimezone(Request $request){
        $messages = array(
            'timezone_name.required' => 'Укажите Наименование'
        );
        $validator = Validator::make($request->all(), [
            'timezone_name' => 'required'
        ], $messages);

        if ($validator->fails()) {
            $messages = $validator->errors();
            $error = $messages->all();

            $result['value'] = $error;
            $result['timezone'] = false;
            $role_list = Role::all();
            return view('admin.timezone-edit', [ 'row' => $request, 'role_list' => $role_list, 'result' => $result ]);
        }

        if($request->timezone_id > 0) {
            $timezone_item = Timezone::find($request->timezone_id);
        }
        else {
            $timezone_item = new Timezone();
        }

        $timezone_item->timezone_name = $request->timezone_name;
        $timezone_item->timezone_value = $request->timezone_value;

        if($timezone_item->save()){
            return redirect('/admin/timezone-list');
        }
        else{
            $error[0] = 'Ошибка при сохранении';
            $result['value'] = $error;
            $result['timezone'] = false;
            $role_list = Role::all();
            return view('admin.timezone-edit', [ 'row' => $request, 'role_list' => $role_list, 'result' => $result ]);
        }
    }

    public function stationList(Request $request){
        $row_count = 20;
        if(isset($request->row_count)){
            $row_count = $request->row_count;
        }
        $row = Station::LeftJoin("regions","stations.station_region_id","=","regions.region_id")->select('stations.*',"regions.*");

        if(isset($request->search_word) && strlen($request->search_word) > 0){
            $row = $row->where("station_name","like","%" . $request->search_word . "%");
        }
        $row = $row->paginate($row_count);
        return view('admin.station-list', [ 'row' => $row, 'row_count' => $row_count,'search_word' => $request->search_word]);
    }

    public function stationEdit(Request $request){
        $station_id = $request->station_id;

        $row = Station::find($station_id);
        if(@count($row) < 1){
            $row = new Station();
            $row->station_id = 0;
        }
        return view('admin.station-edit', ['row' => $row]);
    }

    public function deleteStation(Request $request){
        $station_id = $request->station_id;
        $result = Station::where('station_id', '=', $station_id)->delete();
        return response()->json(['result'=>$result]);
    }

    public function saveStation(Request $request){
        $messages = array(
            'station_name.required' => 'Укажите Станцию назначения'
        );
        $validator = Validator::make($request->all(), [
            'station_name' => 'required'
        ], $messages);

        if ($validator->fails()) {
            $messages = $validator->errors();
            $error = $messages->all();

            $result['value'] = $error;
            $result['station'] = false;
            $role_list = Role::all();
            return view('admin.station-edit', [ 'row' => $request, 'role_list' => $role_list, 'result' => $result ]);
        }

        if($request->station_id > 0) {
            $station_item = Station::find($request->station_id);
        }
        else {
            $station_item = new Station();
        }

        $station_item->station_name = $request->station_name;
        $station_item->station_code = $request->station_code;
        $station_item->station_km = $request->station_km;
        $station_item->station_region_id = $request->station_region_id;
        $station_item->station_rate = $request->station_rate;
        $station_item->station_rate_nds = $request->station_rate_nds;
        $station_item->station_brand_id = $request->station_brand_id;

        if($station_item->save()){
            return redirect('/admin/station-list');
        }
        else{
            $error[0] = 'Ошибка при сохранении';
            $result['value'] = $error;
            $result['station'] = false;
            return view('admin.station-edit', [ 'row' => $request, 'result' => $result ]);
        }
    }

    public function profile(){
        $row = Users::where('user_id','=',Auth::user()->user_id)->first();
        $role_list = Role::all();
        return view('admin.profile', [ 'row' => $row, 'role_list' => $role_list ]);
    }

    public function updateProfileInfo(Request $request){
        $row = Users::where('user_id','=',Auth::user()->user_id)->first();

        if(@count($row) > 0){
            if(strlen($row->password) > 0 && strlen($request->new_password) > 0 && strlen($request->repeat_password) > 0){
                $check_old_pass = Hash::check($request->password, $row->password);
                if($check_old_pass == false){
                    return response()->json(['result'=>'incorrect_password']);
                }

                if($request->new_password != $request->repeat_password){
                    return response()->json(['result'=>'incorrect_repeat']);
                }

                $row->password = Hash::make($request->new_password);
            }

            $row->user_surname = $request->user_surname;
            $row->user_name = $request->user_name;
            $row->user_phone = $request->user_phone;
            $row->email = $request->email;
            $row->user_role_id = $request->user_role_id;
            if($row->save()){
                return response()->json(['result'=>true]);
            }
            else{
                return response()->json(['result'=>false]);
            }
        }
        else{
            return response()->json(['result'=>"incorrect_user"]);
        }
    }


    public function clientList(Request $request){
        $row_count = 20;
        if(isset($request->row_count)){
            $row_count = $request->row_count;
        }
        $row = Client::LeftJoin("companies","clients.client_company_id","=","companies.company_id")
                        ->select('clients.*',"companies.*");

        if(isset($request->search_word) && strlen($request->search_word) > 0){
            $row = $row->where(function($query) use ($request)
            {
                $query->where("companies.company_name","like","%" . $request->search_word . "%")->orWhere("client_name","like","%" . $request->search_word . "%")->orWhere("client_surname","like","%" . $request->search_word . "%");
            });
        }
        $row = $row->paginate($row_count);
        return view('admin.client-list', [ 'row' => $row, 'row_count' => $row_count,'search_word' => $request->search_word]);
    }

    public function clientEdit(Request $request){
        $client_id = $request->client_id;

        $row = Client::LeftJoin("stations","clients.client_station_id","=","stations.station_id")
                    ->LeftJoin("regions","clients.client_region_id","=","regions.region_id")
                    ->select("clients.*","stations.station_name","regions.region_name")
                    ->where("client_id","=",$client_id)->first();
        $company_row = null;
        if(@count($row) < 1){
            $row = new Client();
            $row->client_id = 0;
        }
        else{
            $company_row = Company::where("company_id","=",$row['client_company_id'])->first();
        }

        return view('admin.client-edit', ['row' => $row, 'company_row' => $company_row]);
    }

    public function deleteClient(Request $request){
        $client_id = $request->client_id;
        $result = Client::where('client_id', '=', $client_id)->delete();
        return response()->json(['result'=>$result]);
    }

    public function saveClient(Request $request){
        if($request->client_id > 0) {
            $client_item = Client::find($request->client_id);
        }
        else {
            $client_item = new Client();
        }

        $client_item->client_name = $request->client_name;
        $client_item->client_surname = $request->client_surname;
        $client_item->client_phone = $request->client_phone;
        $client_item->client_email = $request->client_email;
        $client_item->client_region_id = $request->client_region_id;
        $client_item->client_station_id = $request->client_station_id;
        $client_item->client_receiver_code = $request->client_receiver_code;
        $client_item->client_company_id = $request->client_company_id;

        if($client_item->save()){
            return response()->json(['result'=>true]);
        }
        else{
            return response()->json(['result'=>false]);
        }
    }

    public function getRegionList(Request $request){
        $region_list = Region::where("region_name","like","%" . $request->region_search_str . "%")->get();
        return response()->json(['region_list'=>$region_list]);
    }

    public function getStationList(Request $request){
        $station_list = Station::where("station_name","like","%" . $request->station_search_str . "%")->get();
        return response()->json(['station_list'=>$station_list]);
    }

    public function getCompanyList(Request $request){
        $company_list = Company::where("company_name","like","%" . $request->company_search_str . "%")->get();
        return response()->json(['company_list'=>$company_list]);
    }

    public function getClientList(Request $request){
        $client_list = Client::where("client_surname","like","%" . $request->client_search_str . "%")->orWhere("client_name","like","%" . $request->client_search_str . "%")->get();
        return response()->json(['client_list'=>$client_list]);
    }

    public function getStation(Request $request){
        $station_row = Station::find($request->station_id);
        return response()->json(['station_row'=>$station_row]);
    }

    public function changeDealType(Request $request){
        $deal_row = Deal::where("deal_id","=",$request->deal_id)->first();
        if(@count($deal_row) > 0){
            if($deal_row['deal_status_id'] >= 3){
                $deal_row->deal_type_id = $request->deal_type_id;
                if($deal_row->save()){
                    return response()->json(['result'=>true]);
                }
                else{
                    return response()->json(['result'=>false]);
                }
            }
            else{
                return response()->json(['result'=>'incorrect_status']);
            }
        }
        else{
            return response()->json(['result'=>false]);
        }
    }

    public function dealList(Request $request){
        $row_count = 20;
        if(isset($request->row_count)){
            $row_count = $request->row_count;
        }
        $row = Deal::LeftJoin("clients","deals.deal_client_id","=","clients.client_id")
                    ->LeftJoin("statuses","deals.deal_status_id","=","statuses.status_id")
                    ->LeftJoin("stations","deals.deal_station_id","=","stations.station_id")
                    ->LeftJoin("marks","deals.deal_mark_id","=","marks.mark_id")
                    ->select('deals.*',"clients.client_name","clients.client_surname", "statuses.status_name", "statuses.status_color", "stations.*", "marks.*", DB::raw('DATE_FORMAT(deals.deal_datetime1,"%d.%m.%Y %T") as deal_datetime1_format'));

        if(isset($request->deal_type_id) && strlen($request->deal_type_id) > 0){
            $row = $row->where("deals.deal_type_id","=",$request->deal_type_id);
        }

        if(isset($request->client_id) && $request->client_id > 0){
            $row = $row->where("deals.deal_client_id","=",$request->client_id);
        }

        if(isset($request->status_id) && $request->status_id > 0 && $request->type != "cards"){
            $row = $row->where("deals.deal_status_id","=",$request->status_id);
        }

        if(isset($request->user_id) && $request->user_id > 0){
            $row = $row->where(function($query) use ($request)
            {
                $query->orWhere("deals.deal_user_id1","=",$request->user_id)->orWhere("deals.deal_user_id2","=",$request->user_id)
                      ->orWhere("deals.deal_user_id3","=",$request->user_id)->orWhere("deals.deal_user_id4","=",$request->user_id)
                      ->orWhere("deals.deal_user_id5","=",$request->user_id)->orWhere("deals.deal_user_id6","=",$request->user_id)
                      ->orWhere("deals.deal_user_id7","=",$request->user_id)->orWhere("deals.deal_user_id8","=",$request->user_id)
                      ->orWhere("deals.deal_user_id9","=",$request->user_id);
            });
        }

        if(isset($request->date_from) && strlen($request->date_from) > 0 && isset($request->date_to) && strlen($request->date_to) > 0){
            $from = date('Y-m-d 00:00:00',strtotime($request->date_from));
            $to = date('Y-m-d 23:59:59',strtotime($request->date_to));
            $row = $row->whereBetween('deals.deal_datetime1', array($from, $to));
        }

        if(isset($request->search_word) && strlen($request->search_word) > 0){
            $row = $row->where(function($query) use ($request)
            {
                $query->where("stations.station_name","like","%" . $request->search_word . "%")->orWhere("marks.mark_name","like","%" . $request->search_word . "%");
            });
        }

        $row_item = $row->get();
        if($request->type == "cards"){
            $row_list[1] = $row_item->where("deal_status_id","=",1);
            $row_list[2] = $row_item->where("deal_status_id","=",2);
            $row_list[3] = $row_item->where("deal_status_id","=",3);
            $row_list[4] = $row_item->where("deal_status_id","=",4);
            $row_list[5] = $row_item->where("deal_status_id","=",5);
            $row_list[6] = $row_item->where("deal_status_id","=",6);
            $row_list[7] = $row_item->where("deal_status_id","=",7);
            $row_list[8] = $row_item->where("deal_status_id","=",8);
            $row_list[9] = $row_item->where("deal_status_id","=",9);
        }

        $row = $row->paginate($row_count);

        $status_list = Status::orderBy("status_id","asc")->get();
        $client_list = Client::orderBy("client_name","asc")->get();
        $user_list = Users::orderBy("user_surname","asc")->get();

        if($request->type == "cards"){
            return view('admin.deal-cards', [ 'row_list' => $row_list, 'row_count' => $row_count,'search_word' => $request->search_word, 'deal_type_id' => $request->deal_type_id, 'client_id' => $request->client_id, 'status_id' => $request->status_id, 'user_id' => $request->user_id, 'date_from' => $request->date_from, 'date_to' => $request->date_to, 'status_list' => $status_list, 'client_list' => $client_list, 'user_list' => $user_list]);
        }
        else{
            return view('admin.deal-list', [ 'row' => $row, 'row_count' => $row_count,'search_word' => $request->search_word, 'deal_type_id' => $request->deal_type_id, 'client_id' => $request->client_id, 'status_id' => $request->status_id, 'user_id' => $request->user_id, 'date_from' => $request->date_from, 'date_to' => $request->date_to, 'status_list' => $status_list, 'client_list' => $client_list, 'user_list' => $user_list]);
        }
    }

    public function dealEdit(Request $request){
        $deal_id = $request->deal_id;

        $row = Deal::LeftJoin("clients","deals.deal_client_id","=","clients.client_id")
                    ->LeftJoin("brands","deals.deal_brand_id","=","brands.brand_id")
                    ->LeftJoin("marks","deals.deal_mark_id","=","marks.mark_id")
                    ->LeftJoin("fractions","deals.deal_fraction_id","=","fractions.fraction_id")
                    ->LeftJoin("regions","deals.deal_region_id","=","regions.region_id")
                    ->LeftJoin("stations","deals.deal_station_id","=","stations.station_id")
                    ->LeftJoin("companies","clients.client_company_id","=","companies.company_id")
//                    ->LeftJoin("users as users1","deals.deal_user_id1","=","users1.user_id")
//                    ->LeftJoin("users as users2","deals.deal_user_id2","=","users2.user_id")
//                    ->LeftJoin("users as users3","deals.deal_user_id3","=","users3.user_id")
//                    ->LeftJoin("users as users4","deals.deal_user_id4","=","users4.user_id")
//                    ->LeftJoin("users as users5","deals.deal_user_id5","=","users5.user_id")
//                    ->LeftJoin("users as users6","deals.deal_user_id6","=","users6.user_id")
//                    ->LeftJoin("users as users7","deals.deal_user_id7","=","users7.user_id")
//                    ->LeftJoin("users as users8","deals.deal_user_id8","=","users8.user_id")
//                    ->LeftJoin("users as users9","deals.deal_user_id9","=","users9.user_id")
                    ->select("deals.*","clients.*","brands.*","marks.*","fractions.*","regions.*","stations.*",
                            "companies.*",
                            DB::raw('DATE_FORMAT(deals.deal_datetime1,"%d.%m.%Y %T") as deal_datetime1_format'),
                            DB::raw('DATE_FORMAT(deals.deal_datetime2,"%d.%m.%Y %T") as deal_datetime2_format'),
                            DB::raw('DATE_FORMAT(deals.deal_datetime3,"%d.%m.%Y %T") as deal_datetime3_format'),
                            DB::raw('DATE_FORMAT(deals.deal_datetime4,"%d.%m.%Y %T") as deal_datetime4_format'),
                            DB::raw('DATE_FORMAT(deals.deal_datetime5,"%d.%m.%Y %T") as deal_datetime5_format'),
                            DB::raw('DATE_FORMAT(deals.deal_datetime6,"%d.%m.%Y %T") as deal_datetime6_format'),
                            DB::raw('DATE_FORMAT(deals.deal_datetime7,"%d.%m.%Y %T") as deal_datetime7_format'),
                            DB::raw('DATE_FORMAT(deals.deal_datetime8,"%d.%m.%Y %T") as deal_datetime8_format'),
                            DB::raw('DATE_FORMAT(deals.deal_datetime9,"%d.%m.%Y %T") as deal_datetime9_format'),
                            DB::raw('DATE_FORMAT(deals.deal_shipping_date,"%d/%m/%Y") as deal_shipping_date'),
                            DB::raw('DATE_FORMAT(deals.deal_delivery_date,"%d/%m/%Y") as deal_delivery_date')
                            )
                    ->where("deal_id","=",$deal_id)->first();
        if(@count($row) < 1){
            $row = new Deal();
            $row->deal_id = 0;
        }

        $user_list = Users::orderBy("user_surname")->get();
        $brand_list = Brand::orderBy("brand_name")->get();
        $mark_list = Mark::orderBy("mark_name")->get();
        $fraction_list = Fraction::orderBy("fraction_name")->get();
        $region_list = Region::orderBy("region_name")->get();
        $station_list = Station::orderBy("station_name")->get();
        $payment_list = Payment::orderBy("payment_name")->get();
        $bank_list = Bank::orderBy("bank_name")->get();
        $delivery_list = Delivery::orderBy("delivery_name")->get();
        $client_list = Client::orderBy("client_surname")->get();

        $deal_brand_files = DealFile::select("deal_files.*",DB::raw('DATE_FORMAT(deal_files.deal_file_date,"%d.%m.%Y %T") as deal_file_date_format'))->where("deal_file_type","=",4)->get();
        $deal_other_files = DealFile::select("deal_files.*",DB::raw('DATE_FORMAT(deal_files.deal_file_date,"%d.%m.%Y %T") as deal_file_date_format'))->where("deal_file_type","=",5)->get();

        return view('admin.deal-edit', ['row' => $row, 'user_list' => $user_list, 'brand_list' => $brand_list,
                'mark_list' => $mark_list, 'fraction_list' => $fraction_list, 'region_list' => $region_list,
                'station_list' => $station_list, 'payment_list' => $payment_list, 'bank_list' => $bank_list,
                'deal_brand_files' => $deal_brand_files, 'delivery_list' => $delivery_list, 'client_list' => $client_list,
                'deal_other_files' => $deal_other_files]);
    }

    public function deleteDeal(Request $request){
        $deal_id = $request->deal_id;
        $result = Deal::where('deal_id', '=', $deal_id)->delete();
        return response()->json(['result'=>$result]);
    }

    public function saveDealInfo(Request $request){
        if($request->deal_id > 0){
            $deal_row = Deal::find($request->deal_id);
        }
        else{
            $deal_row = new Deal();
        }

        if(!($request->deal_status_id == 1 && $deal_row->deal_status_id == null) &&  $request->deal_status_id > $deal_row->deal_status_id){
            return response()->json(['result'=>'incorrect_status']);
        }

        $deal_history_str = "";
        $user_id_process = null;
        if($request->deal_status_id == 1){
            if($request->deal_client_id != $deal_row->deal_client_id){
                $deal_history_str .= "<b>Клиент:</b> " . $request->client_surname . " " . $request->client_name . "<br>";
            }

            if($request->deal_user_id1 != $deal_row->deal_user_id1){
                $user_row = Users::where("user_id","=",$request->deal_user_id1)->first();
                $deal_history_str .= "<b>Ответственный:</b> " . $user_row->user_surname . " " . $user_row->user_name . "<br>";
            }
            $user_id_process = $request->deal_user_id1;

            if($request->deal_client_id > 0){
                $deal_row->deal_client_id = $request->deal_client_id;
            }
            else{
                $new_client = new Client();
                $client_fio_parts = explode(" ",$request->client_fio);
                if(@count($client_fio_parts) > 0){
                   if(isset($client_fio_parts[0])){
                       $new_client->client_surname = $client_fio_parts[0];
                   }
                   if(isset($client_fio_parts[1])){
                       $new_client->client_name = $client_fio_parts[1];
                   }
                }
                $new_client->client_phone = $request->client_phone;
                $new_client->client_email = $request->client_email;
                $new_client->save();
                $deal_row->deal_client_id = $new_client->client_id;
            }
            if($request->deal_id < 1){
                $deal_row->deal_user_id2 = $request->deal_user_id1;
                $deal_row->deal_user_id3 = $request->deal_user_id1;
                $deal_row->deal_user_id4 = $request->deal_user_id1;
            }

            $offset= strtotime("+6 hours 0 minutes");
            $deal_row->deal_datetime1 = date("Y-m-d H:i:s", $offset);
            $deal_row->deal_user_id1 = $request->deal_user_id1;
        }
        else if($request->deal_status_id == 2){
            $station_row = Station::where("station_id","=", $request->deal_station_id)->first();
            $region_row = Region::where("region_id","=",$request->deal_region_id)->first();

            $percents_row = Station::LeftJoin("percents","stations.station_brand_id","=","percents.percent_brand_id")
                ->select("percents.*")
                ->where("stations.station_id","=",$request->deal_station_id)
                ->first();
            $sum = 0;
            if(@count($percents_row) > 0){
                if($percents_row->percent_rate > 0){
                    $sum = (($station_row['station_rate_nds']+$region_row['region_price_nds'])+ ($station_row['station_rate_nds']+$region_row['region_price_nds'])*$percents_row['percent_rate']/100)*$request->deal_volume;
                }
                else{
                    $sum = ($station_row['station_rate_nds']+$region_row['region_price_nds']+$percents_row['percent_sum_rate'])*$request->deal_volume;
                }
            }

            if($request->deal_brand_id != $deal_row->deal_brand_id){
                $brand_row = Brand::where("brand_id","=",$request->deal_brand_id)->first();
                $deal_history_str .= "<b>Разрез:</b> " . $brand_row->brand_name . "<br>";
            }
            if($request->deal_mark_id != $deal_row->deal_mark_id){
                $mark_row = Mark::where("mark_id","=",$request->deal_mark_id)->first();
                $deal_history_str .= "<b>Марка:</b> " . $mark_row->mark_name . "<br>";
            }
            if($request->deal_fraction_id != $deal_row->deal_fraction_id){
                $fraction_row = Fraction::where("fraction_id","=",$request->deal_fraction_id)->first();
                $deal_history_str .= "<b>Фракция:</b> " . $fraction_row->fraction_name . "<br>";
            }
            if($request->deal_volume != $deal_row->deal_volume){
                $deal_history_str .= "<b>Объем в тоннах:</b> " . $request->deal_volume . "<br>";
            }
            if($request->deal_region_id != $deal_row->deal_region_id){
                $deal_history_str .= "<b>Область:</b> " . $region_row->region_name . "<br>";
            }
            if($request->deal_station_id != $deal_row->deal_station_id){
                $deal_history_str .= "<b>Станция:</b> " . $station_row->station_name . "<br>";
            }
            if($sum != $deal_row->deal_kp_sum){
                $deal_history_str .= "<b>Цена за 1 тонну + доставка + НДС:</b> " . floor($sum) . "<br>";
            }

            if($request->deal_user_id2 != $deal_row->deal_user_id2){
                $user_row = Users::where("user_id","=",$request->deal_user_id2)->first();
                $deal_history_str .= "<b>Ответственный:</b> " . $user_row->user_surname . " " . $user_row->user_name . "<br>";
            }
            $user_id_process = $request->deal_user_id2;

            $deal_row->deal_brand_id = $request->deal_brand_id;
            $deal_row->deal_mark_id = $request->deal_mark_id;
            $deal_row->deal_fraction_id = $request->deal_fraction_id;
            $deal_row->deal_volume = $request->deal_volume;
            $deal_row->deal_region_id = $request->deal_region_id;
            $deal_row->deal_station_id = $request->deal_station_id;

            $deal_row->deal_kp_sum = $sum;

            $offset= strtotime("+6 hours 0 minutes");
            $deal_row->deal_datetime2 = date("Y-m-d H:i:s", $offset);
            $deal_row->deal_user_id2 = $request->deal_user_id2;
        }
        else if($request->deal_status_id == 3){
            if($request->deal_discount_type != $deal_row->deal_discount_type || $request->deal_discount != $deal_row->deal_discount){
                $discount_str = " тг.";
                if($request->deal_discount_type == 1){
                    $discount_str = " %";
                }
                $deal_history_str .= "<b>Скидка:</b> " . $request->deal_discount . $discount_str . "<br>";
            }
            if($request->deal_user_id3 != $deal_row->deal_user_id3){
                $user_row = Users::where("user_id","=",$request->deal_user_id3)->first();
                $deal_history_str .= "<b>Ответственный:</b> " . $user_row->user_surname . " " . $user_row->user_name . "<br>";
            }
            $user_id_process = $request->deal_user_id3;

            if($request->deal_discount_type == "on"){
                $deal_row->deal_discount_type = 1;
            }
            $deal_row->deal_discount = $request->deal_discount;

            $offset= strtotime("+6 hours 0 minutes");
            $deal_row->deal_datetime3 = date("Y-m-d H:i:s", $offset);
            $deal_row->deal_user_id3 = $request->deal_user_id3;
        }
        else if($request->deal_status_id == 4){
            if($request->deal_payment_id != $deal_row->deal_payment_id){
                $payment_row = Payment::where("payment_id","=",$request->deal_payment_id)->first();
                $deal_history_str .= "<b>Тип оплаты:</b> " . $payment_row->payment_name . "<br>";
            }
            if($request->deal_delivery_id != $deal_row->deal_delivery_id){
                $delivery_row = Delivery::where("delivery_id","=",$request->deal_delivery_id)->first();
                $deal_history_str .= "<b>Срок доставки:</b> " . $delivery_row->delivery_name . "<br>";
            }
            if($request->deal_receiver_code != $deal_row->deal_receiver_code){
                $deal_history_str .= "<b>Код получателя:</b> " . $request->deal_receiver_code . "<br>";
            }
            if($request->deal_user_id4 != $deal_row->deal_user_id4){
                $user_row = Users::where("user_id","=",$request->deal_user_id4)->first();
                $deal_history_str .= "<b>Ответственный:</b> " . $user_row->user_surname . " " . $user_row->user_name . "<br>";
            }

            $deal_row->deal_payment_id = $request->deal_payment_id;
            $deal_row->deal_delivery_id = $request->deal_delivery_id;

            if($request->company_id > 0){
                $deal_client_row = Client::where("client_id","=",$deal_row->deal_client_id)->first();
                $deal_client_row->client_company_id = $request->company_id;
                $deal_client_row->save();
            }
            else{
                $new_company_row = new Company();
                $new_company_row->company_name = $request->company_name;
                $new_company_row->company_ceo_position = $request->company_ceo_position;
                $new_company_row->company_ceo_name = $request->company_ceo_name;
                $new_company_row->company_address = $request->company_address;
                $new_company_row->company_bank_id = $request->company_bank_id;
                $new_company_row->company_bank_iik = $request->company_bank_iik;
                $new_company_row->company_bank_bin = $request->company_bank_bin;
                $new_company_row->company_delivery_address = $request->company_delivery_address;
                $new_company_row->company_okpo = $request->company_okpo;
                $new_company_row->save();

                $deal_client_row = Client::where("client_id","=",$deal_row->deal_client_id)->first();
                $deal_client_row->client_company_id = $new_company_row->company_id;
                $deal_client_row->save();
            }

            $deal_row->deal_receiver_code = $request->deal_receiver_code;

            $offset= strtotime("+6 hours 0 minutes");
            $deal_row->deal_datetime4 = date("Y-m-d H:i:s", $offset);
            $deal_row->deal_user_id4 = $request->deal_user_id4;
        }
        else if($request->deal_status_id == 5){
            if($request->deal_user_id5 != $deal_row->deal_user_id5){
                $user_row = Users::where("user_id","=",$request->deal_user_id5)->first();
                $deal_history_str .= "<b>Ответственный:</b> " . $user_row->user_surname . " " . $user_row->user_name . "<br>";
            }

            $offset= strtotime("+6 hours 0 minutes");
            $deal_row->deal_datetime5 = date("Y-m-d H:i:s", $offset);
            $deal_row->deal_user_id5 = $request->deal_user_id5;
        }
        else if($request->deal_status_id == 6){
            if($request->deal_user_id6 != $deal_row->deal_user_id6){
                $user_row = Users::where("user_id","=",$request->deal_user_id6)->first();
                $deal_history_str .= "<b>Ответственный:</b> " . $user_row->user_surname . " " . $user_row->user_name . "<br>";
            }

            $offset= strtotime("+6 hours 0 minutes");
            $deal_row->deal_datetime6 = date("Y-m-d H:i:s", $offset);
            $deal_row->deal_user_id6 = $request->deal_user_id6;
        }
        else if($request->deal_status_id == 7){
            if($request->deal_brand_sum != $deal_row->deal_brand_sum){
                $deal_history_str .= "<b>Сумма оплаты:</b> " . $request->deal_brand_sum . "<br>";
            }
            if($request->deal_user_id7 != $deal_row->deal_user_id7){
                $user_row = Users::where("user_id","=",$request->deal_user_id7)->first();
                $deal_history_str .= "<b>Ответственный:</b> " . $user_row->user_surname . " " . $user_row->user_name . "<br>";
            }

            $deal_row->deal_brand_sum = $request->deal_brand_sum;

            $offset= strtotime("+6 hours 0 minutes");
            $deal_row->deal_datetime7 = date("Y-m-d H:i:s", $offset);
            $deal_row->deal_user_id7 = $request->deal_user_id7;
        }
        else if($request->deal_status_id == 8){
            if($request->deal_shipping_date != $deal_row->deal_shipping_date){
                $deal_history_str .= "<b>Дата отгрузки:</b> " . date('d.m.Y', strtotime($request->deal_shipping_date)) . "<br>";
            }
            if($request->deal_shipping_time != $deal_row->deal_shipping_time){
                $deal_history_str .= "<b>Время отгрузки:</b> " . $request->deal_shipping_time . "<br>";
            }
            if($request->deal_user_id8 != $deal_row->deal_user_id8){
                $user_row = Users::where("user_id","=",$request->deal_user_id8)->first();
                $deal_history_str .= "<b>Ответственный:</b> " . $user_row->user_surname . " " . $user_row->user_name . "<br>";
            }

            $deal_row->deal_shipping_date = date('Y-m-d', strtotime($request->deal_shipping_date));
            $deal_row->deal_shipping_time = $request->deal_shipping_time;

            $offset= strtotime("+6 hours 0 minutes");
            $deal_row->deal_datetime8 = date("Y-m-d H:i:s", $offset);
            $deal_row->deal_user_id8 = $request->deal_user_id8;
        }
        else if($request->deal_status_id == 9){
            if($request->deal_delivery_date != $deal_row->deal_delivery_date){
                $deal_history_str .= "<b>Дата доставки:</b> " . date('d.m.Y', strtotime($request->deal_delivery_date)) . "<br>";
            }
            if($request->deal_delivery_time != $deal_row->deal_delivery_time){
                $deal_history_str .= "<b>Время доставки:</b> " . $request->deal_delivery_time . "<br>";
            }
            if($request->deal_user_id9 != $deal_row->deal_user_id9){
                $user_row = Users::where("user_id","=",$request->deal_user_id9)->first();
                $deal_history_str .= "<b>Ответственный:</b> " . $user_row->user_surname . " " . $user_row->user_name . "<br>";
            }

            $deal_row->deal_delivery_date = date('Y-m-d', strtotime($request->deal_delivery_date));
            $deal_row->deal_delivery_time = $request->deal_delivery_time;

            $offset= strtotime("+6 hours 0 minutes");
            $deal_row->deal_datetime9 = date("Y-m-d H:i:s", $offset);
            $deal_row->deal_user_id9 = $request->deal_user_id9;
            $deal_row->deal_type_id = 1;
        }

        if($request->deal_status_id != 9){
            $deal_row->deal_type_id = 0;
        }

        if($deal_row->deal_status_id == null){
            $deal_row->deal_status_id = 2;
        }
        else if($request->deal_status_id == $deal_row->deal_status_id){
            if($deal_row->deal_status_id + 1 < 10){
                $deal_row->deal_status_id = $deal_row->deal_status_id + 1;
            }
        }
        if($deal_row->save()){
            if(strlen($deal_history_str) > 0){
                $new_deal_history = new DealHistory();
                $new_deal_history->deal_history_deal_id = $deal_row->deal_id;
                $new_deal_history->deal_history_user_id = $user_id_process;
                $offset= strtotime("+6 hours 0 minutes");
                $new_deal_history->deal_history_datetime = date("Y-m-d H:i:s", $offset);
                $new_deal_history->deal_history_text = $deal_history_str;
                $new_deal_history->save();
            }

            if($deal_row['deal_status_id'] == 7){
                $deal_template_file_row = DealTemplateFile::where("deal_template_type_id","=",3)->first();
                $deal_template_text = $this->replaceDealFileTemplate($deal_template_file_row['deal_template_text'],$request->deal_id);

//        return view('admin.test-pdf', [ 'deal_template_text' => $deal_template_text]);
                $pdf = PDF::loadView('admin.test-pdf',['deal_template_text' => $deal_template_text]);
                $deal_file_src = time() . $request->deal_id . '_kp.pdf';
                $pdf->save('deal_files/' . $deal_file_src);

                $new_deal_file = new DealFile();
                $new_deal_file->deal_file_deal_id = $request->deal_id;
                $new_deal_file->deal_file_name = $deal_file_src;
                $new_deal_file->deal_file_src = $deal_file_src;
                $new_deal_file->deal_file_type = 4;
                $offset= strtotime("+6 hours 0 minutes");
                $new_deal_file->deal_file_date = date("Y-m-d H:i:s",$offset);
                if($new_deal_file->save()){
                    $email_to = "adik.khalikhov@mail.ru";
                    $message_str = 'Уважаемый (-ая), <br>Ваш пароль для входа в личный кабинет: ';
                    Mail::send(['html' => 'admin.email-kp'], ['text' => $message_str], function($message) use ($email_to,$new_deal_file)
                    {
                        $message->to($email_to)->subject("Заявка разрезу");
                        $message->attach("deal_files/" . $new_deal_file['deal_file_src'], ['as' => $new_deal_file['deal_file_name'], 'mime' => 'application/pdf']);
                    });
                    if(@count(Mail::failures()) > 0){
                        return response()->json(['result'=>'error_send_brand_mail']);
                    }
                }
                else{
                    return response()->json(['result'=>'error_save_brand_file']);
                }
            }

            $deal_row_new = Deal::LeftJoin("clients","deals.deal_client_id","=","clients.client_id")
                ->LeftJoin("brands","deals.deal_brand_id","=","brands.brand_id")
                ->LeftJoin("marks","deals.deal_mark_id","=","marks.mark_id")
                ->LeftJoin("fractions","deals.deal_fraction_id","=","fractions.fraction_id")
                ->LeftJoin("regions","deals.deal_region_id","=","regions.region_id")
                ->LeftJoin("stations","deals.deal_station_id","=","stations.station_id")
                ->LeftJoin("companies","clients.client_company_id","=","companies.company_id")
                ->select("deals.*","clients.*","brands.*","marks.*","fractions.*","regions.*","stations.*",
                    "companies.*",
                    DB::raw('DATE_FORMAT(deals.deal_datetime1,"%d.%m.%Y %T") as deal_datetime1_format'),
                    DB::raw('DATE_FORMAT(deals.deal_datetime2,"%d.%m.%Y %T") as deal_datetime2_format'),
                    DB::raw('DATE_FORMAT(deals.deal_datetime3,"%d.%m.%Y %T") as deal_datetime3_format'),
                    DB::raw('DATE_FORMAT(deals.deal_datetime4,"%d.%m.%Y %T") as deal_datetime4_format'),
                    DB::raw('DATE_FORMAT(deals.deal_datetime5,"%d.%m.%Y %T") as deal_datetime5_format'),
                    DB::raw('DATE_FORMAT(deals.deal_datetime6,"%d.%m.%Y %T") as deal_datetime6_format'),
                    DB::raw('DATE_FORMAT(deals.deal_datetime7,"%d.%m.%Y %T") as deal_datetime7_format'),
                    DB::raw('DATE_FORMAT(deals.deal_datetime8,"%d.%m.%Y %T") as deal_datetime8_format'),
                    DB::raw('DATE_FORMAT(deals.deal_datetime9,"%d.%m.%Y %T") as deal_datetime9_format'),
                    DB::raw('DATE_FORMAT(deals.deal_shipping_date,"%d/%m/%Y") as deal_shipping_date'),
                    DB::raw('DATE_FORMAT(deals.deal_delivery_date,"%d/%m/%Y") as deal_delivery_date')
                )
                ->where("deal_id","=",$deal_row['deal_id'])->first();

            return response()->json(['result'=>true, 'deal_row' => $deal_row_new]);
        }
        else{
            return response()->json(['result'=>false]);
        }
    }

    public function uploadDealFile(Request $request){
        if(!(isset($request->brand_deal_file_src))){
            $result['success'] = "not_file";
            return $result;
        }
        $file = $request->brand_deal_file_src;
        $original_file_name = $file->getClientOriginalName();
        $file_name = time() . $request->deal_id . "_brands_file.";
        $file_extension = $file->extension($file_name);
        $file_name = $file_name . $file_extension;
        Storage::disk('deal_files')->put($file_name,  File::get($file));

        $new_deal_file = new DealFile();
        $new_deal_file->deal_file_deal_id = $request->deal_id;
        $new_deal_file->deal_file_name = $original_file_name;
        $new_deal_file->deal_file_src = $file_name;
        $new_deal_file->deal_file_type = $request->deal_file_type;
        $offset= strtotime("+6 hours 0 minutes");
        $new_deal_file->deal_file_date = date("Y-m-d H:i:s",$offset);
        $deal_file_date = date("d.m.Y H:i:s",$offset);
        if($new_deal_file->save()){
            $result['success'] = true;
            $result['deal_file_name'] = $original_file_name;
            $result['deal_file_src'] = $file_name;
            $result['deal_file_date'] = $deal_file_date;
            $result['deal_file_id'] = $new_deal_file->deal_file_id;
            $result['deal_file_deal_id'] = $new_deal_file->deal_file_deal_id;
        }
        else{
            $result['success'] = false;
            $result['file_name'] = "";
        }
        return $result;
    }

    public function uploadDealOtherFile(Request $request){

        if(!(isset($request->deal_file_src))){
            $result['success'] = "not_file";
            return $result;
        }
        $file = $request->deal_file_src;
        $original_file_name = $file->getClientOriginalName();
        $file_name = time() . $request->deal_id . rand(1, 100) . "_other_file.";
        $file_extension = $file->extension($file_name);
        $file_name = $file_name . $file_extension;
        Storage::disk('deal_files')->put($file_name,  File::get($file));

        $new_deal_file = new DealFile();
        $new_deal_file->deal_file_deal_id = $request->deal_id;
        $new_deal_file->deal_file_name = $original_file_name;
        $new_deal_file->deal_file_src = $file_name;
        $new_deal_file->deal_file_type = $request->deal_file_type;
        $offset= strtotime("+6 hours 0 minutes");
        $new_deal_file->deal_file_date = date("Y-m-d H:i:s",$offset);
        $deal_file_date = date("d.m.Y H:i:s",$offset);
        if($new_deal_file->save()){
            $result['success'] = true;
            $result['deal_file_name'] = $original_file_name;
            $result['deal_file_src'] = $file_name;
            $result['deal_file_date'] = $deal_file_date;
            $result['deal_file_id'] = $new_deal_file['deal_file_id'];
            $result['deal_file_deal_id'] = $new_deal_file['deal_file_deal_id'];
        }
        else{
            $result['success'] = false;
            $result['file_name'] = "";
        }
        return $result;
    }

    function saveNewUserTask(Request $request){
        if(strtotime($request->user_task_end_date) < strtotime($request->user_task_start_date)){
            return response()->json(['result'=>'incorrect_date']);
        }
        $new_task = new UserTask();
        $new_task->user_task_deal_id = $request->deal_id;
        $new_task->user_task_user_id = $request->user_task_user_id;
        $new_task->user_task_text = $request->user_task_text;
        $new_task->user_task_start_date = date('Y-m-d', strtotime($request->user_task_start_date));
        $new_task->user_task_start_time = $request->user_task_start_time;
        $new_task->user_task_end_date = date('Y-m-d', strtotime($request->user_task_end_date));
        $new_task->user_task_end_time = $request->user_task_end_time;
        $new_task->user_task_task_id = 1;

        if($new_task->save()){
            $user_row = Users::where("user_id","=",$request->user_task_user_id)->first();
            $deal_row = Deal::LeftJoin("stations","deals.deal_station_id","=","stations.station_id")
                        ->LeftJoin("marks","deals.deal_mark_id","=","marks.mark_id")
                        ->select("deals.*","stations.*","marks.*")
                        ->where("deals.deal_id","=",$request->deal_id)->first();
            if(@count($user_row) > 0 && strlen($user_row['email']) > 0){
                $email_to = "adik.khalikhov@mail.ru";

                $message_str = 'Уважаемый (-ая), ' . $user_row['user_surname'] . " " . $user_row['user_name'];
                $message_str .= '<br>У вас новая задача: ';
                $message_str .= '<br><b>Сделка:</b> ' . $deal_row['station_name'] . ' - ' .  $deal_row['mark_name'] . ' ' . $deal_row['deal_volume'] . ' тонн';
                $message_str .= '<br><b>Дата и время исполнения:</b> ' . date('d.m.Y', strtotime($request->user_task_start_date)) . ' ' .  $request['user_task_start_time'] . ' - ' . date('d.m.Y', strtotime($request->user_task_end_date)) . ' ' .  $request['user_task_end_time'];
                $message_str .= '<br><b>Текст:</b> ' . nl2br($new_task->user_task_text);
                $message_str .= '<br><b>Статус:</b> В процессе';
                Mail::send(['html' => 'admin.email-template'], ['text' => $message_str], function($message) use ($email_to)
                {
                    $message->to($email_to)->subject("Новая задача");
                });
                if(@count(Mail::failures()) > 0){
                    return response()->json(['result'=>'error_sending_mail']);
                }
            }
            else{
                return response()->json(['result'=>'error_user']);
            }
            return response()->json(['result'=>true]);
        }
        else{
            return response()->json(['result'=>false]);
        }
    }

    public function saveClientAnswer(Request $request){
        $deal_row = Deal::where("deal_id","=",$request->deal_id)->first();
        if(@count($deal_row) > 0) {
            if ($deal_row['deal_status_id'] < 3) {
                return response()->json(['result' => 'incorrect_status']);
            }
            $new_client_answer = new ClientAnswer();
            $new_client_answer->client_answer_deal_id = $request->deal_id;
            $new_client_answer->client_answer_user_id = $request->deal_user_id3;
            $offset = strtotime("+6 hours 0 minutes");
            $new_client_answer->client_answer_datetime = date("Y-m-d H:i:s", $offset);
            $new_client_answer->client_answer_text = $request->client_answer_text;
            if ($new_client_answer->save()) {
                return response()->json(['result' => true]);
            }
            else {
                return response()->json(['result' => false]);
            }
        }
        else {
            return response()->json(['result' => false]);
        }
    }

    public function deleteClientAnswer(Request $request){
        $client_answer_id = $request->client_answer_id;
        $result = ClientAnswer::where('client_answer_id', '=', $client_answer_id)->delete();
        return response()->json(['result'=>$result]);
    }

    public function saveShippingComment(Request $request){
        $deal_row = Deal::where("deal_id","=",$request->deal_id)->first();
        if(@count($deal_row) > 0){
            if($deal_row['deal_status_id'] < 8){
                return response()->json(['result'=>'incorrect_status']);
            }
            $new_shipping_comment = new ShippingComment();
            $new_shipping_comment->shipping_comment_deal_id = $request->deal_id;
            $new_shipping_comment->shipping_comment_user_id = $request->deal_user_id8;
            $offset= strtotime("+6 hours 0 minutes");
            $new_shipping_comment->shipping_comment_datetime = date("Y-m-d H:i:s",$offset);
            $new_shipping_comment->shipping_comment_text = $request->shipping_comment_text;
            if($new_shipping_comment->save()){
                return response()->json(['result'=>true]);
            }
            else{
                return response()->json(['result'=>false]);
            }
        }
        else{
            return response()->json(['result'=>false]);
        }
    }

    public function deleteShippingComment(Request $request){
        $shipping_comment_id = $request->shipping_comment_id;
        $result = ShippingComment::where('shipping_comment_id', '=', $shipping_comment_id)->delete();
        return response()->json(['result'=>$result]);
    }

    public function saveDeliveryComment(Request $request){
        $deal_row = Deal::where("deal_id","=",$request->deal_id)->first();
        if(@count($deal_row) > 0){
            if($deal_row['deal_status_id'] < 9){
//                return response()->json(['result'=>'incorrect_status']);
            }
            $new_delivery_comment = new DeliveryComment();
            $new_delivery_comment->delivery_comment_deal_id = $request->deal_id;
            $new_delivery_comment->delivery_comment_user_id = $request->deal_user_id9;
            $offset= strtotime("+6 hours 0 minutes");
            $new_delivery_comment->delivery_comment_datetime = date("Y-m-d H:i:s",$offset);
            $new_delivery_comment->delivery_comment_text = $request->delivery_comment_text;
            if($new_delivery_comment->save()){
                return response()->json(['result'=>true]);
            }
            else{
                return response()->json(['result'=>false]);
            }
        }
        else{
            return response()->json(['result'=>false]);
        }
    }

    public function deleteDeliveryComment(Request $request){
        $delivery_comment_id = $request->delivery_comment_id;
        $result = DeliveryComment::where('delivery_comment_id', '=', $delivery_comment_id)->delete();
        return response()->json(['result'=>$result]);
    }

    public function loadDealTask(Request $request){
        $deal_task_list = UserTask::LeftJoin("users","user_tasks.user_task_user_id","=","users.user_id")
                                ->LeftJoin("tasks","user_tasks.user_task_task_id","=","tasks.task_id")
                                ->select("user_tasks.*","users.*","tasks.*",DB::raw('DATE_FORMAT(user_tasks.user_task_end_date,"%d.%m.%Y") as user_task_end_date_format'),DB::raw('DATE_FORMAT(user_tasks.user_task_start_date,"%d.%m.%Y") as user_task_start_date_format'))
                                ->where("user_tasks.user_task_deal_id","=",$request->deal_id)
                                ->orderByRaw(DB::raw("FIELD(user_tasks.user_task_task_id, '2', '1', '3','4')"))
                                ->orderBy("user_tasks.user_task_end_date","desc")->get();
        return view('admin.load-deal-task', ['deal_task_list' => $deal_task_list]);
    }

    public function loadClientAnswers(Request $request){
        $client_answer_list = ClientAnswer::LeftJoin("users","client_answers.client_answer_user_id","=","users.user_id")
                                    ->select("client_answers.*",DB::raw('DATE_FORMAT(client_answers.client_answer_datetime,"%d.%m.%Y %T") as client_answer_datetime_format'),"users.*")
                                    ->orderBy("client_answer_datetime","desc")->where("client_answer_deal_id","=",$request->deal_id)->get();
        return view('admin.load-client-answer', ['client_answer_list' => $client_answer_list]);
    }

    public function loadShippingComment(Request $request){
        $shipping_comment_list = ShippingComment::LeftJoin("users","shipping_comments.shipping_comment_user_id","=","users.user_id")
                                    ->select("shipping_comments.*",DB::raw('DATE_FORMAT(shipping_comments.shipping_comment_datetime,"%d.%m.%Y %T") as shipping_comment_datetime_format'),"users.*")
                                    ->orderBy("shipping_comment_datetime","desc")->where("shipping_comment_deal_id","=",$request->deal_id)->get();
        return view('admin.load-shipping-comment', ['shipping_comment_list' => $shipping_comment_list]);
    }

    public function loadDeliveryComment(Request $request){
        $delivery_comment_list = DeliveryComment::LeftJoin("users","delivery_comments.delivery_comment_user_id","=","users.user_id")
                                    ->select("delivery_comments.*",DB::raw('DATE_FORMAT(delivery_comments.delivery_comment_datetime,"%d.%m.%Y %T") as delivery_comment_datetime_format'),"users.*")
                                    ->orderBy("delivery_comment_datetime","desc")->where("delivery_comment_deal_id","=",$request->deal_id)->get();
        return view('admin.load-delivery-comment', ['delivery_comment_list' => $delivery_comment_list]);
    }

    public function loadDealHistory(Request $request){
        $deal_history_list = DealHistory::LeftJoin("users","deal_histories.deal_history_user_id","=","users.user_id")
                                    ->select("deal_histories.*",DB::raw('DATE_FORMAT(deal_histories.deal_history_datetime,"%d.%m.%Y %T") as deal_history_datetime_format'),"users.*")
                                    ->orderBy("deal_history_datetime","desc")->where("deal_history_deal_id","=",$request->deal_id)->get();
        return view('admin.load-deal-history', ['deal_history_list' => $deal_history_list]);
    }

    public function loadDealBillFile(Request $request){
        $deal_bill_file_list = DealFile::select("deal_files.*",DB::raw('DATE_FORMAT(deal_files.deal_file_date,"%d.%m.%Y %T") as deal_file_date_format'))->
                                    where("deal_file_deal_id","=",$request->deal_id)->where("deal_file_type","=",2)->orderBy("deal_file_date","desc")->get();
        return view('admin.load-deal-bill-file', ['deal_bill_file_list' => $deal_bill_file_list]);
    }

    public function completeUserTask(Request $request){
        $user_task_row = UserTask::where("user_task_id","=",$request->user_task_id)->first();
        if(@count($user_task_row) > 0){
            $offset= strtotime("+6 hours 0 minutes");
            if(strtotime($user_task_row['user_task_end_date']) < strtotime(date("Y-m-d", $offset))){
                $user_task_row->user_task_task_id = 4;
            }
            else{
                $user_task_row->user_task_task_id = 3;
            }
            if($user_task_row->save()){
                return response()->json(['result'=>true]);
            }
            else{
                return response()->json(['result'=>false]);
            }
        }
        else{
            return response()->json(['result'=>false]);
        }
    }

    public function userTaskList(Request $request){

        $user_task_list[1] = UserTask::LeftJoin("users","user_tasks.user_task_user_id","=","users.user_id")
                                        ->LeftJoin("tasks","user_tasks.user_task_task_id","=","tasks.task_id")
                                        ->LeftJoin("deals","user_tasks.user_task_deal_id","=","deals.deal_id")
                                        ->LeftJoin("marks","deals.deal_mark_id","=","marks.mark_id")
                                        ->LeftJoin("stations","deals.deal_station_id","=","stations.station_id")
                                        ->select("user_tasks.*","users.*","tasks.*",DB::raw('DATE_FORMAT(user_tasks.user_task_end_date,"%d.%m.%Y") as user_task_end_date_format'), "deals.*", "marks.*","stations.*")
                                        ->where("user_tasks.user_task_task_id","=",1);

        if(isset($request->client_id) && $request->client_id > 0){
            $user_task_list[1] = $user_task_list[1]->where("deals.deal_client_id","=",$request->client_id);
        }
        if(isset($request->user_id) && $request->user_id > 0){
            $user_task_list[1] = $user_task_list[1]->where("user_tasks.user_task_user_id","=",$request->user_id);
        }
        if(isset($request->user_task_start_date) && strlen($request->user_task_start_date) > 0 && isset($request->user_task_end_date) && strlen($request->user_task_end_date) > 0){
            $from = date('Y-m-d 00:00:00',strtotime($request->user_task_start_date));
            $to = date('Y-m-d 23:59:59',strtotime($request->user_task_end_date));
            $user_task_list[1] = $user_task_list[1]->whereBetween('user_tasks.user_task_end_date', array($from, $to));
        }

        $user_task_list[1] = $user_task_list[1]->get();

        $user_task_list[2] = UserTask::LeftJoin("users","user_tasks.user_task_user_id","=","users.user_id")
                                        ->LeftJoin("tasks","user_tasks.user_task_task_id","=","tasks.task_id")
                                        ->LeftJoin("deals","user_tasks.user_task_deal_id","=","deals.deal_id")
                                        ->LeftJoin("marks","deals.deal_mark_id","=","marks.mark_id")
                                        ->LeftJoin("stations","deals.deal_station_id","=","stations.station_id")
                                        ->select("user_tasks.*","users.*","tasks.*",DB::raw('DATE_FORMAT(user_tasks.user_task_end_date,"%d.%m.%Y") as user_task_end_date_format'), "deals.*", "marks.*","stations.*")
                                        ->where("user_tasks.user_task_task_id","=",2);

        if(isset($request->client_id) && $request->client_id > 0){
            $user_task_list[2] = $user_task_list[2]->where("deals.deal_client_id","=",$request->client_id);
        }
        if(isset($request->user_id) && $request->user_id > 0){
            $user_task_list[2] = $user_task_list[2]->where("user_tasks.user_task_user_id","=",$request->user_id);
        }
        if(isset($request->user_task_start_date) && strlen($request->user_task_start_date) > 0 && isset($request->user_task_end_date) && strlen($request->user_task_end_date) > 0){
            $from = date('Y-m-d 00:00:00',strtotime($request->user_task_start_date));
            $to = date('Y-m-d 23:59:59',strtotime($request->user_task_end_date));
            $user_task_list[2] = $user_task_list[2]->whereBetween('user_tasks.user_task_end_date', array($from, $to));
        }

        $user_task_list[2] = $user_task_list[2]->get();

        $user_task_list[3] = UserTask::LeftJoin("users","user_tasks.user_task_user_id","=","users.user_id")
                                        ->LeftJoin("tasks","user_tasks.user_task_task_id","=","tasks.task_id")
                                        ->LeftJoin("deals","user_tasks.user_task_deal_id","=","deals.deal_id")
                                        ->LeftJoin("marks","deals.deal_mark_id","=","marks.mark_id")
                                        ->LeftJoin("stations","deals.deal_station_id","=","stations.station_id")
                                        ->select("user_tasks.*","users.*","tasks.*",DB::raw('DATE_FORMAT(user_tasks.user_task_end_date,"%d.%m.%Y") as user_task_end_date_format'), "deals.*", "marks.*","stations.*")
                                        ->where("user_tasks.user_task_task_id","=",3);

        if(isset($request->client_id) && $request->client_id > 0){
            $user_task_list[3] = $user_task_list[3]->where("deals.deal_client_id","=",$request->client_id);
        }
        if(isset($request->user_id) && $request->user_id > 0){
            $user_task_list[3] = $user_task_list[3]->where("user_tasks.user_task_user_id","=",$request->user_id);
        }
        if(isset($request->user_task_start_date) && strlen($request->user_task_start_date) > 0 && isset($request->user_task_end_date) && strlen($request->user_task_end_date) > 0){
            $from = date('Y-m-d 00:00:00',strtotime($request->user_task_start_date));
            $to = date('Y-m-d 23:59:59',strtotime($request->user_task_end_date));
            $user_task_list[3] = $user_task_list[3]->whereBetween('user_tasks.user_task_end_date', array($from, $to));
        }

        $user_task_list[3] = $user_task_list[3]->get();

        $user_task_list[4] = UserTask::LeftJoin("users","user_tasks.user_task_user_id","=","users.user_id")
                                        ->LeftJoin("tasks","user_tasks.user_task_task_id","=","tasks.task_id")
                                        ->LeftJoin("deals","user_tasks.user_task_deal_id","=","deals.deal_id")
                                        ->LeftJoin("marks","deals.deal_mark_id","=","marks.mark_id")
                                        ->LeftJoin("stations","deals.deal_station_id","=","stations.station_id")
                                        ->select("user_tasks.*","users.*","tasks.*",DB::raw('DATE_FORMAT(user_tasks.user_task_end_date,"%d.%m.%Y") as user_task_end_date_format'), "deals.*", "marks.*","stations.*")
                                        ->where("user_tasks.user_task_task_id","=",4);

        if(isset($request->client_id) && $request->client_id > 0){
            $user_task_list[4] = $user_task_list[4]->where("deals.deal_client_id","=",$request->client_id);
        }
        if(isset($request->user_id) && $request->user_id > 0){
            $user_task_list[4] = $user_task_list[4]->where("user_tasks.user_task_user_id","=",$request->user_id);
        }
        if(isset($request->user_task_start_date) && strlen($request->user_task_start_date) > 0 && isset($request->user_task_end_date) && strlen($request->user_task_end_date) > 0){
            $from = date('Y-m-d 00:00:00',strtotime($request->user_task_start_date));
            $to = date('Y-m-d 23:59:59',strtotime($request->user_task_end_date));
            $user_task_list[4] = $user_task_list[4]->whereBetween('user_tasks.user_task_end_date', array($from, $to));
        }

        $user_task_list[4] = $user_task_list[4]->get();

        $client_list = Client::orderBy("client_name","asc")->get();
        $user_list = Users::orderBy("user_surname","asc")->get();

        return view('admin.user-task-list',['user_task_list' => $user_task_list, 'client_list' => $client_list, 'user_list' => $user_list, 'user_task_start_date' => $request->user_task_start_date, 'user_task_end_date' => $request->user_task_end_date, 'client_id' => $request->client_id, 'user_id' => $request->user_id, 'task_id' => $request->task_id]);

    }

    public function companyList(Request $request){
        $row_count = 20;
        if(isset($request->row_count)){
            $row_count = $request->row_count;
        }
        $row = Company::select('companies.*');

        if(isset($request->search_word) && strlen($request->search_word) > 0){
            $row = $row->where(function($query) use ($request)
            {
                $query->where("companies.company_name","like","%" . $request->search_word . "%")->orWhere("company_ceo_position","like","%" . $request->search_word . "%")->orWhere("company_ceo_name","like","%" . $request->search_word . "%");
            });
        }
        $row = $row->paginate($row_count);
        return view('admin.company-list', [ 'row' => $row, 'row_count' => $row_count,'search_word' => $request->search_word]);
    }

    public function companyEdit(Request $request){
        $company_id = $request->company_id;

        $row = Company::select("companies.*")
            ->where("company_id","=",$company_id)->first();
        if(@count($row) < 1){
            $row = new Company();
            $row->company_id = 0;
        }

        return view('admin.company-edit', ['row' => $row]);
    }

    public function deleteCompany(Request $request){
        $company_id = $request->company_id;
        $result = Company::where('company_id', '=', $company_id)->delete();
        return response()->json(['result'=>$result]);
    }

    public function saveCompany(Request $request){
        if($request->company_id > 0) {
            $company_item = Company::find($request->company_id);
        }
        else {
            $company_item = new Company();
        }

        $company_item->company_name = $request->company_name;
        $company_item->company_ceo_position = $request->company_ceo_position;
        $company_item->company_ceo_name = $request->company_ceo_name;
        $company_item->company_address = $request->company_address;
        $company_item->company_bank_id = $request->company_bank_id;
        $company_item->company_bank_iik = $request->company_bank_iik;
        $company_item->company_bank_bin = $request->company_bank_bin;
        $company_item->company_delivery_address = $request->company_delivery_address;
        $company_item->company_okpo = $request->company_okpo;

        if($company_item->save()){
            return response()->json(['result'=>true]);
        }
        else{
            return response()->json(['result'=>false]);
        }
    }

    public function calculateDealKpSum(Request $request){
        $station_row = Station::where("station_id","=",$request->station_id)->first();
        $region_row = Region::where("region_id","=",$request->region_id)->first();

        $percents_row = Station::LeftJoin("percents","stations.station_brand_id","=","percents.percent_brand_id")
                            ->select("percents.*")
                            ->where("stations.station_id","=",$request->station_id)
                            ->first();
        if(@count($percents_row) > 0){
            if($percents_row->percent_rate > 0){
                $sum = (($station_row['station_rate_nds']+$region_row['region_price_nds'])+ ($station_row['station_rate_nds']+$region_row['region_price_nds'])*$percents_row['percent_rate']/100)*$request->deal_volume;
            }
            else{
                $sum = ($station_row['station_rate_nds']+$region_row['region_price_nds']+$percents_row['percent_sum_rate'])*$request->deal_volume;
            }
            return response()->json(['result'=>true, 'sum' => floor($sum)]);
        }
        else{
            return response()->json(['result'=>false]);
        }
    }

    public function dealTemplateFileList(Request $request){
        $row = DealTemplateFile::orderBy("deal_template_type_id")->get();
        return view('admin.deal-template-file-list', [ 'row' => $row]);
    }

    public function dealTemplateFileEdit(Request $request){
        $deal_template_file_id = $request->deal_template_file_id;

        $row = DealTemplateFile::find($deal_template_file_id);
        if(@count($row) < 1){
            $row = new DealTemplateFile();
            $row->deal_template_file_id = 0;
        }
        return view('admin.deal-template-file-edit', ['row' => $row]);
    }

    public function deleteDealTemplateFile(Request $request){
        $deal_template_file_id = $request->deal_template_file_id;
        $result = DealTemplateFile::where('deal_template_file_id', '=', $deal_template_file_id)->delete();
        return response()->json(['result'=>$result]);
    }

    public function saveDealTemplateFile(Request $request){
        $messages = array(
            'deal_template_type_id.not_in' => 'Укажите Тип шаблона файла',
            'deal_template_text.required' => 'Укажите HTML шаблона файла'
        );
        $validator = Validator::make($request->all(), [
            'deal_template_type_id' => 'required|not_in:0',
            'deal_template_text' => 'required'
        ], $messages);

        if ($validator->fails()) {
            $messages = $validator->errors();
            $error = $messages->all();

            $result['value'] = $error;
            $result['status'] = false;
            $role_list = Role::all();
            return view('admin.deal-template-file-edit', [ 'row' => $request, 'role_list' => $role_list, 'result' => $result ]);
        }

        if($request->deal_template_file_id > 0) {
            $deal_template_file_item = DealTemplateFile::find($request->deal_template_file_id);
        }
        else {
            $deal_template_file_item = new DealTemplateFile();
        }

        $deal_template_file_item->deal_template_type_id = $request->deal_template_type_id;
        $deal_template_file_item->deal_template_text = $request->deal_template_text;

        if($deal_template_file_item->save()){
            return redirect('/admin/deal-template-file-list');
        }
        else{
            $error[0] = 'Ошибка при сохранении';
            $result['value'] = $error;
            $result['status'] = false;
            $role_list = Role::all();
            return view('admin.deal-template-file-edit', [ 'row' => $request, 'result' => $result ]);
        }
    }

    public function uploadDealDogovorFile(Request $request){
        $this->deleteFile("file_template","dogovor_filetemplate.docx");
        $file = $request->deal_dogovor_file;
        $file_name = "dogovor_filetemplate.";
        $file_extension = $file->extension($file_name);
        $file_name = $file_name . $file_extension;
        Storage::disk('file_template')->put($file_name, File::get($file));
        return response()->json(['result'=>true]);
    }

    public function downloadDealKp(Request $request, $is_static_call = 0){
        $deal_kp_file_row = DealFile::where("deal_file_deal_id","=",$request->deal_id)->where("deal_file_type","=",1)->first();
        if(@count($deal_kp_file_row) > 0 && strlen($deal_kp_file_row['deal_file_src']) > 0){
            $this->deleteFile("deal_files",$deal_kp_file_row['deal_file_src']);
            $delete_result = DealFile::where('deal_file_id', '=', $deal_kp_file_row['deal_file_id'])->delete();
        }

        $deal_template_file_row = DealTemplateFile::where("deal_template_type_id","=",1)->first();
        $deal_template_text = $this->replaceDealFileTemplate($deal_template_file_row['deal_template_text'],$request->deal_id);

//        return view('admin.test-pdf', [ 'deal_template_text' => $deal_template_text]);
        $pdf = PDF::loadView('admin.test-pdf',['deal_template_text' => $deal_template_text]);
        $deal_file_src = time() . $request->deal_id . '_kp.pdf';
        $pdf->save('deal_files/' . $deal_file_src);

        $new_deal_file = new DealFile();
        $new_deal_file->deal_file_deal_id = $request->deal_id;
        $new_deal_file->deal_file_name = $deal_file_src;
        $new_deal_file->deal_file_src = $deal_file_src;
        $new_deal_file->deal_file_type = 1;
        $offset= strtotime("+6 hours 0 minutes");
        $new_deal_file->deal_file_date = date("Y-m-d H:i:s",$offset);
        if($new_deal_file->save()){
            $result['result'] = true;
            $result['filename'] = '/deal_files/' . $deal_file_src;
            $result['filename2'] = 'deal_files/' . $deal_file_src;
            $result['file_name'] = $deal_file_src;
        }
        else{
            $result['result'] = false;
        }
        if($is_static_call == 1){
            return $result;
        }
        else{
            return response()->json(['result'=>$result]);
        }
    }

    public function sendKpMail(Request $request){
        $result = $this->downloadDealKp($request,1);
        $email_to = "adik.khalikhov@mail.ru";
        $message_str = 'Уважаемый (-ая), <br>Ваш пароль для входа в личный кабинет: ';
        Mail::send(['html' => 'admin.email-kp'], ['text' => $message_str], function($message) use ($email_to,$result)
        {
            $message->to($email_to)->subject("Договор КП");
            $message->attach($result['filename2'], ['as' => $result['file_name'], 'mime' => 'application/pdf']);
        });
        if(@count(Mail::failures()) > 0){
            return response()->json(['result'=>false]);
        }
        else{
            return response()->json(['result'=>true]);
        }
    }

    public function createDealBillFile(Request $request, $is_static_call = 0){
        $deal_template_file_row = DealTemplateFile::where("deal_template_type_id","=",2)->first();
        $deal_template_text = $this->replaceDealFileTemplate($deal_template_file_row['deal_template_text'],$request->deal_id);
        $pdf = PDF::loadView('admin.test-pdf',['deal_template_text' => $deal_template_text]);
        $deal_file_src = time() . $request->deal_id . '_bill.pdf';
        $pdf->save('deal_files/' . $deal_file_src);

        $new_deal_file = new DealFile();
        $new_deal_file->deal_file_deal_id = $request->deal_id;
        $new_deal_file->deal_file_name = $deal_file_src;
        $new_deal_file->deal_file_src = $deal_file_src;
        $new_deal_file->deal_file_type = 2;
        $offset= strtotime("+6 hours 0 minutes");
        $new_deal_file->deal_file_date = date("Y-m-d H:i:s",$offset);
        if($new_deal_file->save()){
            return response()->json(['result'=>true]);
        }
        else{
            return response()->json(['result'=>false]);
        }
    }

    public function sendBillMail(Request $request){
        $deal_bill_file_row = DealFile::where("deal_file_id","=",$request->deal_file_id)->where("deal_file_deal_id","=",$request->deal_file_deal_id)->first();
        if(@count($deal_bill_file_row) > 0) {
            $email_to = "adik.khalikhov@mail.ru";
            $message_str = 'Уважаемый (-ая), <br>Ваш пароль для входа в личный кабинет: ';
            Mail::send(['html' => 'admin.email-kp'], ['text' => $message_str], function ($message) use ($email_to, $deal_bill_file_row) {
                $message->to($email_to)->subject("Счет на оплату");
                $message->attach("deal_files/" . $deal_bill_file_row['deal_file_src'], ['as' => $deal_bill_file_row['deal_file_name'], 'mime' => 'application/pdf']);
            });
            if (@count(Mail::failures()) > 0) {
                return response()->json(['result' => false]);
            }
            else {
                return response()->json(['result' => true]);
            }
        }
        else {
            return response()->json(['result' => false]);
        }
    }

    public function deleteDealFile(Request $request){
        $deal_bill_row = DealFile::where("deal_file_deal_id","=",$request->deal_file_deal_id)->where("deal_file_id","=",$request->deal_file_id)->first();
        if(@count($deal_bill_row) > 0){
            $this->deleteFile("deal_files",$deal_bill_row['deal_file_src']);
        }
        $result = DealFile::where("deal_file_deal_id","=",$request->deal_file_deal_id)->where("deal_file_id","=",$request->deal_file_id)->delete();
        return response()->json(['result'=>true]);
    }

    public function replaceDealFileTemplate($deal_template_text,$deal_file_deal_id){
        $deal_row = Deal::LeftJoin("clients","deals.deal_client_id","=","clients.client_id")
                        ->LeftJoin("brands","deals.deal_brand_id","=","brands.brand_id")
                        ->LeftJoin("marks","deals.deal_mark_id","=","marks.mark_id")
                        ->LeftJoin("fractions","deals.deal_fraction_id","=","fractions.fraction_id")
                        ->LeftJoin("regions","deals.deal_region_id","=","regions.region_id")
                        ->LeftJoin("stations","deals.deal_station_id","=","stations.station_id")
                        ->LeftJoin("companies","clients.client_company_id","=","companies.company_id")
                        ->select("deals.*","clients.*","brands.*","marks.*","fractions.*","regions.*","stations.*",
                            "companies.*",
                            DB::raw('DATE_FORMAT(deals.deal_datetime1,"%d.%m.%Y %T") as deal_datetime1_format'),
                            DB::raw('DATE_FORMAT(deals.deal_datetime2,"%d.%m.%Y %T") as deal_datetime2_format'),
                            DB::raw('DATE_FORMAT(deals.deal_datetime3,"%d.%m.%Y %T") as deal_datetime3_format'),
                            DB::raw('DATE_FORMAT(deals.deal_datetime4,"%d.%m.%Y %T") as deal_datetime4_format'),
                            DB::raw('DATE_FORMAT(deals.deal_datetime5,"%d.%m.%Y %T") as deal_datetime5_format'),
                            DB::raw('DATE_FORMAT(deals.deal_datetime6,"%d.%m.%Y %T") as deal_datetime6_format'),
                            DB::raw('DATE_FORMAT(deals.deal_datetime7,"%d.%m.%Y %T") as deal_datetime7_format'),
                            DB::raw('DATE_FORMAT(deals.deal_datetime8,"%d.%m.%Y %T") as deal_datetime8_format'),
                            DB::raw('DATE_FORMAT(deals.deal_datetime9,"%d.%m.%Y %T") as deal_datetime9_format'),
                            DB::raw('DATE_FORMAT(deals.deal_shipping_date,"%d/%m/%Y") as deal_shipping_date'),
                            DB::raw('DATE_FORMAT(deals.deal_delivery_date,"%d/%m/%Y") as deal_delivery_date')
                        )
                        ->where("deal_id","=",$deal_file_deal_id)->first();
        $replace_var_arr = ['deal_datetime1_format', 'deal_datetime2_format', 'deal_datetime3_format',
                            'deal_datetime4_format','deal_datetime5_format','deal_datetime6_format','deal_datetime7_format',
                            'deal_datetime8_format','deal_datetime9_format','status_name',"brand_name","mark_name",
                            "fractions.fraction_name","region_name","station_name","payment_name",
                            "deal_volume","deal_discount_type","deal_discount","delivery_name","deal_receiver_code",
                            "deal_brand_sum","deal_kp_sum","deal_shipping_date","deal_shipping_time","deal_delivery_date","deal_delivery_time",
                            'client_surname', 'client_name', "client_phone","client_email","company_name","company_ceo_position","company_ceo_name",
                            "company_address","company_bank_iik", "company_bank_bin","company_delivery_address","company_okpo"];

        foreach($replace_var_arr as $key => $replace_var_arr_item){
            $deal_template_text = str_replace('${' . $replace_var_arr_item . '}',$deal_row[$replace_var_arr_item], $deal_template_text);
        }
        return $deal_template_text;
    }

    public function testDoc(){
        $templateProcessor = new \PhpOffice\PhpWord\TemplateProcessor('file_template/kp_template.docx');
        $templateProcessor->setValue('${fio}', 'ФИО');
        $templateProcessor->saveAs('trash/Sample_07_TemplateCloneRow.docx');
    }
}
